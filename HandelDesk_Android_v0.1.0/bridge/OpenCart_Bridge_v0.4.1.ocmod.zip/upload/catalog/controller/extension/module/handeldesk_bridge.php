<?php
class ControllerExtensionModuleHandeldeskBridge extends Controller {
    const PROTOCOL = '0.4.1';

    private $allowed_product_fields = array(
        'model','sku','upc','ean','jan','isbn','mpn','location','quantity','stock_status_id','image','manufacturer_id',
        'shipping','price','points','tax_class_id','date_available','weight','weight_class_id','length','width','height',
        'length_class_id','subtract','minimum','sort_order','status'
    );

    private $description_fields = array('name','description','tag','meta_title','meta_description','meta_keyword');

    public function index() {
        try {
            $this->authorize();
            $action = isset($this->request->get['action']) ? $this->request->get['action'] : 'schema';
            if ($action === 'image_fetch') {
                $this->actionImageFetch();
                return;
            }
            $this->response->addHeader('Content-Type: application/json; charset=utf-8');
            $map = array(
                'schema' => 'actionSchema',
                'reference' => 'actionReference',
                'snapshot' => 'actionSnapshot',
                'sync_preview' => 'actionSyncPreview',
                'sync_apply' => 'actionSyncApply',
                'image_upload' => 'actionImageUpload'
            );
            if (!isset($map[$action])) throw new Exception('Unknown action', 404);
            $method = $map[$action];
            $result = $this->$method();
            if (!is_array($result)) $result = array();
            $result['ok'] = true;
            $this->response->setOutput(json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        } catch (Exception $e) {
            $code = (int)$e->getCode();
            if ($code < 400 || $code > 599) $code = 500;
            $this->response->addHeader('Content-Type: application/json; charset=utf-8');
            $this->response->addHeader('HTTP/1.1 ' . $code . ' ' . $this->statusText($code));
            $this->response->setOutput(json_encode(array('ok' => false, 'error' => $e->getMessage()), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        }
    }

    private function decodeEditorHtml($value) {
        $value = (string)$value;
        // Do not blindly decode literal entities. Decode only when encoded HTML structure is visible.
        if (!$this->descriptionUsesEntityStorage($value)) return $value;
        return html_entity_decode($value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }

    private function descriptionUsesEntityStorage($raw) {
        $raw = (string)$raw;
        return (bool)preg_match('/&lt;\s*\/?\s*(?:p|br|div|span|ul|ol|li|strong|b|em|i|a|h[1-6]|table|thead|tbody|tr|td|th|img)(?:\s|&gt;)/i', $raw);
    }

    private function siteUsesEntityDescriptionStorage() {
        $q = $this->db->query("SELECT description FROM `" . DB_PREFIX . "product_description` WHERE description<>'' ORDER BY product_id DESC LIMIT 100");
        $encoded = 0; $raw = 0;
        foreach ($q->rows as $r) {
            $v = isset($r['description']) ? (string)$r['description'] : '';
            if ($this->descriptionUsesEntityStorage($v)) $encoded++;
            elseif (preg_match('/<\s*\/?\s*(?:p|br|div|span|ul|ol|li|strong|b|em|i|a|h[1-6]|table|tr|td|th|img)\b/i', $v)) $raw++;
        }
        return $encoded > $raw;
    }

    private function encodeEditorHtmlForStorage($value, $existingRaw = null) {
        $encoded = ($existingRaw !== null) ? $this->descriptionUsesEntityStorage($existingRaw) : $this->siteUsesEntityDescriptionStorage();
        if (!$encoded) return (string)$value;
        return htmlspecialchars((string)$value, ENT_QUOTES | ENT_HTML5, 'UTF-8', false);
    }

    private function statusText($code) {
        $map = array(400=>'Bad Request',401=>'Unauthorized',403=>'Forbidden',404=>'Not Found',409=>'Conflict',500=>'Internal Server Error',503=>'Service Unavailable');
        return isset($map[$code]) ? $map[$code] : 'Error';
    }

    private function authorize() {
        if (!$this->config->get('module_handeldesk_bridge_status')) {
            throw new Exception('HandelDesk Bridge is disabled', 503);
        }
        if ($this->config->get('module_handeldesk_bridge_require_https')) {
            $https = (!empty($this->request->server['HTTPS']) && $this->request->server['HTTPS'] !== 'off') ||
                     (isset($this->request->server['HTTP_X_FORWARDED_PROTO']) && strtolower($this->request->server['HTTP_X_FORWARDED_PROTO']) === 'https');
            if (!$https) throw new Exception('HTTPS is required', 403);
        }
        $token = '';
        if (isset($this->request->server['HTTP_X_HANDELDESK_TOKEN'])) {
            $token = trim($this->request->server['HTTP_X_HANDELDESK_TOKEN']);
        }
        $expected = (string)$this->config->get('module_handeldesk_bridge_token_hash');
        if (!$token || !$expected || !hash_equals($expected, hash('sha256', $token))) {
            throw new Exception('Invalid device token', 401);
        }
        if ($this->request->server['REQUEST_METHOD'] === 'POST') {
            $ctype = isset($this->request->server['CONTENT_TYPE']) ? strtolower($this->request->server['CONTENT_TYPE']) : '';
            if (strpos($ctype, 'application/json') === false) {
                throw new Exception('POST requests must use application/json', 400);
            }
        }
    }

    private function writeMode() {
        $mode = (string)$this->config->get('module_handeldesk_bridge_write_mode');
        if (!in_array($mode, array('read_only','safe_test','live'), true)) $mode = 'read_only';
        return $mode;
    }

    private function allowedSafePaths() {
        $raw = (string)$this->config->get('module_handeldesk_bridge_safe_allowed_paths');
        $parts = preg_split('/[\r\n,;]+/', $raw);
        $out = array();
        foreach ($parts as $p) {
            $p = trim($p);
            if ($p !== '' && preg_match('/^[A-Za-z0-9_*.-]+$/', $p)) $out[] = $p;
        }
        return array_values(array_unique($out));
    }

    private function safePathMatches($path, $pattern) {
        $a = explode('.', (string)$path); $b = explode('.', (string)$pattern);
        if (count($a) !== count($b)) return false;
        foreach ($a as $i=>$part) if ($b[$i] !== '*' && $b[$i] !== $part) return false;
        return true;
    }

    private function writePolicy() {
        return array(
            'mode'=>$this->writeMode(),
            'safe_product_id'=>(int)$this->config->get('module_handeldesk_bridge_safe_product_id'),
            'safe_allowed_paths'=>$this->allowedSafePaths(),
            'server_enforced'=>true
        );
    }

    private function writePolicyViolations($payload) {
        $mode = $this->writeMode();
        if ($mode === 'live') return array();
        if ($mode === 'read_only') return array('Bridge is READ ONLY: server-side writes are disabled.');
        $errors = array();
        $safeId = (int)$this->config->get('module_handeldesk_bridge_safe_product_id');
        $allowed = $this->allowedSafePaths();
        $items = isset($payload['products']) && is_array($payload['products']) ? $payload['products'] : array();
        $manufacturers = isset($payload['manufacturers']) && is_array($payload['manufacturers']) ? $payload['manufacturers'] : array();
        $categories = isset($payload['categories']) && is_array($payload['categories']) ? $payload['categories'] : array();
        if ($manufacturers || $categories) $errors[] = 'SAFE TEST forbids manufacturer/category writes.';
        if ($safeId <= 0) $errors[] = 'SAFE TEST product_id is not configured.';
        if (count($items) !== 1) $errors[] = 'SAFE TEST requires exactly one existing product in the payload.';
        foreach ($items as $item) {
            $pid = isset($item['product_id']) && $item['product_id'] !== null ? (int)$item['product_id'] : 0;
            if (!$pid) $errors[] = 'SAFE TEST forbids creating products.';
            if ($safeId > 0 && $pid !== $safeId) $errors[] = 'SAFE TEST payload product_id does not match configured product_id.';
            $changes = isset($item['changes']) && is_array($item['changes']) ? $item['changes'] : array();
            if (!$changes) $errors[] = 'SAFE TEST payload has no changes.';
            foreach ($changes as $ch) {
                $path = isset($ch['field_path']) ? (string)$ch['field_path'] : '';
                if ($path === '__create__') { $errors[] = 'SAFE TEST forbids create operations.'; continue; }
                $ok = false; foreach ($allowed as $pattern) if ($this->safePathMatches($path, $pattern)) { $ok = true; break; }
                if (!$ok) $errors[] = 'SAFE TEST field is not allowed: '.$path;
            }
        }
        if (!$allowed) $errors[] = 'SAFE TEST allowed field list is empty.';
        return array_values(array_unique($errors));
    }

    private function assertWriteAllowed($payload, $kind='sync') {
        if ($kind === 'image') {
            if ($this->writeMode() !== 'live') throw new Exception('Image upload is allowed only in LIVE write mode.', 403);
            return;
        }
        $errors = $this->writePolicyViolations($payload);
        if ($errors) throw new Exception('Write policy blocked Apply: '.implode(' | ', $errors), 403);
    }

    private function iniBytes($value) {
        $value = trim((string)$value);
        if ($value === '') return 0;
        $last = strtolower(substr($value, -1));
        $num = (float)$value;
        if ($last === 'g') $num *= 1024;
        if ($last === 'g' || $last === 'm') $num *= 1024;
        if ($last === 'g' || $last === 'm' || $last === 'k') $num *= 1024;
        return (int)$num;
    }

    private function maxImageUploadBytes() {
        $post = $this->iniBytes(ini_get('post_max_size'));
        if ($post <= 0) $post = 8 * 1024 * 1024;
        // JSON Base64 costs ~4/3 plus envelope/headroom.
        return max(256 * 1024, min(20 * 1024 * 1024, (int)floor($post * 0.68)));
    }

    private function safeImagePath($path) {
        $path = str_replace('\\', '/', trim((string)$path));
        $path = ltrim($path, '/');
        if ($path === '' || strpos($path, "\0") !== false || preg_match('#(^|/)\.\.(/|$)#', $path)) {
            throw new Exception('Invalid image path', 400);
        }
        if (!preg_match('/\.(jpe?g|png|gif|webp)$/i', $path)) throw new Exception('Unsupported image type', 400);
        return $path;
    }

    private function actionImageFetch() {
        if ($this->request->server['REQUEST_METHOD'] !== 'GET') throw new Exception('GET required', 400);
        $path = isset($this->request->get['path']) ? $this->safeImagePath($this->request->get['path']) : '';
        if (!$path) throw new Exception('Missing image path', 400);
        $root = realpath(DIR_IMAGE);
        $full = realpath(DIR_IMAGE . $path);
        if ($root === false || $full === false || strpos($full, $root . DIRECTORY_SEPARATOR) !== 0 || !is_file($full)) throw new Exception('Image not found', 404);
        if (filesize($full) > 20 * 1024 * 1024) throw new Exception('Image too large', 400);
        $info = @getimagesize($full);
        if (!$info || empty($info['mime'])) throw new Exception('Invalid image file', 400);
        $this->response->addHeader('Content-Type: ' . $info['mime']);
        $this->response->addHeader('Content-Length: ' . filesize($full));
        $this->response->addHeader('Cache-Control: private, max-age=300');
        $this->response->setOutput(file_get_contents($full));
    }

    private function actionImageUpload() {
        $data = $this->inputJson();
        $this->assertWriteAllowed($data, 'image');
        $file_id = isset($data['file_id']) ? trim((string)$data['file_id']) : '';
        $filename = isset($data['filename']) ? trim((string)$data['filename']) : '';
        $sha256 = isset($data['sha256']) ? strtolower(trim((string)$data['sha256'])) : '';
        $encoded = isset($data['data_base64']) ? (string)$data['data_base64'] : '';
        if ($file_id === '' || !preg_match('/^[A-Za-z0-9._-]{8,128}$/', $file_id)) throw new Exception('Invalid file_id', 400);
        if (!preg_match('/^[a-f0-9]{64}$/', $sha256)) throw new Exception('Invalid SHA-256', 400);
        if ($encoded === '' || strlen($encoded) > 30 * 1024 * 1024) throw new Exception('Image payload too large', 400);
        $binary = base64_decode($encoded, true);
        $maxImage = $this->maxImageUploadBytes();
        if ($binary === false || strlen($binary) < 16 || strlen($binary) > $maxImage) throw new Exception('Invalid image payload or file exceeds server limit of '.round($maxImage/1048576, 1).' MB', 400);
        if (!hash_equals($sha256, hash('sha256', $binary))) throw new Exception('Image checksum mismatch', 400);
        $info = @getimagesizefromstring($binary);
        if (!$info || empty($info[2])) throw new Exception('Uploaded file is not a supported image', 400);
        $extMap = array(IMAGETYPE_JPEG=>'jpg', IMAGETYPE_PNG=>'png', IMAGETYPE_GIF=>'gif');
        if (defined('IMAGETYPE_WEBP')) $extMap[IMAGETYPE_WEBP] = 'webp';
        if (!isset($extMap[$info[2]])) throw new Exception('Unsupported image type', 400);
        $ext = $extMap[$info[2]];

        $op = hash('sha256', 'image|' . $file_id . '|' . $sha256);
        $existing = $this->db->query("SELECT * FROM `".DB_PREFIX."handeldesk_operation` WHERE operation_id='".$this->db->escape($op)."' LIMIT 1");
        if ($existing->num_rows) {
            if ($existing->row['status'] === 'DONE') {
                $r = json_decode($existing->row['result_json'], true);
                if (is_array($r) && !empty($r['path'])) return $r;
            }
            throw new Exception('Image upload has PENDING operation; automatic retry blocked.', 409);
        }
        $this->db->query("INSERT INTO `".DB_PREFIX."handeldesk_operation` SET operation_id='".$this->db->escape($op)."',entity_type='image',status='PENDING',request_hash='".$this->db->escape($sha256)."',result_json='',date_added=NOW(),date_modified=NOW()");

        $base = pathinfo($filename, PATHINFO_FILENAME);
        $base = preg_replace('/[^A-Za-z0-9._-]+/', '-', $base);
        $base = trim($base, '.-_'); if ($base === '') $base = 'image';
        $base = substr($base, 0, 70);
        $dirRel = 'catalog/handeldesk/' . date('Y/m') . '/';
        $dirFull = DIR_IMAGE . $dirRel;
        if (!is_dir($dirFull) && !@mkdir($dirFull, 0755, true) && !is_dir($dirFull)) throw new Exception('Cannot create image directory', 500);
        $rel = $dirRel . substr($sha256, 0, 12) . '-' . $base . '.' . $ext;
        $full = DIR_IMAGE . $rel;
        if (is_file($full)) {
            if (hash_file('sha256', $full) !== $sha256) throw new Exception('Target image path collision', 409);
        } else {
            $tmp = $full . '.tmp-' . bin2hex(random_bytes(4));
            if (file_put_contents($tmp, $binary, LOCK_EX) !== strlen($binary)) { @unlink($tmp); throw new Exception('Cannot write image', 500); }
            @chmod($tmp, 0644);
            if (!@rename($tmp, $full)) { @unlink($tmp); throw new Exception('Cannot finalize image', 500); }
        }
        $result = array('file_id'=>$file_id,'path'=>$rel,'sha256'=>$sha256,'width'=>(int)$info[0],'height'=>(int)$info[1]);
        $enc = json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $this->db->query("UPDATE `".DB_PREFIX."handeldesk_operation` SET status='DONE',result_json='".$this->db->escape($enc)."',date_modified=NOW() WHERE operation_id='".$this->db->escape($op)."'");
        $this->audit('image', 0, 'upload', array('file_id'=>$file_id,'path'=>$rel,'sha256'=>$sha256));
        return $result;
    }

    private function actionSchema() {
        $language_id = (int)$this->config->get('config_language_id');
        $languages = array();
        $q = $this->db->query("SELECT language_id,name,code,status,sort_order FROM `" . DB_PREFIX . "language` WHERE status=1 ORDER BY sort_order,name");
        foreach ($q->rows as $row) $languages[] = $row;

        $stores = array(array('store_id'=>0,'name'=>$this->config->get('config_name')));
        $q = $this->db->query("SELECT store_id,name FROM `" . DB_PREFIX . "store` ORDER BY store_id");
        foreach ($q->rows as $row) $stores[] = $row;

        $tax_classes = $this->db->query("SELECT tax_class_id,title FROM `" . DB_PREFIX . "tax_class` ORDER BY title")->rows;
        $stock_statuses = $this->db->query("SELECT stock_status_id,name FROM `" . DB_PREFIX . "stock_status` WHERE language_id=" . $language_id . " ORDER BY name")->rows;
        $customer_groups = $this->db->query("SELECT customer_group_id,name FROM `" . DB_PREFIX . "customer_group_description` WHERE language_id=" . $language_id . " ORDER BY name")->rows;
        $weight_classes = $this->db->query("SELECT w.weight_class_id,wd.title,wd.unit,w.value FROM `" . DB_PREFIX . "weight_class` w LEFT JOIN `" . DB_PREFIX . "weight_class_description` wd ON (w.weight_class_id=wd.weight_class_id AND wd.language_id=".$language_id.") ORDER BY wd.title")->rows;
        $length_classes = $this->db->query("SELECT l.length_class_id,ld.title,ld.unit,l.value FROM `" . DB_PREFIX . "length_class` l LEFT JOIN `" . DB_PREFIX . "length_class_description` ld ON (l.length_class_id=ld.length_class_id AND ld.language_id=".$language_id.") ORDER BY ld.title")->rows;

        $options = array();
        $oq = $this->db->query("SELECT o.option_id,o.type,o.sort_order,od.name FROM `" . DB_PREFIX . "option` o LEFT JOIN `" . DB_PREFIX . "option_description` od ON (o.option_id=od.option_id AND od.language_id=".$language_id.") ORDER BY o.sort_order,od.name");
        foreach ($oq->rows as $o) {
            $o['values'] = $this->db->query("SELECT ov.option_value_id,ov.image,ov.sort_order,ovd.name FROM `" . DB_PREFIX . "option_value` ov LEFT JOIN `" . DB_PREFIX . "option_value_description` ovd ON (ov.option_value_id=ovd.option_value_id AND ovd.language_id=".$language_id.") WHERE ov.option_id=".(int)$o['option_id']." ORDER BY ov.sort_order,ovd.name")->rows;
            $options[] = $o;
        }

        $attribute_groups = $this->db->query("SELECT ag.attribute_group_id,ag.sort_order,agd.name FROM `" . DB_PREFIX . "attribute_group` ag LEFT JOIN `" . DB_PREFIX . "attribute_group_description` agd ON (ag.attribute_group_id=agd.attribute_group_id AND agd.language_id=".$language_id.") ORDER BY ag.sort_order,agd.name")->rows;
        $attributes = $this->db->query("SELECT a.attribute_id,a.attribute_group_id,a.sort_order,ad.name FROM `" . DB_PREFIX . "attribute` a LEFT JOIN `" . DB_PREFIX . "attribute_description` ad ON (a.attribute_id=ad.attribute_id AND ad.language_id=".$language_id.") ORDER BY a.attribute_group_id,a.sort_order,ad.name")->rows;

        return array('schema' => array(
            'protocol' => self::PROTOCOL,
            'opencart_version' => defined('VERSION') ? VERSION : '',
            'max_image_upload_bytes' => $this->maxImageUploadBytes(),
            'languages' => $languages,
            'stores' => $stores,
            'tax_classes' => $tax_classes,
            'stock_statuses' => $stock_statuses,
            'customer_groups' => $customer_groups,
            'weight_classes' => $weight_classes,
            'length_classes' => $length_classes,
            'options' => $options,
            'attribute_groups' => $attribute_groups,
            'attributes' => $attributes,
            'extension_adapters' => array(),
            'write_policy' => $this->writePolicy(),
            'features' => array(
                'snapshot'=>true,
                'safe_field_sync'=>true,
                'three_way_preview'=>true,
                'quantity_adjustments'=>true,
                'new_products'=>true,
                'copy_sections'=>true,
                'image_cache'=>true,
                'image_upload'=>true,
                'custom_extension_fields'=>false,
                'reference_editing'=>true,
                'stores'=>true,
                'related_products'=>true,
                'server_write_policy'=>true
            )
        ));
    }

    private function actionReference() {
        $categories = array();
        $q = $this->db->query("SELECT category_id FROM `" . DB_PREFIX . "category` ORDER BY category_id");
        foreach ($q->rows as $row) { $payload = $this->getCategoryPayload((int)$row['category_id']); if ($payload) $categories[] = $payload; }
        $manufacturers = array();
        $q = $this->db->query("SELECT manufacturer_id FROM `" . DB_PREFIX . "manufacturer` ORDER BY manufacturer_id");
        foreach ($q->rows as $row) { $payload = $this->getManufacturerPayload((int)$row['manufacturer_id']); if ($payload) $manufacturers[] = $payload; }
        return array('categories'=>$categories, 'manufacturers'=>$manufacturers);
    }

    private function actionSnapshot() {
        $page = isset($this->request->get['page']) ? max(1, (int)$this->request->get['page']) : 1;
        $per_page = isset($this->request->get['per_page']) ? (int)$this->request->get['per_page'] : 50;
        $per_page = max(1, min(100, $per_page));
        $offset = ($page - 1) * $per_page;
        $total = (int)$this->db->query("SELECT COUNT(*) total FROM `" . DB_PREFIX . "product`")->row['total'];
        $ids = $this->db->query("SELECT product_id FROM `" . DB_PREFIX . "product` ORDER BY product_id LIMIT " . $offset . "," . $per_page)->rows;
        $products = array();
        foreach ($ids as $row) {
            $payload = $this->getProductPayload((int)$row['product_id']);
            if ($payload) $products[] = $payload;
        }
        return array('page'=>$page,'per_page'=>$per_page,'total'=>$total,'has_more'=>($offset + count($ids) < $total),'products'=>$products);
    }

    private function inputJson() {
        $raw = file_get_contents('php://input');
        if ($raw === false || $raw === '') return array();
        $data = json_decode($raw, true);
        if (!is_array($data)) throw new Exception('Invalid JSON body', 400);
        return $data;
    }

    private function actionSyncPreview() {
        $payload = $this->inputJson();
        return $this->buildPreview($payload);
    }

    private function buildPreview($payload) {
        $items = isset($payload['products']) && is_array($payload['products']) ? $payload['products'] : array();
        $manufacturers = isset($payload['manufacturers']) && is_array($payload['manufacturers']) ? $payload['manufacturers'] : array();
        $categories = isset($payload['categories']) && is_array($payload['categories']) ? $payload['categories'] : array();
        $results = array(); $referenceResults = array(); $conflicts = 0; $warnings = 0;
        $tempManufacturers = array(); $tempCategories = array();
        foreach ($manufacturers as $m) {
            $id = isset($m['entity_id']) ? (int)$m['entity_id'] : (isset($m['temp_id']) ? (int)$m['temp_id'] : 0);
            if ($id < 0) $tempManufacturers[$id] = true;
            $r = $this->previewReference('manufacturer', $m); $referenceResults[] = $r;
            $conflicts += count($r['conflicts']); $warnings += count($r['warnings']);
        }
        foreach ($categories as $c) {
            $id = isset($c['entity_id']) ? (int)$c['entity_id'] : (isset($c['temp_id']) ? (int)$c['temp_id'] : 0);
            if ($id < 0) $tempCategories[$id] = true;
            $r = $this->previewReference('category', $c); $referenceResults[] = $r;
            $conflicts += count($r['conflicts']); $warnings += count($r['warnings']);
        }
        foreach ($categories as $c) {
            $parent = isset($c['local']['parent_id']) ? (int)$c['local']['parent_id'] : 0;
            if ($parent < 0 && !isset($tempCategories[$parent])) {
                $conflicts++; $referenceResults[] = array('entity_type'=>'category','entity_uuid'=>isset($c['entity_uuid'])?$c['entity_uuid']:'','entity_id'=>isset($c['entity_id'])?$c['entity_id']:null,'mode'=>'dependency','conflicts'=>array(array('path'=>'parent_id','reason'=>'Missing local parent category dependency '.$parent)),'warnings'=>array());
            }
        }
        $graphErrors = $this->categoryGraphErrors($categories);
        foreach ($graphErrors as $msg) {
            $conflicts++; $referenceResults[] = array('entity_type'=>'category','entity_uuid'=>'','entity_id'=>null,'mode'=>'graph','conflicts'=>array(array('path'=>'parent_id','reason'=>$msg)),'warnings'=>array());
        }
        foreach ($items as $item) {
            $r = $this->previewProduct($item);
            $mid = isset($item['local']['product']['manufacturer_id']) ? (int)$item['local']['product']['manufacturer_id'] : 0;
            if ($mid < 0 && !isset($tempManufacturers[$mid])) $r['conflicts'][] = array('path'=>'product.manufacturer_id','reason'=>'Missing local manufacturer dependency '.$mid);
            if (isset($item['local']['categories']) && is_array($item['local']['categories'])) foreach ($item['local']['categories'] as $cid) {
                $cid=(int)$cid; if ($cid<0 && !isset($tempCategories[$cid])) $r['conflicts'][]=array('path'=>'categories','reason'=>'Missing local category dependency '.$cid);
            }
            $results[] = $r; $conflicts += count($r['conflicts']); $warnings += count($r['warnings']);
        }
        $policyErrors = $this->writePolicyViolations($payload);
        return array(
            'product_count'=>count($items),'manufacturer_count'=>count($manufacturers),'category_count'=>count($categories),
            'new_manufacturer_count'=>count($tempManufacturers),'new_category_count'=>count($tempCategories),
            'conflict_count'=>$conflicts,'warning_count'=>$warnings,'results'=>$results,'reference_results'=>$referenceResults,
            'policy'=>$this->writePolicy(),'policy_errors'=>$policyErrors,'apply_allowed'=>($conflicts===0 && !$policyErrors)
        );
    }

    private function previewReference($type, $item) {
        $uuid = isset($item['entity_uuid']) ? (string)$item['entity_uuid'] : '';
        $id = isset($item['entity_id']) ? (int)$item['entity_id'] : (isset($item['temp_id']) ? (int)$item['temp_id'] : 0);
        $local = isset($item['local']) && is_array($item['local']) ? $item['local'] : array();
        $base = isset($item['base']) && is_array($item['base']) ? $item['base'] : array();
        $changes = isset($item['changes']) && is_array($item['changes']) ? $item['changes'] : array();
        $conflicts=array(); $warnings=array();
        if ($uuid==='') $conflicts[]=array('path'=>'__entity__','reason'=>'Missing entity_uuid');
        if ($id < 0) {
            $name = $this->referenceName($type, $local);
            if ($name==='') $conflicts[]=array('path'=>'name','reason'=>'Name is required');
            if ($type==='category') {
                $parent=isset($local['parent_id'])?(int)$local['parent_id']:0;
                if ($parent===$id) $conflicts[]=array('path'=>'parent_id','reason'=>'Category cannot be its own parent');
            }
            return array('entity_type'=>$type,'entity_uuid'=>$uuid,'entity_id'=>$id,'mode'=>'create_'.$type,'conflicts'=>$conflicts,'warnings'=>$warnings);
        }
        if ($id <= 0) {
            $conflicts[]=array('path'=>'__entity__','reason'=>'Invalid entity ID');
            return array('entity_type'=>$type,'entity_uuid'=>$uuid,'entity_id'=>$id,'mode'=>'update_'.$type,'conflicts'=>$conflicts,'warnings'=>$warnings);
        }
        $server = $type==='manufacturer' ? $this->getManufacturerPayload($id) : $this->getCategoryPayload($id);
        if (!$server) {
            $conflicts[]=array('path'=>'__entity__','reason'=>ucfirst($type).' no longer exists on server');
            return array('entity_type'=>$type,'entity_uuid'=>$uuid,'entity_id'=>$id,'mode'=>'update_'.$type,'conflicts'=>$conflicts,'warnings'=>$warnings);
        }
        $serverRevision=$server['revision']; unset($server['revision']);
        foreach ($changes as $ch) {
            $path=isset($ch['field_path'])?(string)$ch['field_path']:''; $op=isset($ch['operation_type'])?$ch['operation_type']:'set';
            if ($path==='__create__') continue;
            if ($op!=='set') { $conflicts[]=array('path'=>$path,'reason'=>'Unsupported reference operation: '.$op); continue; }
            $b=$this->pathGet($base,$path); $l=$this->pathGet($local,$path); $sv=$this->pathGet($server,$path);
            if ($this->same($sv,$b) || $this->same($sv,$l)) continue;
            $conflicts[]=array('path'=>$path,'reason'=>'Both local and server changed','base'=>$b,'local'=>$l,'server'=>$sv);
        }
        if ($this->referenceName($type,$local)==='') $conflicts[]=array('path'=>'name','reason'=>'Name is required');
        if ($type==='category') {
            $parent=isset($local['parent_id'])?(int)$local['parent_id']:0;
            if ($parent===$id) $conflicts[]=array('path'=>'parent_id','reason'=>'Category cannot be its own parent');
            if ($parent>0 && !$this->getCategoryPayload($parent)) $conflicts[]=array('path'=>'parent_id','reason'=>'Parent category does not exist');
        }
        return array('entity_type'=>$type,'entity_uuid'=>$uuid,'entity_id'=>$id,'mode'=>'update_'.$type,'server_revision'=>$serverRevision,'conflicts'=>$conflicts,'warnings'=>$warnings);
    }

    private function referenceName($type, $local) {
        if ($type==='manufacturer') return trim(isset($local['name'])?(string)$local['name']:'');
        if (!empty($local['name'])) return trim((string)$local['name']);
        $descs=isset($local['descriptions'])&&is_array($local['descriptions'])?$local['descriptions']:array();
        $lid=(string)$this->config->get('config_language_id');
        if (isset($descs[$lid]['name'])) return trim((string)$descs[$lid]['name']);
        foreach ($descs as $d) if (is_array($d) && !empty($d['name'])) return trim((string)$d['name']);
        return '';
    }

    private function categoryGraphErrors($payloadCategories) {
        if (!$payloadCategories) return array();
        $parents=array(); $starts=array();
        foreach ($this->db->query("SELECT category_id,parent_id FROM `".DB_PREFIX."category`")->rows as $r) $parents[(int)$r['category_id']]=(int)$r['parent_id'];
        foreach ($payloadCategories as $c) {
            $id=isset($c['entity_id'])?(int)$c['entity_id']:(isset($c['temp_id'])?(int)$c['temp_id']:0);
            if ($id!==0) { $parents[$id]=isset($c['local']['parent_id'])?(int)$c['local']['parent_id']:0; $starts[]=$id; }
        }
        $errors=array();
        foreach (array_unique($starts) as $start) {
            $seen=array(); $cur=$start; $guard=0;
            while ($cur!==0 && $guard++<10000) {
                if (isset($seen[$cur])) { $errors[]='Category parent cycle detected involving ID '.$cur; break; }
                $seen[$cur]=true;
                if (!array_key_exists($cur,$parents)) { $errors[]='Category parent references missing ID '.$cur; break; }
                $cur=(int)$parents[$cur];
            }
            if ($guard>=10000) $errors[]='Category graph is too deep or cyclic near ID '.$start;
        }
        return array_values(array_unique($errors));
    }

    private function previewProduct($item) {
        $entity_uuid = isset($item['entity_uuid']) ? (string)$item['entity_uuid'] : '';
        $product_id = isset($item['product_id']) && $item['product_id'] !== null ? (int)$item['product_id'] : 0;
        $changes = isset($item['changes']) && is_array($item['changes']) ? $item['changes'] : array();
        $local = isset($item['local']) && is_array($item['local']) ? $item['local'] : array();
        $base = isset($item['base']) && is_array($item['base']) ? $item['base'] : array();
        $warnings = array();
        $conflicts = array();

        if (!$entity_uuid) $conflicts[] = array('path'=>'__entity__','reason'=>'Missing entity_uuid');
        if (!$product_id) {
            $validation = $this->validateNewProduct($local);
            $conflicts = array_merge($conflicts, $validation['errors']);
            $warnings = array_merge($warnings, $validation['warnings']);
            return array('entity_uuid'=>$entity_uuid,'product_id'=>null,'mode'=>'create','conflicts'=>$conflicts,'warnings'=>$warnings);
        }

        $server = $this->getProductPayload($product_id);
        if (!$server) {
            $conflicts[] = array('path'=>'__entity__','reason'=>'Product no longer exists on server');
            return array('entity_uuid'=>$entity_uuid,'product_id'=>$product_id,'mode'=>'update','conflicts'=>$conflicts,'warnings'=>$warnings);
        }
        $server_rev = $server['revision'];
        unset($server['revision']);

        $has_set_qty = false; $has_adjust_qty = false;
        foreach ($changes as $ch) {
            $path = isset($ch['field_path']) ? $ch['field_path'] : '';
            $op = isset($ch['operation_type']) ? $ch['operation_type'] : 'set';
            if ($path === '__create__') continue;
            if ($path === 'product.quantity' && $op === 'set') $has_set_qty = true;
            if ($path === 'product.quantity' && $op === 'adjust') $has_adjust_qty = true;
            if (strpos($path, 'extension_fields') === 0) {
                $conflicts[] = array('path'=>$path,'reason'=>'No adapter installed for extension_fields');
                continue;
            }
            if ($op === 'adjust' && $path === 'product.quantity') continue;
            if ($op !== 'set') {
                $conflicts[] = array('path'=>$path,'reason'=>'Unsupported operation type: ' . $op);
                continue;
            }
            $b = $this->pathGet($base, $path);
            $l = $this->pathGet($local, $path);
            $s = $this->pathGet($server, $path);
            if ($this->same($s, $b) || $this->same($s, $l)) {
                continue;
            }
            $conflicts[] = array('path'=>$path,'reason'=>'Both local and server changed','base'=>$b,'local'=>$l,'server'=>$s);
        }
        if ($has_set_qty && $has_adjust_qty) {
            $conflicts[] = array('path'=>'product.quantity','reason'=>'Exact quantity set and relative adjustment cannot be mixed in one sync set');
        }
        $warnings = array_merge($warnings, $this->validateIdentifiersAndSeo($local, $product_id));
        $conflicts = array_merge($conflicts, $this->validateSeoConflicts($local, $product_id));
        return array('entity_uuid'=>$entity_uuid,'product_id'=>$product_id,'mode'=>'update','server_revision'=>$server_rev,'conflicts'=>$conflicts,'warnings'=>$warnings);
    }

    private function validateSeoConflicts($local, $exclude_product_id = 0) {
        $conflicts = array(); $seen = array();
        $seo = isset($local['seo_urls']) && is_array($local['seo_urls']) ? $local['seo_urls'] : array();
        foreach ($seo as $row) {
            if (!is_array($row)) continue;
            $keyword = trim(isset($row['keyword']) ? (string)$row['keyword'] : '');
            if ($keyword === '') continue;
            $key = strtolower($keyword);
            if (isset($seen[$key])) {
                $conflicts[] = array('path'=>'seo_urls','reason'=>'SEO keyword duplicated inside this product: '.$keyword);
                continue;
            }
            $seen[$key] = true;
            $query = 'product_id='.(int)$exclude_product_id;
            $sql = "SELECT query FROM `" . DB_PREFIX . "seo_url` WHERE keyword='" . $this->db->escape($keyword) . "'";
            if ($exclude_product_id) $sql .= " AND query<>'".$this->db->escape($query)."'";
            $sql .= " LIMIT 1";
            $q = $this->db->query($sql);
            if ($q->num_rows) $conflicts[] = array('path'=>'seo_urls','reason'=>'SEO keyword already exists: '.$keyword.' ('.$q->row['query'].')');
        }
        return $conflicts;
    }

    private function validateIdentifiersAndSeo($local, $exclude_product_id = 0) {
        $warnings = array();
        $core = isset($local['product']) && is_array($local['product']) ? $local['product'] : array();
        foreach (array('sku','jan','ean','upc','mpn') as $field) {
            $val = trim(isset($core[$field]) ? (string)$core[$field] : '');
            if ($val === '') continue;
            $sql = "SELECT product_id FROM `" . DB_PREFIX . "product` WHERE `" . $field . "`='" . $this->db->escape($val) . "'";
            if ($exclude_product_id) $sql .= " AND product_id<>" . (int)$exclude_product_id;
            $sql .= " LIMIT 1";
            $q = $this->db->query($sql);
            if ($q->num_rows) $warnings[] = array('path'=>'product.'.$field,'reason'=>strtoupper($field).' already exists on product #'.$q->row['product_id']);
        }
        return $warnings;
    }

    private function validateNewProduct($local) {
        $errors = array(); $warnings = array();
        $core = isset($local['product']) && is_array($local['product']) ? $local['product'] : array();
        $descs = isset($local['descriptions']) && is_array($local['descriptions']) ? $local['descriptions'] : array();
        $has_name = false;
        foreach ($descs as $d) if (is_array($d) && trim(isset($d['name']) ? $d['name'] : '') !== '') $has_name = true;
        if (!$has_name) $errors[] = array('path'=>'descriptions','reason'=>'At least one product name is required');
        if (trim(isset($core['model']) ? $core['model'] : '') === '') $warnings[] = array('path'=>'product.model','reason'=>'Model is empty');
        if (empty($local['categories'])) $warnings[] = array('path'=>'categories','reason'=>'No category selected');
        if (empty($core['manufacturer_id'])) $warnings[] = array('path'=>'product.manufacturer_id','reason'=>'No manufacturer selected');
        $warnings = array_merge($warnings, $this->validateIdentifiersAndSeo($local, 0));
        $errors = array_merge($errors, $this->validateSeoConflicts($local, 0));
        return array('errors'=>$errors,'warnings'=>$warnings);
    }

    private function actionSyncApply() {
        $payload = $this->inputJson();
        $this->assertWriteAllowed($payload, 'sync');
        $items = isset($payload['products']) && is_array($payload['products']) ? $payload['products'] : array();
        $manufacturers = isset($payload['manufacturers']) && is_array($payload['manufacturers']) ? $payload['manufacturers'] : array();
        $categories = isset($payload['categories']) && is_array($payload['categories']) ? $payload['categories'] : array();

        // Mandatory full preview immediately before any write.
        $previewResults = $this->previewPayload($payload);
        if ($previewResults['conflict_count'] > 0) throw new Exception('Apply blocked: conflicts detected. Run preview again.', 409);

        $id_map = array('manufacturers'=>array(), 'categories'=>array());
        $referenceResults = array();
        $newManufacturers=array(); $existingManufacturers=array();
        foreach ($manufacturers as $m) {
            $id=isset($m['entity_id'])?(int)$m['entity_id']:(isset($m['temp_id'])?(int)$m['temp_id']:0);
            if ($id<0) $newManufacturers[]=$m; else $existingManufacturers[]=$m;
        }
        $newCategories=array(); $existingCategories=array();
        foreach ($categories as $c) {
            $id=isset($c['entity_id'])?(int)$c['entity_id']:(isset($c['temp_id'])?(int)$c['temp_id']:0);
            if ($id<0) $newCategories[]=$c; else $existingCategories[]=$c;
        }

        // Create new manufacturer dependencies first.
        foreach ($newManufacturers as $m) {
            $tid=(int)$m['temp_id']; $created=$this->createManufacturerIdempotent($m); $id=(int)$created['id']; $id_map['manufacturers'][(string)$tid]=$id;
            $entity=$this->getManufacturerPayload($id);
            $referenceResults[]=array('ok'=>true,'entity_type'=>'manufacturer','entity_uuid'=>isset($m['entity_uuid'])?$m['entity_uuid']:'','entity_id'=>$id,'entity'=>$entity,'recovered_create'=>!empty($created['recovered']));
        }

        // New categories may depend on other new categories.
        $pending=$newCategories; $guard=0;
        while (count($pending) && $guard++<1000) {
            $progress=false;
            foreach ($pending as $k=>$c) {
                $parent=isset($c['local']['parent_id'])?(int)$c['local']['parent_id']:0;
                if ($parent<0 && !isset($id_map['categories'][(string)$parent])) continue;
                if ($parent<0) $c['local']['parent_id']=$id_map['categories'][(string)$parent];
                $tid=(int)$c['temp_id']; $created=$this->createCategoryIdempotent($c); $id=(int)$created['id']; $id_map['categories'][(string)$tid]=$id;
                $entity=$this->getCategoryPayload($id);
                $referenceResults[]=array('ok'=>true,'entity_type'=>'category','entity_uuid'=>isset($c['entity_uuid'])?$c['entity_uuid']:'','entity_id'=>$id,'entity'=>$entity,'recovered_create'=>!empty($created['recovered']));
                unset($pending[$k]); $progress=true;
            }
            if (!$progress) throw new Exception('Cannot resolve category dependency graph', 409);
        }

        // Resolve new local dependencies inside reference updates and product requests.
        foreach ($existingCategories as &$c) {
            if (isset($c['local']['parent_id'])) { $p=(int)$c['local']['parent_id']; if ($p<0 && isset($id_map['categories'][(string)$p])) $c['local']['parent_id']=$id_map['categories'][(string)$p]; }
            if (isset($c['changes']) && is_array($c['changes'])) foreach ($c['changes'] as &$ch) {
                if (isset($ch['field_path']) && $ch['field_path']==='parent_id' && isset($ch['after'])) { $v=(int)$ch['after']; if ($v<0 && isset($id_map['categories'][(string)$v])) $ch['after']=$id_map['categories'][(string)$v]; }
            } unset($ch);
        } unset($c);
        foreach ($items as &$item) {
            if (isset($item['local']['product']['manufacturer_id'])) { $mid=(int)$item['local']['product']['manufacturer_id']; if ($mid<0 && isset($id_map['manufacturers'][(string)$mid])) $item['local']['product']['manufacturer_id']=$id_map['manufacturers'][(string)$mid]; }
            if (isset($item['local']['categories']) && is_array($item['local']['categories'])) foreach ($item['local']['categories'] as &$cid) { $n=(int)$cid; if ($n<0 && isset($id_map['categories'][(string)$n])) $cid=$id_map['categories'][(string)$n]; } unset($cid);
            if (isset($item['changes']) && is_array($item['changes'])) foreach ($item['changes'] as &$ch) {
                if (!isset($ch['field_path'])) continue;
                if ($ch['field_path']==='product.manufacturer_id' && isset($ch['after'])) { $v=(int)$ch['after']; if ($v<0 && isset($id_map['manufacturers'][(string)$v])) $ch['after']=$id_map['manufacturers'][(string)$v]; }
                if ($ch['field_path']==='categories' && isset($ch['after']) && is_array($ch['after'])) foreach ($ch['after'] as &$v) { $n=(int)$v; if ($n<0 && isset($id_map['categories'][(string)$n])) $v=$id_map['categories'][(string)$n]; } unset($v);
            } unset($ch);
        } unset($item);

        // Existing reference objects use field-level merge against fresh server state.
        foreach ($existingManufacturers as $m) $referenceResults[]=$this->applyReferenceIdempotent('manufacturer',$m);
        foreach ($existingCategories as $c) $referenceResults[]=$this->applyReferenceIdempotent('category',$c);

        $results=array(); $success=0; $errors=0;
        foreach ($items as $item) {
            try { $result=$this->applyProductIdempotent($item); $results[]=$result; if (!empty($result['ok'])) $success++; else $errors++; }
            catch (Exception $e) { $errors++; $results[]=array('ok'=>false,'entity_uuid'=>isset($item['entity_uuid'])?$item['entity_uuid']:'','error'=>$e->getMessage()); }
        }
        foreach ($referenceResults as $rr) { if (empty($rr['ok'])) $errors++; else $success++; }
        return array('success_count'=>$success,'error_count'=>$errors,'id_map'=>$id_map,'reference_results'=>$referenceResults,'results'=>$results);
    }

    private function previewPayload($payload) {
        return $this->buildPreview($payload);
    }

    private function pathSet(&$data, $path, $value) {
        $parts=explode('.',(string)$path); $cur=&$data;
        foreach ($parts as $i=>$part) {
            if ($i===count($parts)-1) { $cur[$part]=$value; return; }
            if (!isset($cur[$part]) || !is_array($cur[$part])) $cur[$part]=array();
            $cur=&$cur[$part];
        }
    }

    private function replaceReferenceStores($type,$id,$stores) {
        $table=$type==='manufacturer'?'manufacturer_to_store':'category_to_store'; $idcol=$type.'_id';
        $this->db->query("DELETE FROM `".DB_PREFIX.$table."` WHERE `".$idcol."`=".(int)$id);
        if (!is_array($stores)) $stores=array();
        foreach (array_unique(array_map('intval',$stores)) as $sid) $this->db->query("INSERT IGNORE INTO `".DB_PREFIX.$table."` SET `".$idcol."`=".(int)$id.",store_id=".(int)$sid);
    }

    private function replaceReferenceSeo($type,$id,$rows) {
        $query=$type.'_id='.(int)$id;
        $this->db->query("DELETE FROM `".DB_PREFIX."seo_url` WHERE query='".$this->db->escape($query)."'");
        if (!is_array($rows)) return;
        foreach ($rows as $r) if (is_array($r) && trim(isset($r['keyword'])?(string)$r['keyword']:'')!=='') {
            $this->db->query("INSERT INTO `".DB_PREFIX."seo_url` SET store_id=".(int)(isset($r['store_id'])?$r['store_id']:0).",language_id=".(int)(isset($r['language_id'])?$r['language_id']:0).",query='".$this->db->escape($query)."',keyword='".$this->db->escape($r['keyword'])."'");
        }
    }

    private function categoryWouldCycle($category_id,$parent_id) {
        $category_id=(int)$category_id; $cur=(int)$parent_id; $seen=array(); $guard=0;
        while ($cur>0 && $guard++<10000) {
            if ($cur===$category_id || isset($seen[$cur])) return true;
            $seen[$cur]=true;
            $q=$this->db->query("SELECT parent_id FROM `".DB_PREFIX."category` WHERE category_id=".$cur." LIMIT 1");
            if (!$q->num_rows) return false;
            $cur=(int)$q->row['parent_id'];
        }
        return $guard>=10000;
    }

    private function categoryChain($category_id) {
        $chain=array(); $cur=(int)$category_id; $seen=array(); $guard=0;
        while ($cur>0 && $guard++<10000) {
            if (isset($seen[$cur])) throw new Exception('Category parent cycle detected while rebuilding paths',409);
            $seen[$cur]=true; array_unshift($chain,$cur);
            $q=$this->db->query("SELECT parent_id FROM `".DB_PREFIX."category` WHERE category_id=".$cur." LIMIT 1");
            if (!$q->num_rows) throw new Exception('Category missing while rebuilding paths',409);
            $cur=(int)$q->row['parent_id'];
        }
        if ($guard>=10000) throw new Exception('Category tree is too deep',409);
        return $chain;
    }

    private function rebuildCategorySubtreePaths($root_id) {
        // Discover descendants from the authoritative parent_id adjacency list,
        // not from category_path itself. This avoids propagating an already stale
        // path table when a category is moved.
        $children=array();
        foreach ($this->db->query("SELECT category_id,parent_id FROM `".DB_PREFIX."category`")->rows as $r) {
            $pid=(int)$r['parent_id']; if (!isset($children[$pid])) $children[$pid]=array(); $children[$pid][]=(int)$r['category_id'];
        }
        $ids=array(); $queue=array((int)$root_id); $seen=array(); $guard=0;
        while ($queue && $guard++<100000) {
            $cid=(int)array_shift($queue); if (isset($seen[$cid])) continue; $seen[$cid]=true; $ids[]=$cid;
            if (isset($children[$cid])) foreach ($children[$cid] as $child) $queue[]=(int)$child;
        }
        if ($guard>=100000) throw new Exception('Category subtree is too large or cyclic',409);
        foreach ($ids as $cid) {
            $chain=$this->categoryChain($cid);
            $this->db->query("DELETE FROM `".DB_PREFIX."category_path` WHERE category_id=".$cid);
            foreach ($chain as $level=>$path_id) $this->db->query("INSERT INTO `".DB_PREFIX."category_path` SET category_id=".$cid.",path_id=".(int)$path_id.",level=".(int)$level);
        }
    }

    private function saveManufacturerPayload($id,$payload) {
        $name=trim(isset($payload['name'])?(string)$payload['name']:''); if ($name==='') throw new Exception('Manufacturer name is required',409);
        $this->db->query("UPDATE `".DB_PREFIX."manufacturer` SET name='".$this->db->escape($name)."',image='".$this->db->escape(isset($payload['image'])?$payload['image']:'')."',sort_order=".(int)(isset($payload['sort_order'])?$payload['sort_order']:0)." WHERE manufacturer_id=".(int)$id);
        $this->replaceReferenceStores('manufacturer',$id,isset($payload['stores'])?$payload['stores']:array());
        $this->replaceReferenceSeo('manufacturer',$id,isset($payload['seo_urls'])?$payload['seo_urls']:array());
    }

    private function saveCategoryPayload($id,$payload) {
        $parent=(int)(isset($payload['parent_id'])?$payload['parent_id']:0); if ($parent===(int)$id || $this->categoryWouldCycle($id,$parent)) throw new Exception('Category parent would create a cycle',409);
        if ($parent>0) { $q=$this->db->query("SELECT category_id FROM `".DB_PREFIX."category` WHERE category_id=".$parent." LIMIT 1"); if (!$q->num_rows) throw new Exception('Parent category does not exist',409); }
        $old=$this->db->query("SELECT parent_id FROM `".DB_PREFIX."category` WHERE category_id=".(int)$id." LIMIT 1"); if (!$old->num_rows) throw new Exception('Category not found',404); $oldParent=(int)$old->row['parent_id'];
        $this->db->query("UPDATE `".DB_PREFIX."category` SET parent_id=".$parent.",image='".$this->db->escape(isset($payload['image'])?$payload['image']:'')."',top=".(int)(isset($payload['top'])?$payload['top']:0).",`column`=".max(1,(int)(isset($payload['column'])?$payload['column']:1)).",sort_order=".(int)(isset($payload['sort_order'])?$payload['sort_order']:0).",status=".(int)(isset($payload['status'])?$payload['status']:1).",date_modified=NOW() WHERE category_id=".(int)$id);
        $descs=isset($payload['descriptions'])&&is_array($payload['descriptions'])?$payload['descriptions']:array();
        if (!$descs) throw new Exception('At least one category description is required',409);
        $this->db->query("DELETE FROM `".DB_PREFIX."category_description` WHERE category_id=".(int)$id);
        $insertedDescriptions=0;
        foreach ($descs as $lid=>$d) if (is_array($d)) {
            $name=trim(isset($d['name'])?(string)$d['name']:''); if ($name==='') continue;
            $descStorage=$this->encodeEditorHtmlForStorage(isset($d['description'])?$d['description']:'',null);
            $this->db->query("INSERT INTO `".DB_PREFIX."category_description` SET category_id=".(int)$id.",language_id=".(int)$lid.",name='".$this->db->escape($name)."',description='".$this->db->escape($descStorage)."',meta_title='".$this->db->escape(isset($d['meta_title'])&&$d['meta_title']!==''?$d['meta_title']:$name)."',meta_description='".$this->db->escape(isset($d['meta_description'])?$d['meta_description']:'')."',meta_keyword='".$this->db->escape(isset($d['meta_keyword'])?$d['meta_keyword']:'')."'");
            $insertedDescriptions++;
        }
        if (!$insertedDescriptions) throw new Exception('At least one non-empty category description is required',409);
        $this->replaceReferenceStores('category',$id,isset($payload['stores'])?$payload['stores']:array());
        $this->replaceReferenceSeo('category',$id,isset($payload['seo_urls'])?$payload['seo_urls']:array());
        if ($oldParent!==$parent) $this->rebuildCategorySubtreePaths($id);
    }

    private function applyReferenceIdempotent($type,$item) {
        $uuid=isset($item['entity_uuid'])?(string)$item['entity_uuid']:''; $id=isset($item['entity_id'])?(int)$item['entity_id']:0;
        if (!$uuid || $id<=0) throw new Exception('Invalid reference update request',400);
        $op=hash('sha256','reference|'.$type.'|'.$uuid.'|'.json_encode($item,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
        $existing=$this->db->query("SELECT * FROM `".DB_PREFIX."handeldesk_operation` WHERE operation_id='".$this->db->escape($op)."' LIMIT 1");
        if ($existing->num_rows) { if ($existing->row['status']==='DONE') { $r=json_decode($existing->row['result_json'],true); if (is_array($r)) return $r; } throw new Exception('Reference update has PENDING operation; automatic retry blocked.',409); }
        $this->db->query("INSERT INTO `".DB_PREFIX."handeldesk_operation` SET operation_id='".$this->db->escape($op)."',entity_type='".$this->db->escape($type)."',status='PENDING',request_hash='".$this->db->escape($op)."',result_json='',date_added=NOW(),date_modified=NOW()");
        $this->db->query('START TRANSACTION');
        try {
            $server=$type==='manufacturer'?$this->getManufacturerPayload($id):$this->getCategoryPayload($id); if (!$server) throw new Exception(ucfirst($type).' not found',404); unset($server['revision']);
            $local=isset($item['local'])&&is_array($item['local'])?$item['local']:array(); $changes=isset($item['changes'])&&is_array($item['changes'])?$item['changes']:array();
            $merged=$server;
            foreach ($changes as $ch) { $path=isset($ch['field_path'])?(string)$ch['field_path']:''; if ($path===''||$path==='__create__') continue; if ((isset($ch['operation_type'])?$ch['operation_type']:'set')!=='set') throw new Exception('Unsupported reference operation',409); $this->pathSet($merged,$path,$this->pathGet($local,$path)); }
            if ($type==='manufacturer') $this->saveManufacturerPayload($id,$merged); else $this->saveCategoryPayload($id,$merged);
            $entity=$type==='manufacturer'?$this->getManufacturerPayload($id):$this->getCategoryPayload($id); if (!$entity) throw new Exception('Reference missing after apply',500);
            $result=array('ok'=>true,'entity_type'=>$type,'entity_uuid'=>$uuid,'entity_id'=>$id,'entity'=>$entity); $enc=json_encode($result,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
            $this->db->query("UPDATE `".DB_PREFIX."handeldesk_operation` SET status='DONE',result_json='".$this->db->escape($enc)."',date_modified=NOW() WHERE operation_id='".$this->db->escape($op)."'");
            $this->audit($type,$id,'update',array('entity_uuid'=>$uuid,'operation_id'=>$op,'changes'=>$changes)); $this->db->query('COMMIT'); return $result;
        } catch (Exception $e) { $this->db->query('ROLLBACK'); throw $e; }
    }

    private function createManufacturerIdempotent($item) {
        $uuid=isset($item['entity_uuid'])?(string)$item['entity_uuid']:''; $local=isset($item['local'])&&is_array($item['local'])?$item['local']:array();
        if ($uuid==='') throw new Exception('Manufacturer entity_uuid is required',400);
        // The create operation key is stable for the lifetime of this local entity.
        // Editing the draft after a lost HTTP response must never produce a second manufacturer.
        $op=hash('sha256','manufacturer-create|'.$uuid); $requestHash=hash('sha256',json_encode($local,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
        $existing=$this->db->query("SELECT * FROM `".DB_PREFIX."handeldesk_operation` WHERE operation_id='".$this->db->escape($op)."' LIMIT 1");
        if ($existing->num_rows) {
            if ($existing->row['status']==='DONE') { $r=json_decode($existing->row['result_json'],true); if(isset($r['manufacturer_id'])) return array('id'=>(int)$r['manufacturer_id'],'recovered'=>true); }
            throw new Exception('Manufacturer create is PENDING; automatic retry is blocked to prevent a duplicate. Check the Bridge audit.',409);
        }
        $name=trim(isset($local['name'])?(string)$local['name']:''); if ($name==='') throw new Exception('Manufacturer name is required',409);
        $this->db->query("INSERT INTO `".DB_PREFIX."handeldesk_operation` SET operation_id='".$this->db->escape($op)."',entity_type='manufacturer',status='PENDING',request_hash='".$this->db->escape($requestHash)."',result_json='',date_added=NOW(),date_modified=NOW()");
        $this->db->query('START TRANSACTION');
        try {
            $this->db->query("INSERT INTO `".DB_PREFIX."manufacturer` SET name='".$this->db->escape($name)."',image='".$this->db->escape(isset($local['image'])?$local['image']:'')."',sort_order=".(int)(isset($local['sort_order'])?$local['sort_order']:0));
            $id=(int)$this->db->getLastId(); $local['manufacturer_id']=$id; $this->saveManufacturerPayload($id,$local);
            $res=array('manufacturer_id'=>$id); $enc=json_encode($res,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
            $this->db->query("UPDATE `".DB_PREFIX."handeldesk_operation` SET status='DONE',result_json='".$this->db->escape($enc)."',date_modified=NOW() WHERE operation_id='".$this->db->escape($op)."'");
            $this->audit('manufacturer',$id,'create',array('entity_uuid'=>$uuid,'operation_id'=>$op)); $this->db->query('COMMIT');
            return array('id'=>$id,'recovered'=>false);
        } catch(Exception $e){$this->db->query('ROLLBACK');throw $e;}
    }

    private function createCategoryIdempotent($item) {
        $uuid=isset($item['entity_uuid'])?(string)$item['entity_uuid']:''; $local=isset($item['local'])&&is_array($item['local'])?$item['local']:array();
        if ($uuid==='') throw new Exception('Category entity_uuid is required',400);
        $op=hash('sha256','category-create|'.$uuid); $requestHash=hash('sha256',json_encode($local,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
        $existing=$this->db->query("SELECT * FROM `".DB_PREFIX."handeldesk_operation` WHERE operation_id='".$this->db->escape($op)."' LIMIT 1");
        if ($existing->num_rows) {
            if ($existing->row['status']==='DONE') { $r=json_decode($existing->row['result_json'],true); if(isset($r['category_id'])) return array('id'=>(int)$r['category_id'],'recovered'=>true); }
            throw new Exception('Category create is PENDING; automatic retry is blocked to prevent a duplicate. Check the Bridge audit.',409);
        }
        $name=$this->referenceName('category',$local); if ($name==='') throw new Exception('Category name is required',409); $parent=(int)(isset($local['parent_id'])?$local['parent_id']:0); if ($parent<0) throw new Exception('Unresolved local parent category',409);
        if ($parent>0) { $q=$this->db->query("SELECT category_id FROM `".DB_PREFIX."category` WHERE category_id=".$parent." LIMIT 1"); if(!$q->num_rows) throw new Exception('Parent category does not exist',409); }
        $this->db->query("INSERT INTO `".DB_PREFIX."handeldesk_operation` SET operation_id='".$this->db->escape($op)."',entity_type='category',status='PENDING',request_hash='".$this->db->escape($requestHash)."',result_json='',date_added=NOW(),date_modified=NOW()");
        $this->db->query('START TRANSACTION');
        try {
            $this->db->query("INSERT INTO `".DB_PREFIX."category` SET image='".$this->db->escape(isset($local['image'])?$local['image']:'')."',parent_id=".$parent.",top=".(int)(isset($local['top'])?$local['top']:0).",`column`=".max(1,(int)(isset($local['column'])?$local['column']:1)).",sort_order=".(int)(isset($local['sort_order'])?$local['sort_order']:0).",status=".(int)(isset($local['status'])?$local['status']:1).",date_added=NOW(),date_modified=NOW()");
            $id=(int)$this->db->getLastId(); $local['category_id']=$id; $this->saveCategoryPayload($id,$local); $this->rebuildCategorySubtreePaths($id);
            $res=array('category_id'=>$id); $enc=json_encode($res,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
            $this->db->query("UPDATE `".DB_PREFIX."handeldesk_operation` SET status='DONE',result_json='".$this->db->escape($enc)."',date_modified=NOW() WHERE operation_id='".$this->db->escape($op)."'");
            $this->audit('category',$id,'create',array('entity_uuid'=>$uuid,'operation_id'=>$op)); $this->db->query('COMMIT');
            return array('id'=>$id,'recovered'=>false);
        } catch(Exception $e){$this->db->query('ROLLBACK');throw $e;}
    }

    private function applyProductIdempotent($item) {
        $entity_uuid = isset($item['entity_uuid']) ? (string)$item['entity_uuid'] : '';
        if (!$entity_uuid) throw new Exception('Missing entity_uuid');
        $product_id = isset($item['product_id']) && $item['product_id'] !== null ? (int)$item['product_id'] : 0;
        $request_hash = hash('sha256', json_encode($item, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        $op_hash = $product_id ? hash('sha256', $entity_uuid . '|' . $request_hash) : hash('sha256', 'product-create|' . $entity_uuid);
        $existing = $this->db->query("SELECT * FROM `" . DB_PREFIX . "handeldesk_operation` WHERE operation_id='" . $this->db->escape($op_hash) . "' LIMIT 1");
        if ($existing->num_rows) {
            if ($existing->row['status'] === 'DONE') {
                $r = json_decode($existing->row['result_json'], true);
                if (is_array($r)) { if (!$product_id) $r['recovered_create']=true; return $r; }
            }
            throw new Exception(($product_id ? 'Previous update' : 'Product create') . ' is marked PENDING. Automatic retry is blocked to prevent duplicate changes. Check server audit first.',409);
        }

        $this->db->query("INSERT INTO `" . DB_PREFIX . "handeldesk_operation` SET operation_id='" . $this->db->escape($op_hash) . "', entity_type='product', status='PENDING', request_hash='" . $this->db->escape($request_hash) . "', result_json='', date_added=NOW(), date_modified=NOW()");
        $this->db->query("START TRANSACTION");
        try {
            if ($product_id) {
                $this->applyExistingProduct($product_id, $item);
            } else {
                $product_id = $this->createProduct($item['local']);
            }
            $server = $this->getProductPayload($product_id);
            if (!$server) throw new Exception('Product missing after apply');
            $result = array('ok'=>true,'entity_uuid'=>$entity_uuid,'product_id'=>$product_id,'product'=>$server,'recovered_create'=>false);
            $encoded = json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $this->db->query("UPDATE `" . DB_PREFIX . "handeldesk_operation` SET status='DONE', result_json='" . $this->db->escape($encoded) . "', date_modified=NOW() WHERE operation_id='" . $this->db->escape($op_hash) . "'");
            $this->audit('product', $product_id, isset($item['product_id']) && $item['product_id'] ? 'update' : 'create', array('entity_uuid'=>$entity_uuid,'operation_id'=>$op_hash));
            $this->db->query("COMMIT");
            return $result;
        } catch (Exception $e) {
            $this->db->query("ROLLBACK");
            // Keep PENDING deliberately. On non-transactional product tables a blind retry could double-apply quantity adjustments.
            throw $e;
        }
    }

    private function applyExistingProduct($product_id, $item) {
        $changes = isset($item['changes']) && is_array($item['changes']) ? $item['changes'] : array();
        $local = isset($item['local']) && is_array($item['local']) ? $item['local'] : array();
        foreach ($changes as $ch) {
            $path = isset($ch['field_path']) ? $ch['field_path'] : '';
            $op = isset($ch['operation_type']) ? $ch['operation_type'] : 'set';
            if ($path === '__create__') continue;
            if ($op === 'adjust' && $path === 'product.quantity') {
                $delta = (int)(isset($ch['after']) ? $ch['after'] : 0);
                $this->db->query("UPDATE `" . DB_PREFIX . "product` SET quantity=quantity+(" . $delta . "), date_modified=NOW() WHERE product_id=" . (int)$product_id);
                continue;
            }
            if ($op !== 'set') throw new Exception('Unsupported operation ' . $op);
            $value = $this->pathGet($local, $path);
            $this->applySetPath($product_id, $path, $value, $local);
        }
    }

    private function applySetPath($product_id, $path, $value, $local) {
        $parts = explode('.', $path);
        if ($parts[0] === 'product' && count($parts) === 2) {
            $field = $parts[1];
            if (!in_array($field, $this->allowed_product_fields, true)) throw new Exception('Product field not allowed: ' . $field);
            $sql = "UPDATE `" . DB_PREFIX . "product` SET `" . $field . "`=" . $this->sqlValue($field, $value) . ", date_modified=NOW() WHERE product_id=" . (int)$product_id;
            $this->db->query($sql);
            return;
        }
        if ($parts[0] === 'descriptions' && count($parts) === 3) {
            $language_id = (int)$parts[1]; $field = $parts[2];
            if (!in_array($field, $this->description_fields, true)) throw new Exception('Description field not allowed: '.$field);
            $this->ensureDescriptionRow($product_id, $language_id);
            $storageValue = (string)$value;
            if ($field === 'description') {
                $old = $this->db->query("SELECT description FROM `".DB_PREFIX."product_description` WHERE product_id=".(int)$product_id." AND language_id=".$language_id." LIMIT 1");
                $existingRaw = $old->num_rows ? $old->row['description'] : null;
                $storageValue = $this->encodeEditorHtmlForStorage($storageValue, $existingRaw);
            }
            $this->db->query("UPDATE `" . DB_PREFIX . "product_description` SET `" . $field . "`='" . $this->db->escape($storageValue) . "' WHERE product_id=" . (int)$product_id . " AND language_id=" . $language_id);
            $this->touchProduct($product_id); return;
        }
        if ($path === 'categories') { $this->replaceCategories($product_id, is_array($value)?$value:array()); return; }
        if ($path === 'stores') { $this->replaceStores($product_id, is_array($value)?$value:array()); return; }
        if ($path === 'related') { $this->replaceRelated($product_id, is_array($value)?$value:array()); return; }
        if ($path === 'images') { $this->replaceImages($product_id, is_array($value)?$value:array()); return; }
        if ($path === 'attributes') { $this->replaceAttributes($product_id, is_array($value)?$value:array()); return; }
        if ($path === 'options') { $this->replaceOptions($product_id, is_array($value)?$value:array()); return; }
        if ($path === 'discounts') { $this->replaceDiscounts($product_id, is_array($value)?$value:array()); return; }
        if ($path === 'specials') { $this->replaceSpecials($product_id, is_array($value)?$value:array()); return; }
        if ($path === 'seo_urls') { $this->replaceSeoUrls($product_id, is_array($value)?$value:array()); return; }
        throw new Exception('Unsupported sync path: ' . $path);
    }

    private function sqlValue($field, $value) {
        $ints = array('quantity','stock_status_id','manufacturer_id','shipping','points','tax_class_id','weight_class_id','length_class_id','subtract','minimum','sort_order','status');
        $floats = array('price','weight','length','width','height');
        if (in_array($field, $ints, true)) return (string)(int)$value;
        if (in_array($field, $floats, true)) return "'" . $this->db->escape((string)(float)str_replace(',', '.', (string)$value)) . "'";
        if ($field === 'date_available') {
            $v = trim((string)$value); if (!$v) $v = date('Y-m-d');
            return "'" . $this->db->escape($v) . "'";
        }
        return "'" . $this->db->escape((string)$value) . "'";
    }

    private function createProduct($local) {
        $validation = $this->validateNewProduct($local);
        if (count($validation['errors'])) throw new Exception($validation['errors'][0]['reason']);
        $core = isset($local['product']) && is_array($local['product']) ? $local['product'] : array();
        $defaults = array(
            'model'=>'','sku'=>'','upc'=>'','ean'=>'','jan'=>'','isbn'=>'','mpn'=>'','location'=>'','quantity'=>0,
            'stock_status_id'=>(int)$this->config->get('config_stock_status_id'),'image'=>'','manufacturer_id'=>0,'shipping'=>1,
            'price'=>'0','points'=>0,'tax_class_id'=>0,'date_available'=>date('Y-m-d'),'weight'=>'0','weight_class_id'=>(int)$this->config->get('config_weight_class_id'),
            'length'=>'0','width'=>'0','height'=>'0','length_class_id'=>(int)$this->config->get('config_length_class_id'),
            'subtract'=>1,'minimum'=>1,'sort_order'=>0,'status'=>0
        );
        $core = array_merge($defaults, $core);
        // New offline products are always created disabled unless explicitly enabled in the local final state.
        $fields = array();
        foreach ($this->allowed_product_fields as $f) $fields[] = "`".$f."`=".$this->sqlValue($f, isset($core[$f])?$core[$f]:$defaults[$f]);
        $this->db->query("INSERT INTO `" . DB_PREFIX . "product` SET " . implode(',', $fields) . ", date_added=NOW(), date_modified=NOW()");
        $product_id = (int)$this->db->getLastId();

        $descs = isset($local['descriptions']) && is_array($local['descriptions']) ? $local['descriptions'] : array();
        foreach ($descs as $language_id => $d) {
            if (!is_array($d)) continue;
            $descStorage = $this->encodeEditorHtmlForStorage(isset($d['description'])?$d['description']:'', null);
            $this->db->query("INSERT INTO `" . DB_PREFIX . "product_description` SET product_id=".$product_id.", language_id=".(int)$language_id.", name='".$this->db->escape(isset($d['name'])?$d['name']:'')."', description='".$this->db->escape($descStorage)."', tag='".$this->db->escape(isset($d['tag'])?$d['tag']:'')."', meta_title='".$this->db->escape(isset($d['meta_title'])?$d['meta_title']:'')."', meta_description='".$this->db->escape(isset($d['meta_description'])?$d['meta_description']:'')."', meta_keyword='".$this->db->escape(isset($d['meta_keyword'])?$d['meta_keyword']:'')."'");
        }
        $this->replaceCategories($product_id, isset($local['categories'])?$local['categories']:array());
        $this->replaceStores($product_id, isset($local['stores'])?$local['stores']:array(0));
        $this->replaceRelated($product_id, isset($local['related'])?$local['related']:array());
        $this->replaceImages($product_id, isset($local['images'])?$local['images']:array());
        $this->replaceAttributes($product_id, isset($local['attributes'])?$local['attributes']:array());
        $this->replaceOptions($product_id, isset($local['options'])?$local['options']:array());
        $this->replaceDiscounts($product_id, isset($local['discounts'])?$local['discounts']:array());
        $this->replaceSpecials($product_id, isset($local['specials'])?$local['specials']:array());
        $this->replaceSeoUrls($product_id, isset($local['seo_urls'])?$local['seo_urls']:array());
        return $product_id;
    }

    private function ensureDescriptionRow($product_id, $language_id) {
        $q = $this->db->query("SELECT product_id FROM `" . DB_PREFIX . "product_description` WHERE product_id=".(int)$product_id." AND language_id=".(int)$language_id." LIMIT 1");
        if (!$q->num_rows) {
            $this->db->query("INSERT INTO `" . DB_PREFIX . "product_description` SET product_id=".(int)$product_id.", language_id=".(int)$language_id.", name='',description='',tag='',meta_title='',meta_description='',meta_keyword=''");
        }
    }

    private function replaceCategories($product_id, $values) {
        $this->db->query("DELETE FROM `" . DB_PREFIX . "product_to_category` WHERE product_id=".(int)$product_id);
        foreach (array_unique(array_map('intval', $values)) as $cid) if ($cid > 0) $this->db->query("INSERT IGNORE INTO `" . DB_PREFIX . "product_to_category` SET product_id=".(int)$product_id.", category_id=".$cid);
        $this->touchProduct($product_id);
    }
    private function replaceStores($product_id, $values) {
        $this->db->query("DELETE FROM `" . DB_PREFIX . "product_to_store` WHERE product_id=".(int)$product_id);
        foreach (array_unique(array_map('intval', $values)) as $sid) $this->db->query("INSERT IGNORE INTO `" . DB_PREFIX . "product_to_store` SET product_id=".(int)$product_id.", store_id=".$sid);
        $this->touchProduct($product_id);
    }
    private function replaceRelated($product_id, $values) {
        $this->db->query("DELETE FROM `" . DB_PREFIX . "product_related` WHERE product_id=".(int)$product_id." OR related_id=".(int)$product_id);
        foreach (array_unique(array_map('intval', $values)) as $rid) if ($rid>0 && $rid!=$product_id) {
            $this->db->query("INSERT IGNORE INTO `" . DB_PREFIX . "product_related` SET product_id=".(int)$product_id.", related_id=".$rid);
            $this->db->query("INSERT IGNORE INTO `" . DB_PREFIX . "product_related` SET product_id=".$rid.", related_id=".(int)$product_id);
        }
        $this->touchProduct($product_id);
    }
    private function replaceImages($product_id, $values) {
        $this->db->query("DELETE FROM `" . DB_PREFIX . "product_image` WHERE product_id=".(int)$product_id);
        foreach ($values as $img) if (is_array($img) && !empty($img['image'])) {
            $this->db->query("INSERT INTO `" . DB_PREFIX . "product_image` SET product_id=".(int)$product_id.", image='".$this->db->escape($img['image'])."', sort_order=".(int)(isset($img['sort_order'])?$img['sort_order']:0));
        }
        $this->touchProduct($product_id);
    }
    private function replaceAttributes($product_id, $values) {
        $this->db->query("DELETE FROM `" . DB_PREFIX . "product_attribute` WHERE product_id=".(int)$product_id);
        foreach ($values as $a) if (is_array($a) && !empty($a['attribute_id'])) {
            $this->db->query("INSERT INTO `" . DB_PREFIX . "product_attribute` SET product_id=".(int)$product_id.", attribute_id=".(int)$a['attribute_id'].", language_id=".(int)(isset($a['language_id'])?$a['language_id']:0).", text='".$this->db->escape(isset($a['text'])?$a['text']:'')."'");
        }
        $this->touchProduct($product_id);
    }
    private function replaceOptions($product_id, $values) {
        $this->db->query("DELETE pov FROM `" . DB_PREFIX . "product_option_value` pov LEFT JOIN `" . DB_PREFIX . "product_option` po ON pov.product_option_id=po.product_option_id WHERE po.product_id=".(int)$product_id);
        $this->db->query("DELETE FROM `" . DB_PREFIX . "product_option` WHERE product_id=".(int)$product_id);
        foreach ($values as $o) if (is_array($o) && !empty($o['option_id'])) {
            $this->db->query("INSERT INTO `" . DB_PREFIX . "product_option` SET product_id=".(int)$product_id.", option_id=".(int)$o['option_id'].", value='".$this->db->escape(isset($o['value'])?$o['value']:'')."', required=".(int)(isset($o['required'])?$o['required']:0));
            $poid = (int)$this->db->getLastId();
            if (!empty($o['values']) && is_array($o['values'])) foreach ($o['values'] as $v) if (is_array($v) && !empty($v['option_value_id'])) {
                $this->db->query("INSERT INTO `" . DB_PREFIX . "product_option_value` SET product_option_id=".$poid.", product_id=".(int)$product_id.", option_id=".(int)$o['option_id'].", option_value_id=".(int)$v['option_value_id'].", quantity=".(int)(isset($v['quantity'])?$v['quantity']:0).", subtract=".(int)(isset($v['subtract'])?$v['subtract']:0).", price='".$this->db->escape(isset($v['price'])?$v['price']:'0')."', price_prefix='".$this->db->escape(isset($v['price_prefix'])?$v['price_prefix']:'+')."', points=".(int)(isset($v['points'])?$v['points']:0).", points_prefix='".$this->db->escape(isset($v['points_prefix'])?$v['points_prefix']:'+')."', weight='".$this->db->escape(isset($v['weight'])?$v['weight']:'0')."', weight_prefix='".$this->db->escape(isset($v['weight_prefix'])?$v['weight_prefix']:'+')."'");
            }
        }
        $this->touchProduct($product_id);
    }
    private function replaceDiscounts($product_id, $values) {
        $this->db->query("DELETE FROM `" . DB_PREFIX . "product_discount` WHERE product_id=".(int)$product_id);
        foreach ($values as $d) if (is_array($d)) $this->db->query("INSERT INTO `" . DB_PREFIX . "product_discount` SET product_id=".(int)$product_id.", customer_group_id=".(int)(isset($d['customer_group_id'])?$d['customer_group_id']:0).", quantity=".(int)(isset($d['quantity'])?$d['quantity']:1).", priority=".(int)(isset($d['priority'])?$d['priority']:1).", price='".$this->db->escape(isset($d['price'])?$d['price']:'0')."', date_start='".$this->db->escape(isset($d['date_start'])?$d['date_start']:'0000-00-00')."', date_end='".$this->db->escape(isset($d['date_end'])?$d['date_end']:'0000-00-00')."'");
        $this->touchProduct($product_id);
    }
    private function replaceSpecials($product_id, $values) {
        $this->db->query("DELETE FROM `" . DB_PREFIX . "product_special` WHERE product_id=".(int)$product_id);
        foreach ($values as $d) if (is_array($d)) $this->db->query("INSERT INTO `" . DB_PREFIX . "product_special` SET product_id=".(int)$product_id.", customer_group_id=".(int)(isset($d['customer_group_id'])?$d['customer_group_id']:0).", priority=".(int)(isset($d['priority'])?$d['priority']:1).", price='".$this->db->escape(isset($d['price'])?$d['price']:'0')."', date_start='".$this->db->escape(isset($d['date_start'])?$d['date_start']:'0000-00-00')."', date_end='".$this->db->escape(isset($d['date_end'])?$d['date_end']:'0000-00-00')."'");
        $this->touchProduct($product_id);
    }
    private function replaceSeoUrls($product_id, $values) {
        $query = 'product_id='.(int)$product_id;
        $this->db->query("DELETE FROM `" . DB_PREFIX . "seo_url` WHERE query='".$this->db->escape($query)."'");
        foreach ($values as $s) if (is_array($s) && isset($s['keyword']) && $s['keyword'] !== '') {
            $this->db->query("INSERT INTO `" . DB_PREFIX . "seo_url` SET store_id=".(int)(isset($s['store_id'])?$s['store_id']:0).", language_id=".(int)(isset($s['language_id'])?$s['language_id']:0).", query='".$this->db->escape($query)."', keyword='".$this->db->escape($s['keyword'])."'");
        }
        $this->touchProduct($product_id);
    }
    private function touchProduct($product_id) { $this->db->query("UPDATE `" . DB_PREFIX . "product` SET date_modified=NOW() WHERE product_id=".(int)$product_id); }

    private function getManufacturerPayload($manufacturer_id) {
        $q=$this->db->query("SELECT manufacturer_id,name,image,sort_order FROM `".DB_PREFIX."manufacturer` WHERE manufacturer_id=".(int)$manufacturer_id." LIMIT 1");
        if (!$q->num_rows) return null;
        $payload=$q->row;
        $payload['stores']=array_map(function($r){return (int)$r['store_id'];},$this->db->query("SELECT store_id FROM `".DB_PREFIX."manufacturer_to_store` WHERE manufacturer_id=".(int)$manufacturer_id." ORDER BY store_id")->rows);
        $payload['seo_urls']=$this->db->query("SELECT store_id,language_id,keyword FROM `".DB_PREFIX."seo_url` WHERE query='manufacturer_id=".(int)$manufacturer_id."' ORDER BY store_id,language_id")->rows;
        $payload['revision']=hash('sha256',json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
        return $payload;
    }

    private function getCategoryPayload($category_id) {
        $q=$this->db->query("SELECT category_id,parent_id,image,top,`column`,sort_order,status FROM `".DB_PREFIX."category` WHERE category_id=".(int)$category_id." LIMIT 1");
        if (!$q->num_rows) return null;
        $payload=$q->row; $descs=array();
        foreach ($this->db->query("SELECT language_id,name,description,meta_title,meta_description,meta_keyword FROM `".DB_PREFIX."category_description` WHERE category_id=".(int)$category_id." ORDER BY language_id")->rows as $r) { $lid=(string)$r['language_id']; unset($r['language_id']); if (isset($r['description'])) $r['description']=$this->decodeEditorHtml($r['description']); $descs[$lid]=$r; }
        $payload['descriptions']=$descs;
        $lid=(string)$this->config->get('config_language_id'); $payload['name']=isset($descs[$lid]['name'])?$descs[$lid]['name']:''; if ($payload['name']==='') foreach($descs as $d) if(!empty($d['name'])){$payload['name']=$d['name'];break;}
        $payload['stores']=array_map(function($r){return (int)$r['store_id'];},$this->db->query("SELECT store_id FROM `".DB_PREFIX."category_to_store` WHERE category_id=".(int)$category_id." ORDER BY store_id")->rows);
        $payload['seo_urls']=$this->db->query("SELECT store_id,language_id,keyword FROM `".DB_PREFIX."seo_url` WHERE query='category_id=".(int)$category_id."' ORDER BY store_id,language_id")->rows;
        $payload['revision']=hash('sha256',json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
        return $payload;
    }

    private function getProductPayload($product_id) {
        $q = $this->db->query("SELECT * FROM `" . DB_PREFIX . "product` WHERE product_id=".(int)$product_id." LIMIT 1");
        if (!$q->num_rows) return null;
        $product = $q->row;
        $descriptions = array();
        foreach ($this->db->query("SELECT * FROM `" . DB_PREFIX . "product_description` WHERE product_id=".(int)$product_id)->rows as $r) {
            $lid = (string)$r['language_id']; unset($r['product_id'],$r['language_id']);
            if (isset($r['description'])) $r['description'] = $this->decodeEditorHtml($r['description']);
            $descriptions[$lid] = $r;
        }
        $categories = array_map(function($r){return (int)$r['category_id'];}, $this->db->query("SELECT category_id FROM `" . DB_PREFIX . "product_to_category` WHERE product_id=".(int)$product_id." ORDER BY category_id")->rows);
        $stores = array_map(function($r){return (int)$r['store_id'];}, $this->db->query("SELECT store_id FROM `" . DB_PREFIX . "product_to_store` WHERE product_id=".(int)$product_id." ORDER BY store_id")->rows);
        $related = array_map(function($r){return (int)$r['related_id'];}, $this->db->query("SELECT related_id FROM `" . DB_PREFIX . "product_related` WHERE product_id=".(int)$product_id." ORDER BY related_id")->rows);
        $images = $this->db->query("SELECT image,sort_order FROM `" . DB_PREFIX . "product_image` WHERE product_id=".(int)$product_id." ORDER BY sort_order,product_image_id")->rows;
        $attributes = $this->db->query("SELECT attribute_id,language_id,text FROM `" . DB_PREFIX . "product_attribute` WHERE product_id=".(int)$product_id." ORDER BY attribute_id,language_id")->rows;
        $discounts = $this->db->query("SELECT customer_group_id,quantity,priority,price,date_start,date_end FROM `" . DB_PREFIX . "product_discount` WHERE product_id=".(int)$product_id." ORDER BY priority,price")->rows;
        $specials = $this->db->query("SELECT customer_group_id,priority,price,date_start,date_end FROM `" . DB_PREFIX . "product_special` WHERE product_id=".(int)$product_id." ORDER BY priority,price")->rows;
        $seo = $this->db->query("SELECT store_id,language_id,keyword FROM `" . DB_PREFIX . "seo_url` WHERE query='product_id=".(int)$product_id."' ORDER BY store_id,language_id")->rows;
        $options = array();
        $oq = $this->db->query("SELECT product_option_id,option_id,value,required FROM `" . DB_PREFIX . "product_option` WHERE product_id=".(int)$product_id." ORDER BY product_option_id");
        foreach ($oq->rows as $o) {
            $o['values'] = $this->db->query("SELECT option_value_id,quantity,subtract,price,price_prefix,points,points_prefix,weight,weight_prefix FROM `" . DB_PREFIX . "product_option_value` WHERE product_option_id=".(int)$o['product_option_id']." ORDER BY product_option_value_id")->rows;
            unset($o['product_option_id']); $options[] = $o;
        }
        // Normalise numeric primary key location and hide server-only timestamps from editable core.
        $payload = array(
            'product'=>$product,
            'descriptions'=>$descriptions,
            'categories'=>$categories,
            'stores'=>$stores,
            'related'=>$related,
            'images'=>$images,
            'attributes'=>$attributes,
            'options'=>$options,
            'discounts'=>$discounts,
            'specials'=>$specials,
            'seo_urls'=>$seo,
            'extension_fields'=>array()
        );
        $revision = hash('sha256', json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        $payload['revision'] = $revision;
        return $payload;
    }

    private function pathGet($data, $path) {
        $cur = $data;
        foreach (explode('.', $path) as $part) {
            if (!is_array($cur) || !array_key_exists($part, $cur)) return null;
            $cur = $cur[$part];
        }
        return $cur;
    }
    private function same($a, $b) { return json_encode($a, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) === json_encode($b, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); }

    private function audit($entity_type, $entity_id, $action, $details) {
        $label = (string)$this->config->get('module_handeldesk_bridge_device_label');
        $this->db->query("INSERT INTO `" . DB_PREFIX . "handeldesk_audit` SET device_label='".$this->db->escape($label)."', entity_type='".$this->db->escape($entity_type)."', entity_id=".(int)$entity_id.", action='".$this->db->escape($action)."', details_json='".$this->db->escape(json_encode($details, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES))."', date_added=NOW()");
    }
}
