<?php
$_['heading_title'] = 'HandelDesk Offline Bridge';
$_['text_extension'] = 'Расширения';
$_['text_success'] = 'Настройки HandelDesk сохранены.';
$_['text_edit'] = 'Настройки HandelDesk Offline Bridge';
$_['entry_status'] = 'Статус';
$_['entry_require_https'] = 'Требовать HTTPS';
$_['entry_token'] = 'Токен устройства';
$_['button_generate'] = 'Сгенерировать новый токен';
$_['help_token'] = 'Токен показывается только сразу после генерации. Скопируйте его в HandelDesk.';
$_['error_permission'] = 'Недостаточно прав для изменения HandelDesk Bridge.';
