<?php
$_['heading_title'] = 'HandelDesk Offline Bridge';
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'HandelDesk settings saved.';
$_['text_edit'] = 'HandelDesk Offline Bridge settings';
$_['entry_status'] = 'Status';
$_['entry_require_https'] = 'Require HTTPS';
$_['entry_token'] = 'Device token';
$_['button_generate'] = 'Generate new token';
$_['help_token'] = 'The token is only shown immediately after generation. Copy it into HandelDesk.';
$_['error_permission'] = 'You do not have permission to modify HandelDesk Bridge.';
