<?php
class ModelExtensionModuleHandeldeskBridge extends Model {
    public function installSchema() {
        $this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "handeldesk_operation` (
            `operation_id` varchar(64) NOT NULL,
            `entity_type` varchar(32) NOT NULL,
            `status` varchar(16) NOT NULL DEFAULT 'PENDING',
            `request_hash` varchar(64) NOT NULL DEFAULT '',
            `result_json` mediumtext NOT NULL,
            `date_added` datetime NOT NULL,
            `date_modified` datetime NOT NULL,
            PRIMARY KEY (`operation_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8");

        // Upgrade older preview schema if present.
        $cols = $this->db->query("SHOW COLUMNS FROM `" . DB_PREFIX . "handeldesk_operation`")->rows;
        $names = array(); foreach ($cols as $c) $names[] = $c['Field'];
        if (!in_array('status', $names)) $this->db->query("ALTER TABLE `" . DB_PREFIX . "handeldesk_operation` ADD `status` varchar(16) NOT NULL DEFAULT 'DONE' AFTER `entity_type`");
        if (!in_array('request_hash', $names)) $this->db->query("ALTER TABLE `" . DB_PREFIX . "handeldesk_operation` ADD `request_hash` varchar(64) NOT NULL DEFAULT '' AFTER `status`");
        if (!in_array('date_modified', $names)) $this->db->query("ALTER TABLE `" . DB_PREFIX . "handeldesk_operation` ADD `date_modified` datetime NOT NULL AFTER `date_added`");

        $this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "handeldesk_audit` (
            `audit_id` int(11) NOT NULL AUTO_INCREMENT,
            `device_label` varchar(128) NOT NULL,
            `entity_type` varchar(32) NOT NULL,
            `entity_id` int(11) NOT NULL DEFAULT '0',
            `action` varchar(64) NOT NULL,
            `details_json` mediumtext NOT NULL,
            `date_added` datetime NOT NULL,
            PRIMARY KEY (`audit_id`),
            KEY `entity` (`entity_type`,`entity_id`),
            KEY `date_added` (`date_added`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8");
    }
}
