<?php
class ControllerExtensionModuleHandeldeskBridge extends Controller {
    private $error = array();

    public function install() {
        if (!$this->user->hasPermission('modify', 'extension/module/handeldesk_bridge')) {
            return;
        }
        $this->load->model('extension/module/handeldesk_bridge');
        $this->model_extension_module_handeldesk_bridge->installSchema();
        $this->load->model('setting/setting');
        $this->model_setting_setting->editSetting('module_handeldesk_bridge', array(
            'module_handeldesk_bridge_status' => 0,
            'module_handeldesk_bridge_require_https' => 1,
            'module_handeldesk_bridge_token_hash' => '',
            'module_handeldesk_bridge_device_label' => 'HandelDesk Device',
            'module_handeldesk_bridge_write_mode' => 'read_only',
            'module_handeldesk_bridge_safe_product_id' => 0,
            'module_handeldesk_bridge_safe_allowed_paths' => ''
        ));
    }

    public function index() {
        $this->load->language('extension/module/handeldesk_bridge');
        $this->document->setTitle($this->language->get('heading_title'));
        $this->load->model('setting/setting');
        $this->load->model('extension/module/handeldesk_bridge');
        $this->model_extension_module_handeldesk_bridge->installSchema();

        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
            $post = $this->request->post;
            // Never accept a token hash from the browser form.
            $current_hash = $this->config->get('module_handeldesk_bridge_token_hash');
            $post['module_handeldesk_bridge_token_hash'] = $current_hash;
            $this->model_setting_setting->editSetting('module_handeldesk_bridge', $post);
            $this->session->data['success'] = $this->language->get('text_success');
            $this->response->redirect($this->url->link('extension/module/handeldesk_bridge', 'user_token=' . $this->session->data['user_token'], true));
        }

        $data['heading_title'] = $this->language->get('heading_title');
        $data['text_edit'] = $this->language->get('text_edit');
        $data['text_enabled'] = $this->language->get('text_enabled');
        $data['text_disabled'] = $this->language->get('text_disabled');
        $data['entry_status'] = $this->language->get('entry_status');
        $data['entry_require_https'] = $this->language->get('entry_require_https');
        $data['entry_token'] = $this->language->get('entry_token');
        $data['button_generate'] = $this->language->get('button_generate');
        $data['help_token'] = $this->language->get('help_token');
        $data['button_save'] = $this->language->get('button_save');
        $data['button_cancel'] = $this->language->get('button_cancel');
        $data['error_warning'] = isset($this->error['warning']) ? $this->error['warning'] : '';

        $data['action'] = $this->url->link('extension/module/handeldesk_bridge', 'user_token=' . $this->session->data['user_token'], true);
        $data['generate_token_url'] = $this->url->link('extension/module/handeldesk_bridge/generateToken', 'user_token=' . $this->session->data['user_token'], true);
        $data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true);

        foreach (array('status','require_https','device_label','write_mode','safe_product_id','safe_allowed_paths') as $key) {
            $full = 'module_handeldesk_bridge_' . $key;
            $data[$full] = isset($this->request->post[$full]) ? $this->request->post[$full] : $this->config->get($full);
        }
        if (!$data['module_handeldesk_bridge_write_mode']) $data['module_handeldesk_bridge_write_mode'] = 'read_only';
        if ($data['module_handeldesk_bridge_safe_product_id'] === null || $data['module_handeldesk_bridge_safe_product_id'] === '') $data['module_handeldesk_bridge_safe_product_id'] = 0;
        $data['token_configured'] = (bool)$this->config->get('module_handeldesk_bridge_token_hash');

        $data['breadcrumbs'] = array();
        $data['breadcrumbs'][] = array('text' => $this->language->get('text_home'), 'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true));
        $data['breadcrumbs'][] = array('text' => $this->language->get('text_extension'), 'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true));
        $data['breadcrumbs'][] = array('text' => $this->language->get('heading_title'), 'href' => $data['action']);
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput($this->load->view('extension/module/handeldesk_bridge', $data));
    }

    public function generateToken() {
        $this->response->addHeader('Content-Type: application/json');
        if ($this->request->server['REQUEST_METHOD'] !== 'POST') {
            $this->response->setOutput(json_encode(array('ok' => false, 'error' => 'POST required')));
            return;
        }
        if (!$this->user->hasPermission('modify', 'extension/module/handeldesk_bridge')) {
            $this->response->setOutput(json_encode(array('ok' => false, 'error' => 'Permission denied')));
            return;
        }
        try {
            $token = bin2hex(random_bytes(32));
        } catch (Exception $e) {
            $token = hash('sha256', uniqid('', true) . mt_rand() . microtime(true));
        }
        $this->load->model('setting/setting');
        $current = $this->model_setting_setting->getSetting('module_handeldesk_bridge');
        $current['module_handeldesk_bridge_token_hash'] = hash('sha256', $token);
        if (!isset($current['module_handeldesk_bridge_status'])) $current['module_handeldesk_bridge_status'] = 0;
        if (!isset($current['module_handeldesk_bridge_require_https'])) $current['module_handeldesk_bridge_require_https'] = 1;
        if (!isset($current['module_handeldesk_bridge_device_label'])) $current['module_handeldesk_bridge_device_label'] = 'HandelDesk Device';
        if (!isset($current['module_handeldesk_bridge_write_mode'])) $current['module_handeldesk_bridge_write_mode'] = 'read_only';
        if (!isset($current['module_handeldesk_bridge_safe_product_id'])) $current['module_handeldesk_bridge_safe_product_id'] = 0;
        if (!isset($current['module_handeldesk_bridge_safe_allowed_paths'])) $current['module_handeldesk_bridge_safe_allowed_paths'] = '';
        $this->model_setting_setting->editSetting('module_handeldesk_bridge', $current);
        $this->response->setOutput(json_encode(array('ok' => true, 'token' => $token)));
    }

    protected function validate() {
        if (!$this->user->hasPermission('modify', 'extension/module/handeldesk_bridge')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }
        if (isset($this->request->post['module_handeldesk_bridge_write_mode']) && !in_array($this->request->post['module_handeldesk_bridge_write_mode'], array('read_only','safe_test','live'), true)) {
            $this->error['warning'] = 'Invalid HandelDesk write mode.';
        }
        if (isset($this->request->post['module_handeldesk_bridge_safe_product_id']) && (int)$this->request->post['module_handeldesk_bridge_safe_product_id'] < 0) {
            $this->error['warning'] = 'SAFE TEST product ID must be zero or a positive product_id.';
        }
        return !$this->error;
    }
}
