package de.handeltheke.handeldesk.data.repo

import androidx.room.withTransaction
import de.handeltheke.handeldesk.data.local.*
import de.handeltheke.handeldesk.data.remote.BridgeClient
import de.handeltheke.handeldesk.domain.ProductJson
import kotlinx.serialization.json.*

class SnapshotRepository(
    private val db: HandelDeskDatabase,
    private val bridge: BridgeClient,
) {
    private class DeltaResetException : Exception()
    data class Progress(val current: Int, val total: Int, val message: String)

    data class RefreshSummary(
        val mode: String,
        val added: Int = 0,
        val updated: Int = 0,
        val deleted: Int = 0,
        val deferred: Int = 0,
        val downloaded: Int = 0,
        val cursor: Long? = null,
    ) {
        fun userText(): String = if (mode == "delta") {
            "Delta: +$added · обновлено $updated · удалено $deleted" +
                if (deferred > 0) " · отложено $deferred" else ""
        } else {
            "Full Snapshot: $downloaded товаров" +
                if (deferred > 0) " · локально изменённых сохранено $deferred" else ""
        }
    }

    suspend fun refresh(onProgress: suspend (Progress) -> Unit = {}): RefreshSummary {
        onProgress(Progress(0, 0, "Проверка Bridge"))
        val schemaRoot = bridge.get("schema")
        val schema = schemaRoot["schema"]?.jsonObject ?: error("Bridge schema отсутствует")
        val protocol = schema["protocol"]?.jsonPrimitive?.contentOrNull.orEmpty()
        require(protocol in setOf("0.4.1", "0.4.2")) { "Неподдерживаемый Bridge protocol: $protocol" }
        val features = schema["features"]?.jsonObject.orEmpty()
        val deltaSupported = protocol == "0.4.2" && features["delta_sync"]?.jsonPrimitive?.booleanOrNull == true
        val savedCursor = db.settings().get("delta_cursor")?.toLongOrNull()

        saveSchema(schema)
        refreshReferences()

        val summary = if (deltaSupported && savedCursor != null) {
            try {
                refreshDelta(savedCursor, onProgress)
            } catch (_: DeltaResetException) {
                db.settings().put(SettingEntity("delta_cursor", ""))
                onProgress(Progress(0, 0, "Delta-журнал сервера сброшен — выполняется новый Full Snapshot"))
                refreshFull(deltaSupported = true, onProgress = onProgress)
            }
        } else {
            if (!deltaSupported) db.settings().put(SettingEntity("delta_cursor", ""))
            refreshFull(deltaSupported, onProgress)
        }

        val now = System.currentTimeMillis()
        db.settings().put(SettingEntity("snapshot_at", now.toString()))
        db.settings().put(SettingEntity("last_refresh_mode", summary.mode))
        db.settings().put(SettingEntity("last_refresh_summary", summary.userText()))
        ensureSession(snapshotAt = now)
        db.audit().insert(AuditEventEntity(
            createdAt = now,
            eventType = if (summary.mode == "delta") "delta_sync" else "snapshot",
            source = "android",
            summary = summary.userText(),
        ))
        return summary
    }

    private suspend fun saveSchema(schema: JsonObject) = db.withTransaction {
        db.settings().put(SettingEntity("bridge_schema", schema.toString()))
        schema["languages"]?.jsonArray?.firstOrNull()?.jsonObject?.get("language_id")?.jsonPrimitive?.contentOrNull?.let {
            db.settings().put(SettingEntity("primary_language_id", it))
        }
    }

    private suspend fun refreshReferences() {
        val reference = bridge.get("reference")
        val categories = reference["categories"]?.jsonArray.orEmpty().mapNotNull { categoryEntity(it.jsonObject) }
        val manufacturers = reference["manufacturers"]?.jsonArray.orEmpty().mapNotNull { manufacturerEntity(it.jsonObject) }
        db.withTransaction {
            val safeCategories = categories.filter { incoming ->
                val current = db.references().categoryById(incoming.categoryId)
                current == null || current.state == "SYNCED"
            }
            val safeManufacturers = manufacturers.filter { incoming ->
                val current = db.references().manufacturerById(incoming.manufacturerId)
                current == null || current.state == "SYNCED"
            }
            db.references().putCategories(safeCategories)
            db.references().putManufacturers(safeManufacturers)
        }
    }

    private suspend fun refreshFull(deltaSupported: Boolean, onProgress: suspend (Progress) -> Unit): RefreshSummary {
        // Anchor first. Any server change that happens while the full snapshot is downloading
        // will be returned by the catch-up delta afterwards.
        val anchor = if (deltaSupported) {
            val root = bridge.get("delta", mapOf("anchor" to "1"))
            root["cursor"]?.jsonPrimitive?.longOrNull ?: 0L
        } else null

        var page = 1
        var received = 0
        var total = 0
        var deferred = 0
        do {
            val root = bridge.get("snapshot", mapOf("page" to page.toString(), "per_page" to "100"))
            total = root["total"]?.jsonPrimitive?.intOrNull ?: total
            val products = root["products"]?.jsonArray.orEmpty().mapNotNull { productEntity(it.jsonObject) }
            val safe = mutableListOf<ProductEntity>()
            products.forEach { incoming ->
                val current = incoming.productId?.let { db.products().getByProductId(it) }
                if (current == null || current.state == "SYNCED") safe += incoming else deferred++
            }
            db.products().putAll(safe)
            received += products.size
            onProgress(Progress(received, total, "Full Snapshot: товары $received / $total"))
            val more = root["has_more"]?.jsonPrimitive?.booleanOrNull == true
            page++
        } while (more)

        if (!deltaSupported || anchor == null) {
            return RefreshSummary(mode = "full", downloaded = received, deferred = deferred)
        }

        onProgress(Progress(0, 0, "Проверка изменений во время Snapshot"))
        val catchUp = refreshDelta(anchor, onProgress, saveMode = false)
        return RefreshSummary(
            mode = "full",
            added = catchUp.added,
            updated = catchUp.updated,
            deleted = catchUp.deleted,
            deferred = deferred + catchUp.deferred,
            downloaded = received,
            cursor = catchUp.cursor,
        )
    }

    private suspend fun refreshDelta(
        startCursor: Long,
        onProgress: suspend (Progress) -> Unit,
        saveMode: Boolean = true,
    ): RefreshSummary {
        var requestCursor = startCursor
        var finalServerCursor = startCursor
        var processed = 0
        var expected = 0
        var firstPage = true
        var added = 0
        var updated = 0
        var deleted = 0
        var deferred = 0

        do {
            val root = bridge.get("delta", mapOf("since" to requestCursor.toString(), "limit" to "100"))
            if (firstPage) {
                expected = root["total_changes"]?.jsonPrimitive?.intOrNull ?: 0
                firstPage = false
            }
            finalServerCursor = root["cursor"]?.jsonPrimitive?.longOrNull ?: finalServerCursor
            if (finalServerCursor < requestCursor) throw DeltaResetException()
            val events = root["events"]?.jsonArray.orEmpty()
            for (eventElement in events) {
                val event = eventElement.jsonObject
                val productId = event["product_id"]?.jsonPrimitive?.intOrNull ?: continue
                val isDeleted = event["deleted"]?.jsonPrimitive?.booleanOrNull == true
                if (isDeleted) {
                    val current = db.products().getByProductId(productId)
                    if (current != null) {
                        if (current.state == "SYNCED") {
                            db.queue().remove(current.uuid)
                            if (db.products().deleteServerSyncedById(productId) > 0) deleted++
                        } else {
                            deferred++
                            db.audit().insert(AuditEventEntity(
                                createdAt = System.currentTimeMillis(), eventType = "delta_deferred_delete",
                                entityType = "product", entityUuid = current.uuid, entityId = productId,
                                source = "android", summary = "Сервер удалил товар, но локальная версия изменена — удаление отложено"
                            ))
                        }
                    }
                } else {
                    val payload = event["product"]?.jsonObject ?: continue
                    val incoming = productEntity(payload) ?: continue
                    val current = db.products().getByProductId(productId)
                    when {
                        current == null -> { db.products().put(incoming); added++ }
                        current.state == "SYNCED" -> { db.products().put(incoming); updated++ }
                        else -> {
                            deferred++
                            db.audit().insert(AuditEventEntity(
                                createdAt = System.currentTimeMillis(), eventType = "delta_deferred_update",
                                entityType = "product", entityUuid = current.uuid, entityId = productId,
                                source = "android", summary = "Серверная версия изменилась, но локальные изменения сохранены для Three-way merge"
                            ))
                        }
                    }
                }
                processed++
                onProgress(Progress(processed, expected.coerceAtLeast(processed), "Delta Sync: $processed / ${expected.coerceAtLeast(processed)}"))
            }
            val hasMore = root["has_more"]?.jsonPrimitive?.booleanOrNull == true
            val next = root["next_cursor"]?.jsonPrimitive?.longOrNull ?: requestCursor
            if (hasMore && next <= requestCursor) error("Bridge Delta cursor не продвигается")
            requestCursor = next
        } while (hasMore)

        db.settings().put(SettingEntity("delta_cursor", finalServerCursor.toString()))
        if (saveMode) db.settings().put(SettingEntity("last_delta_cursor", finalServerCursor.toString()))
        return RefreshSummary(
            mode = "delta", added = added, updated = updated, deleted = deleted,
            deferred = deferred, cursor = finalServerCursor
        )
    }

    suspend fun ensureSession(snapshotAt: Long? = null): String {
        val existing = db.settings().get("active_session_id")
        if (!existing.isNullOrBlank()) return existing
        val id = java.util.UUID.randomUUID().toString()
        db.sessions().put(SessionEntity(id, "Рабочая сессия", snapshotAt, System.currentTimeMillis()))
        db.settings().put(SettingEntity("active_session_id", id))
        return id
    }

    private suspend fun primaryLanguageId(): String? = db.settings().get("primary_language_id")

    private suspend fun productEntity(source: JsonObject): ProductEntity? {
        val product = source["product"]?.jsonObject ?: return null
        val id = product["product_id"]?.jsonPrimitive?.intOrNull ?: return null
        val revision = source["revision"]?.jsonPrimitive?.contentOrNull.orEmpty()
        val payload = JsonObject(source.toMutableMap().apply { remove("revision") })
        val index = ProductJson.index(payload, primaryLanguageId())
        val now = System.currentTimeMillis()
        return ProductEntity(
            uuid = "server-product-$id", productId = id, baseRevision = revision,
            baseJson = payload.toString(), localJson = payload.toString(), state = "SYNCED", isDraft = false,
            name = index.name, model = index.model, sku = index.sku, jan = index.jan, price = index.price,
            quantity = index.quantity, manufacturerId = index.manufacturerId, status = index.status,
            searchNorm = index.searchNorm, updatedAt = now
        )
    }

    private fun categoryEntity(source: JsonObject): CategoryEntity? {
        val id = source["category_id"]?.jsonPrimitive?.intOrNull ?: return null
        val revision = source["revision"]?.jsonPrimitive?.contentOrNull.orEmpty()
        val payload = JsonObject(source.toMutableMap().apply { remove("revision") })
        return CategoryEntity(
            uuid = "server-category-$id", categoryId = id, baseRevision = revision,
            baseJson = payload.toString(), localJson = payload.toString(), state = "SYNCED",
            name = source["name"]?.jsonPrimitive?.contentOrNull.orEmpty(),
            parentId = source["parent_id"]?.jsonPrimitive?.intOrNull ?: 0,
            updatedAt = System.currentTimeMillis()
        )
    }

    private fun manufacturerEntity(source: JsonObject): ManufacturerEntity? {
        val id = source["manufacturer_id"]?.jsonPrimitive?.intOrNull ?: return null
        val revision = source["revision"]?.jsonPrimitive?.contentOrNull.orEmpty()
        val payload = JsonObject(source.toMutableMap().apply { remove("revision") })
        return ManufacturerEntity(
            uuid = "server-manufacturer-$id", manufacturerId = id, baseRevision = revision,
            baseJson = payload.toString(), localJson = payload.toString(), state = "SYNCED",
            name = source["name"]?.jsonPrimitive?.contentOrNull.orEmpty(), updatedAt = System.currentTimeMillis()
        )
    }
}
