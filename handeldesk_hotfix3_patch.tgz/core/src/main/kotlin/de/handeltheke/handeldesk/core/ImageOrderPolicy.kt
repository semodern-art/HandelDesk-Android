package de.handeltheke.handeldesk.core

/** A stable adjacent move; does not rename files or change the main-image slot. */
object ImageOrderPolicy {
    fun <T> move(items: List<T>, index: Int, delta: Int): List<T>? {
        if (delta == 0 || index !in items.indices || index + delta !in items.indices) return null
        val result = items.toMutableList()
        val target = index + delta
        val tmp = result[index]
        result[index] = result[target]
        result[target] = tmp
        return result
    }
}
