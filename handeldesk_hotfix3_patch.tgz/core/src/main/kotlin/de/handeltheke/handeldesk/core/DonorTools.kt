package de.handeltheke.handeldesk.core

data class ReplacementPreview(
    val before: String,
    val after: String,
    val replacements: Int,
)

object DonorTools {
    fun replaceText(source: String, oldValue: String, newValue: String, ignoreCase: Boolean = true): ReplacementPreview {
        if (oldValue.isBlank() || source.isEmpty()) return ReplacementPreview(source, source, 0)
        val regex = Regex(Regex.escape(oldValue), if (ignoreCase) setOf(RegexOption.IGNORE_CASE) else emptySet())
        var count = 0
        val result = regex.replace(source) {
            count++
            newValue
        }
        return ReplacementPreview(source, result, count)
    }

    /**
     * Applies several replacements to the ORIGINAL string in one pass.
     *
     * Important properties for donor cloning:
     * - values are atomic; they are never split into characters/tokens;
     * - replacements do not cascade (A->B together with B->C will not turn an original A into C);
     * - alphanumeric identifiers use token boundaries, so e.g. `2A` does not match inside `X2AB`;
     * - when candidates overlap, the longest source value wins, then the earlier row.
     */
    fun replaceManyAtomic(
        source: String,
        replacements: List<Pair<String, String>>,
        ignoreCase: Boolean = true,
    ): ReplacementPreview {
        if (source.isEmpty()) return ReplacementPreview(source, source, 0)
        val normalized = replacements.mapIndexedNotNull { index, (oldRaw, newRaw) ->
            val old = oldRaw.trim()
            val new = newRaw.trim()
            if (old.isBlank() || new.isBlank() || old.equals(new, ignoreCase = ignoreCase)) null
            else AtomicPair(index, old, new)
        }
        if (normalized.isEmpty()) return ReplacementPreview(source, source, 0)

        val candidates = mutableListOf<Candidate>()
        normalized.forEach { pair ->
            val options = if (ignoreCase) setOf(RegexOption.IGNORE_CASE) else emptySet()
            Regex(Regex.escape(pair.old), options).findAll(source).forEach { match ->
                val start = match.range.first
                val endExclusive = match.range.last + 1
                if (hasValidBoundaries(source, start, endExclusive, pair.old)) {
                    candidates += Candidate(start, endExclusive, pair.new, pair.old.length, pair.order)
                }
            }
        }
        if (candidates.isEmpty()) return ReplacementPreview(source, source, 0)

        val accepted = mutableListOf<Candidate>()
        candidates
            .sortedWith(compareBy<Candidate> { it.start }.thenByDescending { it.length }.thenBy { it.order })
            .forEach { candidate ->
                if (accepted.none { candidate.start < it.endExclusive && candidate.endExclusive > it.start }) {
                    accepted += candidate
                }
            }
        val ordered = accepted.sortedBy { it.start }
        if (ordered.isEmpty()) return ReplacementPreview(source, source, 0)

        val out = StringBuilder(source.length + ordered.sumOf { it.replacement.length - it.length })
        var cursor = 0
        ordered.forEach { candidate ->
            out.append(source, cursor, candidate.start)
            out.append(candidate.replacement)
            cursor = candidate.endExclusive
        }
        out.append(source, cursor, source.length)
        return ReplacementPreview(source, out.toString(), ordered.size)
    }

    /** A donor model is one atomic identifier and is never split by whitespace. */
    fun tokenPairs(oldValue: String, newValue: String): List<Pair<String, String>> {
        val oldAtomic = oldValue.trim()
        val newAtomic = newValue.trim()
        return if (oldAtomic.isBlank() || newAtomic.isBlank()) emptyList() else listOf(oldAtomic to newAtomic)
    }

    private fun hasValidBoundaries(source: String, start: Int, endExclusive: Int, old: String): Boolean {
        val first = old.firstOrNull() ?: return false
        val last = old.lastOrNull() ?: return false
        val leftOk = !first.isLetterOrDigit() || start == 0 || !source[start - 1].isLetterOrDigit()
        val rightOk = !last.isLetterOrDigit() || endExclusive >= source.length || !source[endExclusive].isLetterOrDigit()
        return leftOk && rightOk
    }

    private data class AtomicPair(val order: Int, val old: String, val new: String)
    private data class Candidate(
        val start: Int,
        val endExclusive: Int,
        val replacement: String,
        val length: Int,
        val order: Int,
    )
}
