package de.handeltheke.handeldesk.core

data class ReplacementPreview(
    val before: String,
    val after: String,
    val replacements: Int,
)

object DonorTools {
    fun replaceText(source: String, oldValue: String, newValue: String, ignoreCase: Boolean = true): ReplacementPreview {
        if (oldValue.isBlank() || source.isEmpty()) return ReplacementPreview(source, source, 0)
        val regex = Regex(Regex.escape(oldValue), if (ignoreCase) setOf(RegexOption.IGNORE_CASE) else emptySet())
        var count = 0
        val result = regex.replace(source) {
            count++
            newValue
        }
        return ReplacementPreview(source, result, count)
    }

    /**
     * A donor model is an atomic identifier. Never split it into whitespace tokens:
     * a suffix such as `A -> C` would otherwise replace every letter A in product text.
     */
    fun tokenPairs(oldValue: String, newValue: String): List<Pair<String, String>> {
        val oldAtomic = oldValue.trim()
        val newAtomic = newValue.trim()
        return if (oldAtomic.isBlank() || newAtomic.isBlank()) emptyList() else listOf(oldAtomic to newAtomic)
    }
}
