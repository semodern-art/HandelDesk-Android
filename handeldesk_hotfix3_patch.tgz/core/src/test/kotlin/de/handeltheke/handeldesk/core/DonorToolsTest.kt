package de.handeltheke.handeldesk.core

import kotlin.test.Test
import kotlin.test.assertEquals

class DonorToolsTest {
    @Test
    fun donorModelIsAtomicAndDoesNotReplaceSingleLetterSuffixes() {
        val oldModel = "EADP-40EB A"
        val newModel = "ECDP-40FB C"
        assertEquals(listOf(oldModel to newModel), DonorTools.tokenPairs(oldModel, newModel))

        val source = "Original Delta Electronics EADP-40EB A Netzteil Ladegerät Stromadapter 12V 3.34A"
        val result = DonorTools.tokenPairs(oldModel, newModel).fold(source) { text, (old, new) ->
            DonorTools.replaceText(text, old, new).after
        }
        assertEquals(
            "Original Delta Electronics ECDP-40FB C Netzteil Ladegerät Stromadapter 12V 3.34A",
            result,
        )
    }
}
