package de.handeltheke.handeldesk.core

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull

class ImageOrderPolicyTest {
    @Test fun swapsOnlyRequestedNeighbours() {
        assertEquals(listOf("image2", "image1", "image3"), ImageOrderPolicy.move(listOf("image1", "image2", "image3"), 0, 1))
        assertEquals(listOf("image1", "image3", "image2"), ImageOrderPolicy.move(listOf("image1", "image2", "image3"), 2, -1))
    }
    @Test fun refusesMovingBeyondAvailableImages() {
        assertNull(ImageOrderPolicy.move(listOf("image1", "image2"), 0, -1))
        assertNull(ImageOrderPolicy.move(listOf("image1", "image2"), 1, 1))
        assertNull(ImageOrderPolicy.move(emptyList<String>(), 0, 1))
    }
}
