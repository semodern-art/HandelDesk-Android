import de.handeltheke.handeldesk.core.*

fun main() {
    check(HandelthekeSeoPolicy.slug("Original Kärcher Ladegerät 5.5V 2A") == "original-karcher-ladegerat-5-5v-2a")
    check(HandelthekeSeoPolicy.slug("оригинальный пульт управления") == "originalnyj-pult-upravleniya")
    val q = SearchSyntax.parse("Samsung \"BN59-01232B RMCTPJ1AP2\" -analog model:BN59 OR model:BN60")
    check(q.errors.isEmpty())
    check(q.excluded.size == 1)
    check(q.positiveGroups.last().size == 2)
    check(ThreeWayMerge.compare(20, 22, 21).status == MergeStatus.CONFLICT)

    val donor = DonorTools.replaceManyAtomic(
        "Oceanic OCEALEDCC195W2 Netzteil Ladegerät Stromadapter 12V 2A",
        listOf("OCEALEDCC195W2" to "OCEALEDCC215W3", "2A" to "3A")
    )
    check(donor.after == "Oceanic OCEALEDCC215W3 Netzteil Ladegerät Stromadapter 12V 3A")
    val noCascade = DonorTools.replaceManyAtomic("A B", listOf("A" to "B", "B" to "C"))
    check(noCascade.after == "B C")
    val noInnerToken = DonorTools.replaceManyAtomic("X2AB 2A", listOf("2A" to "3A"))
    check(noInnerToken.after == "X2AB 3A")
    val regression = DonorTools.replaceManyAtomic(
        "Original Delta Electronics EADP-40EB A Netzteil Ladegerät Stromadapter 12V 3.34A",
        listOf("EADP-40EB A" to "ECDP-40FB C")
    )
    check(regression.after == "Original Delta Electronics ECDP-40FB C Netzteil Ladegerät Stromadapter 12V 3.34A")
    println("HandelDesk core smoke: OK")
}
