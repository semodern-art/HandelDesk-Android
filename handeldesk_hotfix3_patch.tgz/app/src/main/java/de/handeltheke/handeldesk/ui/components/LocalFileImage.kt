package de.handeltheke.handeldesk.ui.components

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import java.io.File
import kotlin.math.max

@Composable
fun LocalFileImage(path: String, modifier: Modifier = Modifier, size: Dp = 72.dp, contentScale: ContentScale = ContentScale.Crop) {
    val file = remember(path) { File(path) }
    val bitmap = remember(path, file.lastModified()) {
        file.takeIf { it.isFile }?.let { f ->
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.absolutePath, bounds)
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > 600) sample *= 2
            BitmapFactory.decodeFile(f.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample.coerceAtLeast(1) })
        }?.asImageBitmap()
    }
    if (bitmap != null) {
        Image(bitmap = bitmap, contentDescription = null, modifier = modifier.size(size), contentScale = contentScale)
    } else {
        Box(modifier.size(size).background(MaterialTheme.colorScheme.surfaceVariant))
    }
}
