package de.handeltheke.handeldesk.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import de.handeltheke.handeldesk.ui.ScreenHeader
import de.handeltheke.handeldesk.ui.components.SectionCard

@Composable
fun MoreScreen(onPrepare: () -> Unit, onSync: () -> Unit, onSettings: () -> Unit, onAudit: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Ещё", "Синхронизация, offline и служебные функции")
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SectionCard(Modifier.fillMaxWidth()) {
                Text("Работа с данными", style = MaterialTheme.typography.titleMedium)
                Button(onClick = onSync, modifier = Modifier.fillMaxWidth()) { Text("Синхронизация") }
                FilledTonalButton(onClick = onPrepare, modifier = Modifier.fillMaxWidth()) { Text("Offline / восстановление") }
            }
            SectionCard(Modifier.fillMaxWidth()) {
                Text("Система", style = MaterialTheme.typography.titleMedium)
                OutlinedButton(onClick = onAudit, modifier = Modifier.fillMaxWidth()) { Text("Audit Trail") }
                OutlinedButton(onClick = onSettings, modifier = Modifier.fillMaxWidth()) { Text("Настройки Bridge") }
            }
            Text("Все изменения сначала сохраняются локально и только затем отправляются на сервер.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
