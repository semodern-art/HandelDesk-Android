package de.handeltheke.handeldesk.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun StatusBadge(text: String, kind: String = "neutral") {
    val scheme = MaterialTheme.colorScheme
    val bg: Color
    val fg: Color
    when (kind) {
        "ok" -> { bg = scheme.tertiaryContainer; fg = scheme.onTertiaryContainer }
        "warn" -> { bg = scheme.secondaryContainer; fg = scheme.onSecondaryContainer }
        "error" -> { bg = scheme.errorContainer; fg = scheme.onErrorContainer }
        "primary" -> { bg = scheme.primaryContainer; fg = scheme.onPrimaryContainer }
        else -> { bg = scheme.surfaceVariant; fg = scheme.onSurfaceVariant }
    }
    Surface(color = bg, contentColor = fg, shape = MaterialTheme.shapes.small) {
        Text(text, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp))
    }
}

@Composable
fun SectionCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    ElevatedCard(modifier = modifier, elevation = CardDefaults.elevatedCardElevation(defaultElevation = 1.dp)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
    }
}

@Composable
fun EmptyState(title: String, body: String, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize().padding(28.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(body, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
