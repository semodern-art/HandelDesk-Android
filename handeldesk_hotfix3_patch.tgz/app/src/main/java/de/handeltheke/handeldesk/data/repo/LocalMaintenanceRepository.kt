package de.handeltheke.handeldesk.data.repo

import androidx.room.withTransaction
import de.handeltheke.handeldesk.data.local.AuditEventEntity
import de.handeltheke.handeldesk.data.local.HandelDeskDatabase
import de.handeltheke.handeldesk.data.local.ProductEntity
import de.handeltheke.handeldesk.domain.JsonTools
import de.handeltheke.handeldesk.domain.ProductJson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonPrimitive
import java.io.File

/**
 * Safe local cleanup tools.
 * Nothing here deletes a server product. Local drafts may only be removed while productId == null.
 */
class LocalMaintenanceRepository(
    private val db: HandelDeskDatabase,
    private val localPhotos: LocalPhotoRepository,
    private val history: ProductHistoryRepository,
) {


    suspend fun normalizeNewProductChanges(): Int = db.withTransaction {
        var removed = 0
        db.products().localNewProducts().forEach { product ->
            val pending = db.changes().pendingForEntity("product", product.uuid)
            if (pending.any { it.fieldPath == "__create__" }) {
                removed += db.changes().deleteRedundantNewProductChanges(product.uuid)
            }
        }
        removed
    }

    suspend fun deleteLocalProduct(uuid: String) {
        val product = db.products().get(uuid) ?: return
        require(product.productId == null) { "Товар уже существует на сервере. Удаление с сайта здесь запрещено." }

        val photos = db.photos().forProduct(uuid)
        localPhotos.returnOriginalsToInbox(photos)

        db.withTransaction {
            val current = db.products().get(uuid) ?: return@withTransaction
            require(current.productId == null) { "Товар уже получил server ID и больше не является локальным." }
            db.changes().deletePendingForEntity("product", uuid)
            db.queue().remove(uuid)
            db.photos().deleteForProduct(uuid)
            db.history().deleteForProduct(uuid)
            val removed = db.products().deleteLocalDraft(uuid)
            check(removed == 1) { "Не удалось удалить локальный товар" }
            db.audit().insert(
                AuditEventEntity(
                    createdAt = System.currentTimeMillis(),
                    eventType = "local_product_deleted",
                    entityType = "product",
                    entityUuid = uuid,
                    source = "android",
                    summary = "Локальный несинхронизированный товар удалён",
                )
            )
        }

        localPhotos.removeGalleryMarkers(photos)
        withContext(Dispatchers.IO) {
            photos.mapNotNull { row -> File(row.originalPath).parentFile?.parentFile }
                .distinctBy { it.absolutePath }
                .forEach { runCatching { it.deleteRecursively() } }
        }
    }

    suspend fun setProductChangesIncluded(uuid: String, changeIds: List<Long>, included: Boolean) {
        if (changeIds.isEmpty()) return
        val rows = changeIds.mapNotNull { db.changes().get(it) }
            .filter { !it.synced && it.entityType == "product" && it.entityUuid == uuid }
        if (rows.isEmpty() || rows.all { it.included == included }) return
        val historyId = history.captureCurrent(
            uuid,
            "change_included",
            if (included) "Включение изменений в Sync" else "Исключение изменений из Sync",
        )
        db.withTransaction {
            rows.forEach { row -> db.changes().setIncluded(row.id, included) }
            val product = db.products().get(uuid)
            db.audit().insert(
                AuditEventEntity(
                    createdAt = System.currentTimeMillis(),
                    sessionId = db.settings().get("active_session_id"),
                    eventType = "change_included",
                    entityType = "product",
                    entityUuid = uuid,
                    entityId = product?.productId,
                    source = "android",
                    summary = if (included) "Изменения включены в Sync" else "Изменения исключены из Sync",
                    detailsJson = kotlinx.serialization.json.buildJsonObject {
                        historyId?.let { put("history_id", it) }
                        put("included", included)
                        put("count", rows.size)
                    }.toString(),
                )
            )
        }
    }


    suspend fun discardOneProductChange(changeId: Long) {
        val initial = db.changes().get(changeId) ?: return
        val historyId = history.captureCurrent(initial.entityUuid, "discard_change", "Отмена локального изменения ${initial.fieldPath}")
        db.withTransaction {
        val change = db.changes().get(changeId) ?: return@withTransaction
        require(!change.synced) { "Изменение уже синхронизировано" }
        require(change.entityType == "product") { "Поддерживается только отмена изменений товара" }
        val product = db.products().get(change.entityUuid) ?: error("Товар не найден")
        require(product.productId != null) { "Для локального нового товара удалите товар целиком" }
        require(change.fieldPath != "__create__") { "Операцию создания нельзя удалить отдельно" }

        db.changes().delete(change.id)
        rebuildExistingProduct(product)
        db.audit().insert(
            AuditEventEntity(
                createdAt = System.currentTimeMillis(),
                eventType = "local_change_discarded",
                entityType = "product",
                entityUuid = product.uuid,
                entityId = product.productId,
                source = "android",
                summary = "Несинхронизированное изменение отменено: ${change.fieldPath}",
                detailsJson = kotlinx.serialization.json.buildJsonObject { historyId?.let { put("history_id", it) } }.toString(),
            )
        )
        }
    }

    suspend fun discardAllProductChanges(uuid: String) {
        val product = db.products().get(uuid) ?: return
        require(product.productId != null) { "Для локального нового товара удалите товар целиком" }
        val pending = db.changes().pendingForEntity("product", uuid)
        if (pending.isEmpty()) return
        val historyId = history.captureCurrent(uuid, "discard_all", "Отмена всех локальных изменений")
        val unsyncedPhotos = db.photos().forProduct(uuid).filter { it.status !in setOf("ATTACHED", "UPLOADED") }

        db.withTransaction {
            val current = db.products().get(uuid) ?: return@withTransaction
            require(current.productId != null) { "Товар больше не связан с сервером" }
            db.changes().deletePendingForEntity("product", uuid)
            db.photos().deleteDiscardableForProduct(uuid)
            restoreBase(current)
            db.audit().insert(
                AuditEventEntity(
                    createdAt = System.currentTimeMillis(),
                    eventType = "local_changes_discarded",
                    entityType = "product",
                    entityUuid = uuid,
                    entityId = current.productId,
                    source = "android",
                    summary = "Отменены все несинхронизированные изменения (${pending.size})",
                    detailsJson = kotlinx.serialization.json.buildJsonObject { historyId?.let { put("history_id", it) } }.toString(),
                )
            )
        }

        localPhotos.returnOriginalsToInbox(unsyncedPhotos)
        localPhotos.removeGalleryMarkers(unsyncedPhotos)
        // Keep private photo copies while the product history can still restore them.
        // They are removed only when the whole local product is permanently deleted.
    }

    /** Rebuild localJson from the last accepted server snapshot + the pending rows that remain. */
    private suspend fun rebuildExistingProduct(product: ProductEntity) {
        var payload = JsonTools.objectOf(product.baseJson)
        val remaining = db.changes().pendingForEntity("product", product.uuid)

        remaining.sortedWith(compareBy({ it.createdAt }, { it.id })).forEach { change ->
            when (change.operationType) {
                "set" -> {
                    val after = change.afterJson?.let { text ->
                        runCatching { JsonTools.json.parseToJsonElement(text) }.getOrElse { JsonPrimitive(text) }
                    } ?: JsonNull
                    payload = JsonTools.setPath(payload, change.fieldPath, after)
                }
                "adjust" -> {
                    if (change.fieldPath == "product.quantity") {
                        val current = JsonTools.path(payload, "product.quantity")?.jsonPrimitive?.intOrNull ?: 0
                        val delta = change.afterJson?.toIntOrNull() ?: 0
                        payload = JsonTools.setPath(payload, "product.quantity", JsonPrimitive(current + delta))
                    }
                }
            }
        }

        val index = ProductJson.index(payload, db.settings().get("primary_language_id"))
        db.products().put(
            product.copy(
                localJson = payload.toString(),
                state = if (remaining.isEmpty()) "SYNCED" else "MODIFIED",
                isDraft = false,
                name = index.name,
                model = index.model,
                sku = index.sku,
                jan = index.jan,
                price = index.price,
                quantity = index.quantity,
                manufacturerId = index.manufacturerId,
                status = index.status,
                searchNorm = index.searchNorm,
                updatedAt = System.currentTimeMillis(),
            )
        )
    }

    private suspend fun restoreBase(product: ProductEntity) {
        val payload = JsonTools.objectOf(product.baseJson)
        val index = ProductJson.index(payload, db.settings().get("primary_language_id"))
        db.products().put(
            product.copy(
                localJson = payload.toString(),
                state = "SYNCED",
                isDraft = false,
                name = index.name,
                model = index.model,
                sku = index.sku,
                jan = index.jan,
                price = index.price,
                quantity = index.quantity,
                manufacturerId = index.manufacturerId,
                status = index.status,
                searchNorm = index.searchNorm,
                updatedAt = System.currentTimeMillis(),
            )
        )
    }
}
