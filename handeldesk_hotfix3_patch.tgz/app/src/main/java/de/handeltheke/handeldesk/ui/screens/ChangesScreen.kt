package de.handeltheke.handeldesk.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import de.handeltheke.handeldesk.HandelDeskApp
import de.handeltheke.handeldesk.data.local.ChangeEntity
import de.handeltheke.handeldesk.data.local.ProductEntity
import de.handeltheke.handeldesk.domain.JsonTools
import de.handeltheke.handeldesk.ui.ScreenHeader
import de.handeltheke.handeldesk.ui.components.CachedProductImage
import de.handeltheke.handeldesk.ui.components.LocalFileImage
import kotlinx.coroutines.launch
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

private data class ChangeGroup(
    val key: String,
    val entityType: String,
    val entityUuid: String,
    val dayKey: String,
    val rows: List<ChangeEntity>,
    val product: ProductEntity?,
    val localImage: String?,
) {
    val included: Boolean get() = rows.all { it.included }
    val latest: Long get() = rows.maxOfOrNull { it.createdAt } ?: 0L
}

private sealed interface CleanupRequest {
    data class OneChange(val change: ChangeEntity, val productName: String) : CleanupRequest
    data class AllChanges(val productUuid: String, val productName: String) : CleanupRequest
    data class LocalProduct(val productUuid: String, val productName: String) : CleanupRequest
}

@Composable
fun ChangesScreen(onOpen: (String) -> Unit, onSync: () -> Unit, onAudit: () -> Unit) {
    val app = LocalContext.current.applicationContext as HandelDeskApp
    val changes by app.container.db.changes().observePending().collectAsState(initial = emptyList())
    val localPhotos by app.container.db.photos().observeAll().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var products by remember { mutableStateOf<Map<String, ProductEntity>>(emptyMap()) }
    val zone = remember { ZoneId.systemDefault() }
    var cleanupRequest by remember { mutableStateOf<CleanupRequest?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var cleanupBusy by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { app.container.maintenance.normalizeNewProductChanges() }

    LaunchedEffect(changes) {
        products = changes.asSequence().filter { it.entityType == "product" }.map { it.entityUuid }.distinct()
            .associateWith { app.container.db.products().get(it) }.mapNotNull { (k, v) -> v?.let { k to it } }.toMap()
    }

    val groups = remember(changes, products, localPhotos) {
        val localMain = localPhotos.groupBy { it.productUuid }.mapValues { (uuid, rows) ->
            val mainPath = products[uuid]?.localJson?.let { json ->
                JsonTools.objectOf(json)["product"]?.jsonObject?.get("image")?.jsonPrimitive?.contentOrNull.orEmpty()
            }.orEmpty()
            rows.firstOrNull { it.processedPath.isNotBlank() && it.remotePath == mainPath }?.processedPath
        }
        changes.groupBy { ch ->
            val day = Instant.ofEpochMilli(ch.createdAt).atZone(zone).toLocalDate().toString()
            "${ch.entityType}|${ch.entityUuid}|$day"
        }.map { (key, rows) ->
            val first = rows.first()
            ChangeGroup(
                key = key,
                entityType = first.entityType,
                entityUuid = first.entityUuid,
                dayKey = Instant.ofEpochMilli(first.createdAt).atZone(zone).toLocalDate().toString(),
                rows = rows.sortedWith(compareBy({ it.createdAt }, { it.id })),
                product = products[first.entityUuid],
                localImage = localMain[first.entityUuid],
            )
        }.sortedByDescending { it.latest }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(
            "Изменения",
            "Несинхронизировано: ${groups.size} групп · ${changes.size} операций"
        )
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.End,
        ) {
            OutlinedButton(onClick = onAudit) { Text("ЛОГ ДЕЙСТВИЙ") }
        }
        if (groups.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth().padding(24.dp)) {
                Text("✓ Все изменения синхронизированы")
            }
        } else {
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(groups, key = { it.key }) { group ->
                    ChangeGroupCard(
                        group = group,
                        onOpen = onOpen,
                        onIncluded = { included ->
                            scope.launch {
                                if (group.entityType == "product") {
                                    app.container.maintenance.setProductChangesIncluded(
                                        group.entityUuid,
                                        group.rows.map { it.id },
                                        included,
                                    )
                                } else {
                                    group.rows.forEach { app.container.db.changes().setIncluded(it.id, included) }
                                }
                            }
                        },
                        onDeleteOne = { change ->
                            val name = group.product?.name?.ifBlank { group.product.model }.orEmpty().ifBlank { "Товар" }
                            cleanupRequest = CleanupRequest.OneChange(change, name)
                        },
                        onDeleteAll = {
                            group.product?.let { product ->
                                val name = product.name.ifBlank { product.model }.ifBlank { "Товар" }
                                cleanupRequest = CleanupRequest.AllChanges(product.uuid, name)
                            }
                        },
                        onDeleteLocalProduct = {
                            group.product?.let { product ->
                                val name = product.name.ifBlank { product.model }.ifBlank { "Пустой локальный товар" }
                                cleanupRequest = CleanupRequest.LocalProduct(product.uuid, name)
                            }
                        },
                    )
                }
            }
        }
        Button(
            onClick = onSync,
            enabled = changes.any { it.included },
            modifier = Modifier.fillMaxWidth().padding(12.dp)
        ) { Text("ПРОВЕРИТЬ СИНХРОНИЗАЦИЮ") }
    }

    cleanupRequest?.let { request ->
        val (title, body, confirmText) = when (request) {
            is CleanupRequest.OneChange -> Triple(
                "Отменить изменение?",
                "Изменение «${changeTitle(request.change)}» будет удалено только локально, а карточка пересобрана от последней версии с сервера. На сайте ничего не удаляется.",
                "Отменить изменение",
            )
            is CleanupRequest.AllChanges -> Triple(
                "Отменить все изменения товара?",
                "Все несинхронизированные изменения «${request.productName}» будут отброшены, а локальная карточка вернётся к последней принятой версии с сервера. Локальные фото, которые ещё не были загружены, также выйдут из очереди; оригиналы из 02_Bearbeitet будут возвращены в 01_Eingang, когда это возможно. На сайте ничего не удаляется.",
                "Отменить все",
            )
            is CleanupRequest.LocalProduct -> Triple(
                "Удалить локальный товар?",
                "«${request.productName}» и его локальная очередь будут удалены с телефона. Оригиналы HandelDesk будут возвращены в 01_Eingang, когда это возможно; сами исходники не перекодируются и не удаляются. Если товар каким-то образом уже успел появиться на сайте, это действие его с сайта не удалит.",
                "Удалить локально",
            )
        }
        AlertDialog(
            onDismissRequest = { if (!cleanupBusy) cleanupRequest = null },
            title = { Text(title) },
            text = { Text(body) },
            confirmButton = {
                TextButton(
                    enabled = !cleanupBusy,
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
                    onClick = {
                        scope.launch {
                            cleanupBusy = true
                            runCatching {
                                when (request) {
                                    is CleanupRequest.OneChange -> app.container.maintenance.discardOneProductChange(request.change.id)
                                    is CleanupRequest.AllChanges -> app.container.maintenance.discardAllProductChanges(request.productUuid)
                                    is CleanupRequest.LocalProduct -> app.container.maintenance.deleteLocalProduct(request.productUuid)
                                }
                            }.onSuccess {
                                cleanupRequest = null
                            }.onFailure {
                                message = it.message ?: "Не удалось выполнить действие"
                            }
                            cleanupBusy = false
                        }
                    }
                ) { Text(if (cleanupBusy) "…" else confirmText) }
            },
            dismissButton = { TextButton(enabled = !cleanupBusy, onClick = { cleanupRequest = null }) { Text("Отмена") } },
        )
    }

    message?.let { text ->
        AlertDialog(
            onDismissRequest = { message = null },
            title = { Text("HandelDesk") },
            text = { Text(text) },
            confirmButton = { TextButton(onClick = { message = null }) { Text("OK") } },
        )
    }
}

@Composable
private fun ChangeGroupCard(
    group: ChangeGroup,
    onOpen: (String) -> Unit,
    onIncluded: (Boolean) -> Unit,
    onDeleteOne: (ChangeEntity) -> Unit,
    onDeleteAll: () -> Unit,
    onDeleteLocalProduct: () -> Unit,
) {
    var expanded by remember(group.key) { mutableStateOf(false) }
    val product = group.product
    val remoteImage = remember(product?.localJson) {
        product?.localJson?.let { JsonTools.objectOf(it)["product"]?.jsonObject?.get("image")?.jsonPrimitive?.contentOrNull }.orEmpty()
    }
    val dateFmt = remember { DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm") }
    val zone = remember { ZoneId.systemDefault() }

    Card(Modifier.fillMaxWidth().clickable { expanded = !expanded }) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Checkbox(group.included, onCheckedChange = onIncluded)
                if (group.entityType == "product") {
                    if (!group.localImage.isNullOrBlank()) LocalFileImage(group.localImage, size = 58.dp)
                    else if (remoteImage.isNotBlank()) CachedProductImage(remoteImage, size = 58.dp)
                    else Surface(Modifier.size(58.dp), color = MaterialTheme.colorScheme.surfaceVariant) {}
                }
                Column(Modifier.weight(1f)) {
                    Text(product?.name?.ifBlank { product.model }.orEmpty().ifBlank { group.entityType }, style = MaterialTheme.typography.titleSmall)
                    if (product != null) Text(product.model, style = MaterialTheme.typography.bodySmall)
                    val latest = Instant.ofEpochMilli(group.latest).atZone(zone)
                    Text(
                        "${group.rows.size} ${changeWord(group.rows.size)} · ${dateFmt.format(latest)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text(if (expanded) "⌃" else "⌄")
            }
            if (expanded) {
                HorizontalDivider()
                group.rows.forEach { ch ->
                    val dt = Instant.ofEpochMilli(ch.createdAt).atZone(zone)
                    Column(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                        Text(changeTitle(ch), style = MaterialTheme.typography.bodyMedium)
                        Text(
                            "${dateFmt.format(dt)} · ${ch.operationType}${changeValue(ch)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (group.entityType == "product" && product?.productId != null && ch.fieldPath != "__create__") {
                            TextButton(
                                onClick = { onDeleteOne(ch) },
                                contentPadding = PaddingValues(0.dp),
                                colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
                            ) { Text("Удалить это несинхронизированное изменение") }
                        }
                    }
                }
                if (group.entityType == "product") {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { onOpen(group.entityUuid) }) { Text("Открыть товар") }
                    }
                    if (product?.productId == null) {
                        TextButton(
                            onClick = onDeleteLocalProduct,
                            colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
                        ) { Text("Удалить локальный товар целиком") }
                    } else if (product != null) {
                        TextButton(
                            onClick = onDeleteAll,
                            colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
                        ) { Text("Отменить ВСЕ несинхронизированные изменения товара") }
                    }
                }
            }
        }
    }
}

private fun changeTitle(ch: ChangeEntity): String = when {
    ch.fieldPath == "__create__" -> "Создание товара"
    ch.fieldPath == "product.quantity" && ch.operationType == "adjust" -> "Изменение количества"
    ch.fieldPath == "product.image" -> "Главное фото"
    ch.fieldPath == "images" -> "Дополнительные фото"
    ch.fieldPath.startsWith("descriptions.") && ch.fieldPath.endsWith(".name") -> "Название товара"
    ch.fieldPath == "product.price" -> "Цена"
    ch.fieldPath == "categories" -> "Категории"
    ch.fieldPath == "product.manufacturer_id" -> "Производитель"
    else -> ch.fieldPath
}

private fun changeValue(ch: ChangeEntity): String {
    val value = ch.afterJson.orEmpty().replace("\n", " ").take(80)
    return if (value.isBlank() || ch.fieldPath == "__create__") "" else " · $value"
}

private fun changeWord(count: Int): String = when {
    count % 10 == 1 && count % 100 != 11 -> "изменение"
    count % 10 in 2..4 && count % 100 !in 12..14 -> "изменения"
    else -> "изменений"
}
