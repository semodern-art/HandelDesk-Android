package de.handeltheke.handeldesk.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged

private class DraftState(initial: String) {
    var text by mutableStateOf(initial)
    var sourceValue by mutableStateOf(initial)
    var dirty by mutableStateOf(false)
    var focused by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
}

/**
 * Local text remains independent of Room/Flow recompositions while being edited.
 * Every change is scheduled to an application-lived queue; blur or disposal forces
 * an immediate save, so scrolling or leaving a card cannot cancel the write.
 */
@Composable
fun AutoSaveField(
    value: String,
    label: String,
    onSave: suspend (String) -> Unit,
    modifier: Modifier = Modifier,
    singleLine: Boolean = true,
    minLines: Int = 1,
    onLocalChange: (String) -> Unit = {},
    saveKey: String,
) {
    val draft = remember(saveKey) { DraftState(value) }
    val latestSaver by rememberUpdatedState(onSave)

    LaunchedEffect(value, saveKey) {
        // Apply external changes only once they really change. Never reset a draft
        // merely because the focus/dirty flag changed before Room emits its update.
        if (draft.sourceValue != value) {
            draft.sourceValue = value
            if (!draft.dirty && !draft.focused) draft.text = value
        }
    }

    fun saveNow(immediate: Boolean) {
        if (!draft.dirty) return
        AutoSaveCoordinator.submit(
            key = saveKey,
            text = draft.text,
            immediate = immediate,
            save = latestSaver,
            completed = { saved, failure ->
                if (draft.text == saved) {
                    draft.error = failure?.message ?: if (failure != null) "Ошибка сохранения" else null
                    if (failure == null) draft.dirty = false
                }
            },
        )
    }

    DisposableEffect(saveKey) {
        onDispose { saveNow(immediate = true) }
    }

    Column(modifier = modifier) {
        OutlinedTextField(
            value = draft.text,
            onValueChange = { entered ->
                draft.text = entered
                draft.dirty = true
                draft.error = null
                onLocalChange(entered)
                saveNow(immediate = false)
            },
            label = { Text(label) },
            modifier = Modifier.fillMaxWidth().onFocusChanged { focus ->
                if (draft.focused && !focus.isFocused) saveNow(immediate = true)
                draft.focused = focus.isFocused
            },
            singleLine = singleLine,
            minLines = minLines,
            isError = draft.error != null,
        )
        if (draft.error != null) {
            Text("Не сохранено: ${draft.error}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
            TextButton(onClick = { saveNow(immediate = true) }) { Text("Повторить сохранение") }
        }
    }
}
