package de.handeltheke.handeldesk.data.repo

import androidx.room.withTransaction
import de.handeltheke.handeldesk.core.DonorTools
import de.handeltheke.handeldesk.core.HandelthekeSeoPolicy
import de.handeltheke.handeldesk.data.local.*
import de.handeltheke.handeldesk.domain.JsonTools
import de.handeltheke.handeldesk.domain.ProductJson
import kotlinx.serialization.json.*
import java.util.UUID

class ProductEditorRepository(private val db: HandelDeskDatabase, private val history: ProductHistoryRepository) {
    suspend fun updateField(
        uuid: String,
        path: String,
        value: JsonElement,
        recordHistory: Boolean = true,
        auditChange: Boolean = true,
    ): Boolean {
        val beforeEntity = db.products().get(uuid) ?: error("Товар не найден")
        val beforeLocal = JsonTools.objectOf(beforeEntity.localJson)
        val beforeValue = JsonTools.path(beforeLocal, path) ?: JsonNull
        if (beforeValue == value) return false
        val historyId = if (recordHistory) history.captureCurrent(uuid, "product_field", "Изменение ${friendlyPath(path)}") else null

        return db.withTransaction {
            val entity = db.products().get(uuid) ?: error("Товар не найден")
            val local = JsonTools.objectOf(entity.localJson)
            val before = JsonTools.path(local, path) ?: JsonNull
            if (before == value) return@withTransaction false
            var updated = JsonTools.setPath(local, path, value)
            if (entity.productId == null && path.startsWith("descriptions.") && path.endsWith(".name")) {
                val parts = path.split('.')
                val languageId = parts.getOrNull(1)?.toIntOrNull() ?: 1
                val rows = (updated["seo_urls"] as? JsonArray).orEmpty().toMutableList()
                val existingIndex = rows.indexOfFirst { it.jsonObject["language_id"]?.jsonPrimitive?.intOrNull == languageId && (it.jsonObject["store_id"]?.jsonPrimitive?.intOrNull ?: 0) == 0 }
                val existingKeyword = existingIndex.takeIf { it >= 0 }?.let { rows[it].jsonObject["keyword"]?.jsonPrimitive?.contentOrNull }.orEmpty()
                if (existingKeyword.isBlank()) {
                    val keyword = HandelthekeSeoPolicy.slug(value.jsonPrimitive.contentOrNull.orEmpty())
                    val row = buildJsonObject { put("store_id", 0); put("language_id", languageId); put("keyword", keyword) }
                    if (existingIndex >= 0) rows[existingIndex] = row else rows += row
                    updated = JsonObject(updated.toMutableMap().apply { put("seo_urls", JsonArray(rows)) })
                }
            }
            recordSetChange(entity, path, before, value)
            savePayload(entity, updated)
            if (auditChange) audit("product_field", entity, "${friendlyPath(path)} изменено", buildJsonObject { put("path", path); put("before", before); put("after", value) }, historyId)
            true
        }
    }

    suspend fun adjustQuantity(uuid: String, delta: Int) {
        if (delta == 0) return
        val historyId = history.captureCurrent(uuid, "quantity_adjust", "Изменение остатка ${if (delta > 0) "+" else ""}$delta")
        db.withTransaction {
        val entity = db.products().get(uuid) ?: error("Товар не найден")
        val local = JsonTools.objectOf(entity.localJson)
        val before = JsonTools.path(local, "product.quantity")?.jsonPrimitive?.intOrNull ?: 0
        val after = before + delta
        val updated = JsonTools.setPath(local, "product.quantity", JsonPrimitive(after))
        if (entity.productId != null) {
            val session = activeSessionId()
            db.changes().insert(ChangeEntity(
                sessionId = session, entityType = "product", entityUuid = uuid, fieldPath = "product.quantity",
                beforeJson = "0", afterJson = delta.toString(), operationType = "adjust", createdAt = System.currentTimeMillis()
            ))
        }
        // For a not-yet-created product __create__ already syncs the complete current localJson.
        // A separate quantity-adjust row would only duplicate noise and cannot be independently applied.
        savePayload(entity, updated)
        audit("quantity_adjust", entity, "Остаток ${if (delta > 0) "+" else ""}$delta", buildJsonObject { put("before", before); put("after", after); put("delta", delta) }, historyId)
        }
    }

    suspend fun createBlank(primaryLanguageId: String = "1"): String = db.withTransaction {
        val uuid = UUID.randomUUID().toString()
        var payload = ProductJson.blank()
        payload = JsonTools.setPath(payload, "descriptions.$primaryLanguageId", buildJsonObject {
            put("name", ""); put("description", ""); put("tag", ""); put("meta_title", ""); put("meta_description", ""); put("meta_keyword", "")
        })
        insertNew(uuid, payload, null, null)
        uuid
    }

    suspend fun createFromDonor(donorUuid: String, sections: Set<String>, primaryLanguageId: String = "1"): String = db.withTransaction {
        val donor = db.products().get(donorUuid) ?: error("Донор не найден")
        val source = JsonTools.objectOf(donor.localJson)
        var target = ProductJson.blank()
        fun copySection(key: String) { source[key]?.let { target = JsonObject(target.toMutableMap().apply { put(key, it) }) } }
        if ("descriptions" in sections) copySection("descriptions")
        if ("categories" in sections) copySection("categories")
        if ("stores" in sections) copySection("stores")
        if ("related" in sections) copySection("related")
        if ("specials" in sections) copySection("specials")
        if ("discounts" in sections) copySection("discounts")
        if ("images" in sections) {
            copySection("images")
            JsonTools.path(source, "product.image")?.let { target = JsonTools.setPath(target, "product.image", it) }
        }
        if ("attributes" in sections) copySection("attributes")
        if ("options" in sections) copySection("options")
        if ("seo_urls" in sections) copySection("seo_urls")
        if ("extension_fields" in sections) copySection("extension_fields")
        if ("manufacturer" in sections) {
            val id = JsonTools.path(source, "product.manufacturer_id") ?: JsonPrimitive(0)
            target = JsonTools.setPath(target, "product.manufacturer_id", id)
        }
        if ("price" in sections) {
            target = JsonTools.setPath(target, "product.price", JsonTools.path(source, "product.price") ?: JsonPrimitive("0.0000"))
        }
        if ("core_settings" in sections) {
            listOf("location","stock_status_id","shipping","points","tax_class_id","date_available","weight","weight_class_id","length","width","height","length_class_id","subtract","minimum","sort_order","status").forEach { f ->
                JsonTools.path(source, "product.$f")?.let { target = JsonTools.setPath(target, "product.$f", it) }
            }
        }
        JsonTools.path(source, "product.model")?.let { target = JsonTools.setPath(target, "product.model", it) }
        // Unique identifiers are always cleared. SEO rows deliberately keep the donor keyword
        // until Quick Replace so the store's exact URL structure is preserved as a template.
        listOf("sku","upc","ean","jan","isbn","mpn").forEach { target = JsonTools.setPath(target, "product.$it", JsonPrimitive("")) }
        target = JsonTools.setPath(
            target,
            "product.quantity",
            if ("quantity" in sections) JsonTools.path(source, "product.quantity") ?: JsonPrimitive(0) else JsonPrimitive(0)
        )
        if ((target["descriptions"] as? JsonObject).isNullOrEmpty()) {
            target = JsonTools.setPath(target, "descriptions.$primaryLanguageId", buildJsonObject { put("name", ""); put("description", ""); put("tag", ""); put("meta_title", ""); put("meta_description", ""); put("meta_keyword", "") })
        }
        val uuid = UUID.randomUUID().toString()
        insertNew(uuid, target, donor.productId, donor.uuid)

        // A LOCAL donor may not exist on the server yet. Clone its local photo rows as well,
        // so the new product remains a complete donor clone and can upload/attach the same
        // images independently. Workspace source markers are deliberately detached to avoid
        // moving one physical source file twice when either product is synchronized.
        if ("images" in sections) {
            val donorPhotos = db.photos().forProduct(donorUuid)
            if (donorPhotos.isNotEmpty()) {
                val now = System.currentTimeMillis()
                db.photos().putAll(donorPhotos.mapIndexed { index, photo ->
                    val clonedStatus = when (photo.status) {
                        "ATTACHED", "UPLOADED" -> "ATTACHED"
                        else -> if (photo.processedPath.isNotBlank()) "READY" else "IMPORTED"
                    }
                    photo.copy(
                        id = UUID.randomUUID().toString(),
                        productUuid = uuid,
                        status = clonedStatus,
                        error = "",
                        sourceUri = null,
                        sourceStage = "EXTERNAL",
                        sourceError = null,
                        createdAt = now + index,
                        updatedAt = now + index,
                    )
                })
            }
        }

        val donorLabel = donor.productId?.let { "#$it" } ?: "LOCAL"
        audit("donor_clone", db.products().get(uuid)!!, "Создан из донора $donorLabel", buildJsonObject { put("donor_uuid", donorUuid); put("sections", JsonArray(sections.map(::JsonPrimitive))) })
        uuid
    }

    suspend fun donorQuickReplace(uuid: String, oldValue: String, newValue: String): Int =
        donorQuickReplace(uuid, listOf(oldValue to newValue))

    suspend fun donorQuickReplace(uuid: String, rawReplacements: List<Pair<String, String>>): Int {
        val replacements = rawReplacements.map { it.first.trim() to it.second.trim() }
            .filter { (old, new) -> old.isNotBlank() && new.isNotBlank() && !old.equals(new, ignoreCase = true) }
        require(replacements.isNotEmpty()) { "Не указано ни одной замены" }

        val duplicate = replacements.groupBy { it.first.lowercase() }.entries.firstOrNull { it.value.size > 1 }
        require(duplicate == null) { "Значение «${duplicate?.value?.firstOrNull()?.first.orEmpty()}» указано несколько раз" }

        val summary = replacements.joinToString(", ") { "${it.first} → ${it.second}" }.take(500)
        val historyId = history.captureCurrent(uuid, "donor_replace", "Быстрая замена: $summary")
        return db.withTransaction {
            val entity = db.products().get(uuid) ?: error("Товар не найден")
            var payload = JsonTools.objectOf(entity.localJson)
            var changed = 0

            val paths = mutableListOf("product.model")
            val descriptions = payload["descriptions"]?.jsonObject.orEmpty()
            descriptions.keys.forEach { lang ->
                listOf("name", "description", "tag", "meta_title", "meta_description", "meta_keyword").forEach { field ->
                    paths += "descriptions.$lang.$field"
                }
            }

            // Every row is an atomic object. All rows are applied to the ORIGINAL field in one
            // pass, so replacements never cascade into one another. Alphanumeric boundaries
            // protect short values such as 2A from matching inside larger identifiers.
            paths.forEach { path ->
                val original = JsonTools.path(payload, path)?.jsonPrimitive?.contentOrNull ?: return@forEach
                val preview = DonorTools.replaceManyAtomic(original, replacements)
                if (preview.after != original) {
                    payload = JsonTools.setPath(payload, path, JsonPrimitive(preview.after))
                    recordSetChange(entity.copy(localJson = payload.toString()), path, JsonPrimitive(original), JsonPrimitive(preview.after))
                    changed++
                }
            }

            var seo = payload["seo_urls"] as? JsonArray ?: JsonArray(emptyList())
            if (seo.isEmpty()) {
                val rows = payload["descriptions"]?.jsonObject.orEmpty().keys.mapNotNull { languageId ->
                    val name = JsonTools.path(payload, "descriptions.$languageId.name")?.jsonPrimitive?.contentOrNull.orEmpty()
                    if (name.isBlank()) null else buildJsonObject {
                        put("store_id", 0)
                        put("language_id", languageId.toIntOrNull() ?: 1)
                        put("keyword", HandelthekeSeoPolicy.slug(name))
                    }
                }
                seo = JsonArray(rows)
            }
            val slugPairs = replacements.mapNotNull { (old, new) ->
                val oldSlug = HandelthekeSeoPolicy.slug(old)
                val newSlug = HandelthekeSeoPolicy.slug(new)
                if (oldSlug.isBlank() || newSlug.isBlank() || oldSlug.equals(newSlug, ignoreCase = true)) null else oldSlug to newSlug
            }
            val newSeo = seo.mapIndexed { index, rowElement ->
                val row = rowElement.jsonObject
                val oldKeyword = row["keyword"]?.jsonPrimitive?.contentOrNull.orEmpty()
                var keyword = oldKeyword
                if (keyword.isNotBlank() && slugPairs.isNotEmpty()) {
                    keyword = DonorTools.replaceManyAtomic(keyword, slugPairs).after
                }
                if (keyword.isBlank()) {
                    val languageId = row["language_id"]?.jsonPrimitive?.contentOrNull
                    val name = languageId?.let { JsonTools.path(payload, "descriptions.$it.name")?.jsonPrimitive?.contentOrNull }
                        ?: payload["descriptions"]?.jsonObject?.values?.firstOrNull()?.jsonObject?.get("name")?.jsonPrimitive?.contentOrNull.orEmpty()
                    keyword = HandelthekeSeoPolicy.slug(name)
                } else {
                    keyword = HandelthekeSeoPolicy.slug(keyword)
                }
                if (keyword != oldKeyword) {
                    recordSetChange(entity.copy(localJson = payload.toString()), "seo_urls.$index.keyword", JsonPrimitive(oldKeyword), JsonPrimitive(keyword))
                    changed++
                }
                JsonObject(row.toMutableMap().apply { put("keyword", JsonPrimitive(keyword)) })
            }
            payload = JsonObject(payload.toMutableMap().apply { put("seo_urls", JsonArray(newSeo)) })
            savePayload(entity, payload)
            audit(
                "donor_replace",
                entity,
                "Быстрая замена: $summary",
                buildJsonObject {
                    put("changed", changed)
                    put("mode", "atomic_multi_replace")
                    put("replacements", JsonArray(replacements.map { (old, new) ->
                        buildJsonObject { put("old", old); put("new", new) }
                    }))
                },
                historyId,
            )
            changed
        }
    }


    suspend fun setLocalNote(uuid: String, note: String) {
        val before = db.products().get(uuid) ?: error("Товар не найден")
        if (before.localNote == note) return
        val historyId = history.captureCurrent(uuid, "local_note", "Изменение локальной заметки")
        db.withTransaction {
            val entity = db.products().get(uuid) ?: error("Товар не найден")
            if (entity.localNote == note) return@withTransaction
            db.products().put(entity.copy(localNote = note, updatedAt = System.currentTimeMillis()))
            audit("local_note", entity, "Локальная заметка изменена", buildJsonObject { put("note", note) }, historyId)
        }
    }

    suspend fun setWorkflowState(uuid: String, state: String, ignoreDonorChecklistErrors: Boolean = false) {
        require(state in setOf("DRAFT", "IN_PROGRESS", "REVIEW", "READY")) { "Неизвестный рабочий статус" }
        val current = db.products().get(uuid) ?: error("Товар не найден")
        if (current.workflowState == state && current.isDraft == (state != "READY")) return

        if (state == "READY") {
            val lang = db.settings().get("primary_language_id")
            val errors = de.handeltheke.handeldesk.domain.ValidationEngine.validate(current, lang)
                .filter { it.severity == de.handeltheke.handeldesk.domain.Severity.ERROR }
            require(errors.isEmpty()) { "Нельзя отметить готовым: ${errors.first().message}" }
            val donor = current.sourceProductUuid?.let { db.products().get(it) }
                ?: current.sourceProductId?.let { db.products().getByProductId(it) }
            if (donor != null) {
                val checklist = de.handeltheke.handeldesk.domain.ValidationEngine.donorChecklist(current, donor)
                if (!ignoreDonorChecklistErrors) require(checklist.ready) { "Donor Checklist содержит ошибки" }
            }
        }

        val historyId = history.captureCurrent(uuid, "workflow", "Рабочий статус → $state")
        db.withTransaction {
            val entity = db.products().get(uuid) ?: error("Товар не найден")
            db.products().put(entity.copy(workflowState = state, isDraft = state != "READY", updatedAt = System.currentTimeMillis()))
            audit("workflow", entity, "Рабочий статус: $state", buildJsonObject {
                put("state", state); put("donor_checklist_override", ignoreDonorChecklistErrors)
            }, historyId)
        }
    }

    suspend fun addToQueue(uuid: String) {
        if (db.queue().get(uuid) != null) return
        val historyId = history.captureCurrent(uuid, "queue_add", "Добавление в рабочую очередь")
        val position = db.queue().nextPosition()
        db.queue().put(WorkQueueEntity(uuid, position, System.currentTimeMillis()))
        db.products().get(uuid)?.let { entity ->
            audit("queue_add", entity, "Товар добавлен в рабочую очередь", buildJsonObject { put("position", position) }, historyId)
        }
    }

    suspend fun removeFromQueue(uuid: String) {
        val existing = db.queue().get(uuid) ?: return
        val historyId = history.captureCurrent(uuid, "queue_remove", "Удаление из рабочей очереди")
        db.queue().remove(uuid)
        db.products().get(uuid)?.let { entity ->
            audit("queue_remove", entity, "Товар удалён из рабочей очереди", buildJsonObject { put("position", existing.position) }, historyId)
        }
    }

    private suspend fun insertNew(uuid: String, payload: JsonObject, sourceProductId: Int?, sourceProductUuid: String?) {
        val normalizedPayload = normalizeMainImageDuplicate(payload)
        val idx = ProductJson.index(normalizedPayload, db.settings().get("primary_language_id"))
        val now = System.currentTimeMillis()
        val entity = ProductEntity(
            uuid = uuid, productId = null, sourceProductId = sourceProductId, sourceProductUuid = sourceProductUuid, baseJson = "{}", localJson = normalizedPayload.toString(),
            state = "NEW", isDraft = true, workflowState = "DRAFT", name = idx.name, model = idx.model, sku = idx.sku,
            jan = idx.jan, price = idx.price, quantity = idx.quantity, manufacturerId = idx.manufacturerId,
            status = idx.status, searchNorm = idx.searchNorm, updatedAt = now
        )
        db.products().put(entity)
        db.changes().insert(ChangeEntity(
            sessionId = activeSessionId(), entityType = "product", entityUuid = uuid, fieldPath = "__create__",
            beforeJson = null, afterJson = normalizedPayload.toString(), operationType = "create", createdAt = now
        ))
    }

    private suspend fun savePayload(entity: ProductEntity, payload: JsonObject) {
        val idx = ProductJson.index(payload, db.settings().get("primary_language_id"))
        val pending = db.changes().pendingCount("product", entity.uuid) > 0
        db.products().put(entity.copy(
            localJson = payload.toString(), state = if (entity.productId == null) "NEW" else if (pending) "MODIFIED" else "SYNCED",
            name = idx.name, model = idx.model, sku = idx.sku, jan = idx.jan, price = idx.price, quantity = idx.quantity,
            manufacturerId = idx.manufacturerId, status = idx.status, searchNorm = idx.searchNorm, updatedAt = System.currentTimeMillis()
        ))
    }

    private suspend fun recordSetChange(entity: ProductEntity, path: String, before: JsonElement, after: JsonElement) {
        if (entity.productId == null) return // __create__ carries the latest local payload during sync.
        val base = JsonTools.objectOf(entity.baseJson)
        val baseValue = JsonTools.path(base, path) ?: JsonNull
        val existing = db.changes().findSet("product", entity.uuid, path)
        if (after == baseValue) {
            existing?.let { db.changes().delete(it.id) }
            return
        }
        val now = System.currentTimeMillis()
        if (existing == null) {
            db.changes().insert(ChangeEntity(sessionId = activeSessionId(), entityType = "product", entityUuid = entity.uuid, fieldPath = path,
                beforeJson = baseValue.toString(), afterJson = after.toString(), operationType = "set", createdAt = now))
        } else db.changes().update(existing.copy(afterJson = after.toString(), included = true, createdAt = now))
    }

    /** OpenCart theme contract: product.image must also be product_images sort_order=0. */
    private fun normalizeMainImageDuplicate(payload: JsonObject): JsonObject {
        val main = JsonTools.path(payload, "product.image")?.jsonPrimitive?.contentOrNull.orEmpty()
        if (main.isBlank()) return payload
        val existing = (payload["images"] as? JsonArray).orEmpty()
            .mapNotNull { it as? JsonObject }
            .filter { it["image"]?.jsonPrimitive?.contentOrNull != main }
        val rows = buildList<JsonObject> {
            add(buildJsonObject { put("image", main); put("sort_order", 0) })
            existing.forEachIndexed { index, row ->
                add(JsonObject(row.toMutableMap().apply { put("sort_order", JsonPrimitive(index + 1)) }))
            }
        }
        return JsonObject(payload.toMutableMap().apply { put("images", JsonArray(rows)) })
    }

    private suspend fun activeSessionId(): String? = db.settings().get("active_session_id")

    private fun friendlyPath(path: String): String = when {
        path == "product.model" -> "модели"
        path == "product.price" -> "цены"
        path == "product.quantity" -> "остатка"
        path == "product.status" -> "статуса"
        path == "product.manufacturer_id" -> "производителя"
        path == "product.image" -> "главного фото"
        path == "images" -> "порядка фото"
        path.startsWith("descriptions.") && path.endsWith(".name") -> "названия"
        else -> path
    }

    private suspend fun audit(type: String, entity: ProductEntity, summary: String, details: JsonObject, historyId: Long? = null) {
        val enriched = JsonObject(details.toMutableMap().apply { historyId?.let { put("history_id", JsonPrimitive(it)) } })
        db.audit().insert(AuditEventEntity(
            createdAt = System.currentTimeMillis(), sessionId = activeSessionId(), eventType = type,
            entityType = "product", entityUuid = entity.uuid, entityId = entity.productId,
            source = "android", summary = summary, detailsJson = enriched.toString()
        ))
    }
}
