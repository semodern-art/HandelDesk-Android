package de.handeltheke.handeldesk.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import de.handeltheke.handeldesk.ui.screens.*

@Composable
fun HandelDeskRoot() {
    val nav = rememberNavController()
    val current by nav.currentBackStackEntryAsState()
    val route = current?.destination?.route.orEmpty()
    val detailRoute = route.startsWith("product/") || route.startsWith("donor_replace/") || route.startsWith("photos/") ||
        route.startsWith("photo_edit/") || route.startsWith("photo_inbox/") || route.startsWith("history/") || route in setOf("prepare", "sync", "settings", "audit", "travel")

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (!detailRoute) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 3.dp,
                ) {
                    listOf(
                        Triple("products", "Товары", "▦"),
                        Triple("work", "Работа", "✓"),
                        Triple("new", "Новый", "+"),
                        Triple("changes", "Изменения", "Δ"),
                        Triple("more", "Ещё", "•••")
                    ).forEach { (r, label, symbol) ->
                        NavigationBarItem(
                            selected = route == r,
                            onClick = { nav.navigate(r) { launchSingleTop = true; restoreState = true } },
                            icon = {
                                Surface(
                                    shape = CircleShape,
                                    color = if (route == r) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                                    modifier = Modifier.size(30.dp),
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(symbol, style = MaterialTheme.typography.titleMedium)
                                    }
                                }
                            },
                            label = { Text(label, maxLines = 1) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(navController = nav, startDestination = "products", modifier = Modifier.padding(padding)) {
            composable("products") { ProductsScreen(onOpen = { nav.navigate("product/$it") }, onNew = { nav.navigate("new") }) }
            composable("work") { WorkScreen(onOpen = { nav.navigate("product/$it") }) }
            composable("new") {
                NewProductScreen(onCreated = { uuid, fromDonor ->
                    nav.navigate(if (fromDonor) "donor_replace/$uuid" else "product/$uuid") {
                        popUpTo("new") { inclusive = true }
                    }
                })
            }
            composable("changes") {
                ChangesScreen(
                    onOpen = { nav.navigate("product/$it") },
                    onSync = { nav.navigate("sync") },
                    onAudit = { nav.navigate("audit") },
                )
            }
            composable("more") { MoreScreen(onPrepare = { nav.navigate("prepare") }, onSync = { nav.navigate("sync") }, onSettings = { nav.navigate("settings") }, onAudit = { nav.navigate("audit") }, onTravel = { nav.navigate("travel") }) }
            composable("prepare") { PrepareOfflineScreen(onBack = { nav.popBackStack() }) }
            composable("sync") { SyncScreen(onBack = { nav.popBackStack() }) }
            composable("settings") { SettingsScreen(onBack = { nav.popBackStack() }) }
            composable("audit") { AuditScreen(onBack = { nav.popBackStack() }) }
            composable("travel") { TravelReadyScreen(onBack = { nav.popBackStack() }) }
            composable("product/{uuid}", arguments = listOf(navArgument("uuid") { type = NavType.StringType })) { entry ->
                ProductScreen(
                    uuid = entry.arguments?.getString("uuid").orEmpty(),
                    onBack = { nav.popBackStack() },
                    onDone = {
                        nav.navigate("products") {
                            popUpTo("products") { inclusive = false }
                            launchSingleTop = true
                        }
                    },
                    onReplace = { nav.navigate("donor_replace/$it") },
                    onPhotos = { nav.navigate("photos/$it") },
                    onHistory = { nav.navigate("history/$it") },
                )
            }
            composable("history/{uuid}", arguments = listOf(navArgument("uuid") { type = NavType.StringType })) { entry ->
                ProductHistoryScreen(
                    productUuid = entry.arguments?.getString("uuid").orEmpty(),
                    onBack = { nav.popBackStack() },
                )
            }
            composable("photos/{uuid}", arguments = listOf(navArgument("uuid") { type = NavType.StringType })) { entry ->
                PhotoManagerScreen(
                    productUuid = entry.arguments?.getString("uuid").orEmpty(),
                    onBack = { nav.popBackStack() },
                    onEdit = { nav.navigate("photo_edit/$it") },
                    onInbox = { nav.navigate("photo_inbox/$it") },
                )
            }
            composable("photo_inbox/{uuid}", arguments = listOf(navArgument("uuid") { type = NavType.StringType })) { entry ->
                PhotoInboxScreen(
                    productUuid = entry.arguments?.getString("uuid").orEmpty(),
                    onBack = { nav.popBackStack() },
                    onImported = { nav.popBackStack() },
                )
            }
            composable("photo_edit/{photoId}", arguments = listOf(navArgument("photoId") { type = NavType.StringType })) { entry ->
                PhotoEditScreen(photoId = entry.arguments?.getString("photoId").orEmpty(), onBack = { nav.popBackStack() })
            }
            composable("donor_replace/{uuid}", arguments = listOf(navArgument("uuid") { type = NavType.StringType })) { entry ->
                DonorReplaceScreen(uuid = entry.arguments?.getString("uuid").orEmpty(), onDone = { nav.navigate("product/$it") { popUpTo("products") } })
            }
        }
    }
}

@Composable
fun ScreenHeader(title: String, subtitle: String? = null, onBack: (() -> Unit)? = null) {
    Surface(color = MaterialTheme.colorScheme.background) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            if (onBack != null) {
                FilledTonalIconButton(onClick = onBack, modifier = Modifier.size(40.dp)) {
                    Text("‹", style = MaterialTheme.typography.headlineSmall)
                }
            }
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.headlineSmall, maxLines = 2)
                if (!subtitle.isNullOrBlank()) {
                    Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
