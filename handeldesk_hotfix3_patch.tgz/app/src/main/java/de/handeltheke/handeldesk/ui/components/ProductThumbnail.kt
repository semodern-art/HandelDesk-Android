package de.handeltheke.handeldesk.ui.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.foundation.background
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import de.handeltheke.handeldesk.data.local.LocalPhotoEntity

/**
 * Single thumbnail policy used by Products/Work/Product screens.
 * A phone-local image wins when it represents the current main path. For a new
 * product whose JSON image path has not been refreshed yet, the declared local
 * main photo is used as a safe fallback.
 */
@Composable
fun ProductThumbnail(
    remotePath: String,
    localPhotos: List<LocalPhotoEntity>,
    size: Dp,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop,
) {
    val local = localPhotos.firstOrNull {
        it.remotePath.isNotBlank() && it.remotePath == remotePath && (it.processedPath.isNotBlank() || it.originalPath.isNotBlank())
    } ?: if (remotePath.isBlank()) {
        localPhotos.firstOrNull { it.isMain && (it.processedPath.isNotBlank() || it.originalPath.isNotBlank()) }
    } else null

    when {
        local != null -> LocalFileImage(local.processedPath.ifBlank { local.originalPath }, modifier, size, contentScale)
        remotePath.isNotBlank() -> CachedProductImage(remotePath, modifier, size, contentScale)
        else -> Box(modifier.size(size).background(MaterialTheme.colorScheme.surfaceVariant))
    }
}
