package de.handeltheke.handeldesk.diagnostics

import android.content.Context
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object CrashLog {
    private var installed = false

    fun install(context: Context) {
        if (installed) return
        installed = true
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            runCatching {
                val dir = File(context.filesDir, "diagnostics").apply { mkdirs() }
                val sw = StringWriter()
                throwable.printStackTrace(PrintWriter(sw))
                File(dir, "last_crash.txt").writeText(
                    buildString {
                        appendLine("Time: ${SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.getDefault()).format(Date())}")
                        appendLine("Thread: ${thread.name}")
                        appendLine(sw.toString())
                    }.take(60_000)
                )
            }
            previous?.uncaughtException(thread, throwable)
        }
    }
}
