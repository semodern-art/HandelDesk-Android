package de.handeltheke.handeldesk.data.repo

import androidx.room.withTransaction
import de.handeltheke.handeldesk.data.local.*
import de.handeltheke.handeldesk.domain.JsonTools
import de.handeltheke.handeldesk.domain.ProductJson
import de.handeltheke.handeldesk.domain.ProductStateDiff
import kotlinx.serialization.json.*

class ProductUndoRepository(
    private val db: HandelDeskDatabase,
    private val history: ProductHistoryRepository,
    private val localPhotos: LocalPhotoRepository,
) {
    data class RestoreResult(
        val productUuid: String,
        val historyId: Long,
        val summary: String,
        val pendingChanges: Int,
        val restoredAfterSync: Boolean,
    )

    suspend fun undoLatest(productUuid: String): RestoreResult {
        val point = db.history().latestUndoable(productUuid) ?: error("Для этого товара пока нет точки отката")
        return restore(point.id)
    }

    suspend fun restore(historyId: Long): RestoreResult {
        val point = db.history().get(historyId) ?: error("Точка восстановления не найдена")
        val before = db.products().get(point.productUuid) ?: error("Товар больше не существует локально")

        // Safety snapshot makes the restore itself undoable and preserves the exact current
        // ChangeSet/queue/photo state in case the user wants to go back again.
        val safetyHistoryId = history.captureCurrent(
            point.productUuid,
            "history_restore",
            "Восстановление состояния до: ${point.summary}",
        )
        val safetyPoint = safetyHistoryId?.let { db.history().get(it) }

        val sameBase = point.productIdAtCapture == before.productId &&
            point.baseRevisionAtCapture == before.baseRevision &&
            point.baseJsonAtCapture == before.baseJson
        var target = JsonTools.objectOf(point.localJson)
        if (before.productId != null) {
            // A restore can never resurrect an obsolete/local product identity.
            target = JsonTools.setPath(target, "product.product_id", JsonPrimitive(before.productId))
        }

        val session = db.settings().get("active_session_id")
        val now = System.currentTimeMillis()
        var pendingCount = 0

        try {
            val restoredPhotos = history.decodePhotos(point.photoSnapshotJson)
            localPhotos.restoreHistoryRows(point.productUuid, restoredPhotos)

            db.withTransaction {
                val current = db.products().get(point.productUuid) ?: error("Товар больше не существует локально")
                db.changes().deletePendingForEntity("product", current.uuid)

                if (sameBase) {
                    // Before another Sync the old ChangeSet is still valid against the same BASE.
                    // Restore it exactly so included/excluded flags and adjust operations survive Undo.
                    val exactRows = history.decodeChanges(point.changeSnapshotJson, current.uuid)
                    if (current.productId == null && exactRows.none { it.fieldPath == "__create__" }) {
                        db.changes().insert(
                            ChangeEntity(
                                sessionId = session,
                                entityType = "product",
                                entityUuid = current.uuid,
                                fieldPath = "__create__",
                                beforeJson = null,
                                afterJson = target.toString(),
                                operationType = "create",
                                synced = false,
                                included = true,
                                createdAt = now,
                            )
                        )
                        pendingCount = 1
                    } else {
                        exactRows.forEach { row ->
                            val restoredRow = if (current.productId == null && row.fieldPath == "__create__") {
                                row.copy(id = 0, afterJson = target.toString(), operationType = "create", synced = false)
                            } else row.copy(id = 0, synced = false)
                            db.changes().insert(restoredRow)
                        }
                        pendingCount = exactRows.size
                    }
                } else if (current.productId == null) {
                    // Defensive fallback; normally a local product cannot change BASE identity.
                    db.changes().insert(
                        ChangeEntity(
                            sessionId = session,
                            entityType = "product",
                            entityUuid = current.uuid,
                            fieldPath = "__create__",
                            beforeJson = null,
                            afterJson = target.toString(),
                            operationType = "create",
                            synced = false,
                            included = true,
                            createdAt = now,
                        )
                    )
                    pendingCount = 1
                } else {
                    // A Sync happened after this point. Old pending rows belong to an old BASE and
                    // must never be replayed. Build a fresh, explicit ChangeSet against current BASE.
                    val base = JsonTools.objectOf(current.baseJson)
                    val diffs = ProductStateDiff.diff(base, target)
                    diffs.forEach { diff ->
                        db.changes().insert(
                            ChangeEntity(
                                sessionId = session,
                                entityType = "product",
                                entityUuid = current.uuid,
                                fieldPath = diff.path,
                                beforeJson = diff.before.toString(),
                                afterJson = diff.after.toString(),
                                operationType = "set",
                                synced = false,
                                included = true,
                                createdAt = now,
                            )
                        )
                    }
                    pendingCount = diffs.size
                }

                db.queue().remove(current.uuid)
                point.queuePosition?.let { position ->
                    db.queue().put(
                        WorkQueueEntity(
                            productUuid = current.uuid,
                            position = position,
                            createdAt = point.queueCreatedAt ?: now,
                        )
                    )
                }

                val index = ProductJson.index(target, db.settings().get("primary_language_id"))
                val nextState = when {
                    current.productId == null -> "NEW"
                    pendingCount > 0 -> "MODIFIED"
                    else -> "SYNCED"
                }
                db.products().put(
                    current.copy(
                        localJson = target.toString(),
                        localNote = point.localNote,
                        workflowState = point.workflowState,
                        isDraft = point.isDraft,
                        state = nextState,
                        name = index.name,
                        model = index.model,
                        sku = index.sku,
                        jan = index.jan,
                        price = index.price,
                        quantity = index.quantity,
                        manufacturerId = index.manufacturerId,
                        status = index.status,
                        searchNorm = index.searchNorm,
                        updatedAt = now,
                    )
                )

                db.audit().insert(
                    AuditEventEntity(
                        createdAt = now,
                        sessionId = session,
                        eventType = "history_restore",
                        entityType = "product",
                        entityUuid = current.uuid,
                        entityId = current.productId,
                        source = "android",
                        summary = "Восстановлено состояние до: ${point.summary}",
                        detailsJson = buildJsonObject {
                            safetyHistoryId?.let { put("history_id", it) }
                            put("restored_history_id", historyId)
                            put("pending_changes", pendingCount)
                            put("same_base", sameBase)
                            put("server_unchanged", true)
                        }.toString(),
                    )
                )
            }
        } catch (t: Throwable) {
            // Best-effort rollback of photo workspace/rows if the restore failed midway. Product
            // DB writes are transactional, so only file/photo state can need compensation here.
            safetyPoint?.let { safe ->
                runCatching {
                    localPhotos.restoreHistoryRows(point.productUuid, history.decodePhotos(safe.photoSnapshotJson))
                }
            }
            throw t
        }

        val afterSync = !sameBase
        return RestoreResult(
            productUuid = point.productUuid,
            historyId = historyId,
            summary = point.summary,
            pendingChanges = pendingCount,
            restoredAfterSync = afterSync,
        )
    }
}
