package de.handeltheke.handeldesk.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import de.handeltheke.handeldesk.HandelDeskApp
import de.handeltheke.handeldesk.ui.ScreenHeader
import de.handeltheke.handeldesk.worker.OfflinePrepareService
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PrepareOfflineScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val app = context.applicationContext as HandelDeskApp
    val settings = app.container.db.settings()
    val total by app.container.db.products().observeTotalCount().collectAsState(initial = 0)
    val changedCount by app.container.db.products().observeChangedCount().collectAsState(initial = 0)
    val draftCount by app.container.db.products().observeDraftCount().collectAsState(initial = 0)

    val lastSnapshot by settings.observe("snapshot_at").collectAsState(initial = null)
    val lastMode by settings.observe("last_refresh_mode").collectAsState(initial = null)
    val lastSummary by settings.observe("last_refresh_summary").collectAsState(initial = null)
    val lastFullAt by settings.observe("last_full_snapshot_at").collectAsState(initial = null)
    val lastDeltaAt by settings.observe("last_delta_sync_at").collectAsState(initial = null)
    val deltaCursor by settings.observe("delta_cursor").collectAsState(initial = null)
    val checkpointReceived by settings.observe("full_snapshot_received").collectAsState(initial = null)
    val checkpointTotal by settings.observe("full_snapshot_total").collectAsState(initial = null)
    val checkpointAfterId by settings.observe("full_snapshot_after_id").collectAsState(initial = null)

    val jobState by settings.observe("offline_job_state").collectAsState(initial = null)
    val jobMessage by settings.observe("offline_job_message").collectAsState(initial = null)
    val jobCurrentRaw by settings.observe("offline_job_current").collectAsState(initial = null)
    val jobTotalRaw by settings.observe("offline_job_total").collectAsState(initial = null)
    val jobStage by settings.observe("offline_job_stage").collectAsState(initial = null)
    val jobOperation by settings.observe("offline_job_operation").collectAsState(initial = null)

    var imageMode by rememberSaveable { mutableStateOf("main") }
    var cacheStats by remember { mutableStateOf(0 to 0L) }
    var pendingReset by remember { mutableStateOf<String?>(null) }

    val current = jobCurrentRaw?.toIntOrNull() ?: 0
    val jobTotal = jobTotalRaw?.toIntOrNull() ?: 0
    val checkpointCurrent = checkpointReceived?.toIntOrNull() ?: 0
    val checkpointMax = checkpointTotal?.toIntOrNull() ?: 0
    val running = jobState in setOf(
        OfflinePrepareService.STATE_RUNNING,
        OfflinePrepareService.STATE_WAITING_NETWORK,
    )

    fun start(operation: String, preserveLocal: Boolean = true) {
        OfflinePrepareService.start(context, imageMode, operation, preserveLocal)
    }

    fun requestFullReset(operation: String) {
        if (changedCount > 0) pendingReset = operation else start(operation, preserveLocal = true)
    }

    LaunchedEffect(Unit) {
        settings.get("offline_image_mode")?.takeIf { it in setOf("none", "main", "all") }?.let { imageMode = it }
    }

    LaunchedEffect(jobState) {
        cacheStats = app.container.imageCache.cacheStats()
    }

    if (pendingReset != null) {
        AlertDialog(
            onDismissRequest = { pendingReset = null },
            title = { Text("Есть локальные изменения") },
            text = {
                Text(
                    "Локально изменено: $changedCount товаров" +
                        (if (draftCount > 0) "\nНовых черновиков: $draftCount" else "") +
                        "\n\nМожно сохранить эти изменения и заново скачать только серверные версии, либо удалить локальные изменения полностью."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val op = pendingReset ?: return@TextButton
                    pendingReset = null
                    start(op, preserveLocal = true)
                }) { Text("Сохранить локальные") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { pendingReset = null }) { Text("Отмена") }
                    TextButton(onClick = {
                        val op = pendingReset ?: return@TextButton
                        pendingReset = null
                        start(op, preserveLocal = false)
                    }) { Text("Удалить локальные тоже") }
                }
            },
        )
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Offline", "Каталог локально: $total товаров", onBack)
        Column(Modifier.weight(1f).fillMaxWidth().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                if (deltaCursor.isNullOrBlank()) {
                    "Первый Full Snapshot сохраняет checkpoint и продолжает с места остановки. После завершения включается Delta Sync."
                } else {
                    "Delta Sync активен: сервер отдаёт только изменившиеся товары. Локально изменённые товары серверными данными не перезаписываются."
                }
            )

            Text(
                "Последнее обновление: ${lastSummary ?: if (lastSnapshot == null) "не выполнялось" else lastMode.orEmpty()}",
                style = MaterialTheme.typography.bodySmall,
            )
            if (!lastFullAt.isNullOrBlank()) {
                Text("Последний Full Snapshot: ${formatTimestamp(lastFullAt)}", style = MaterialTheme.typography.bodySmall)
            }
            if (!lastDeltaAt.isNullOrBlank()) {
                Text("Последний Delta Sync: ${formatTimestamp(lastDeltaAt)}", style = MaterialTheme.typography.bodySmall)
            }
            if (!deltaCursor.isNullOrBlank()) {
                Text("Delta cursor: $deltaCursor", style = MaterialTheme.typography.bodySmall)
            } else if (checkpointCurrent > 0 || !checkpointAfterId.isNullOrBlank()) {
                Text(
                    "Checkpoint: $checkpointCurrent${if (checkpointMax > 0) " / $checkpointMax" else ""} · product_id ${checkpointAfterId.orEmpty()}",
                    style = MaterialTheme.typography.bodySmall,
                )
            }

            Text("Изображения для офлайна:", style = MaterialTheme.typography.titleSmall)
            listOf("none" to "Без изображений", "main" to "Только главные", "all" to "Все изображения").forEach { (value, label) ->
                Row(Modifier.fillMaxWidth()) {
                    RadioButton(
                        selected = imageMode == value,
                        onClick = { if (!running) imageMode = value },
                        enabled = !running,
                    )
                    Text(label, modifier = Modifier.padding(top = 12.dp))
                }
            }
            Text(
                "В кеше: ${cacheStats.first} файлов · ${"%.1f".format(cacheStats.second / 1048576.0)} MB",
                style = MaterialTheme.typography.bodySmall,
            )

            if (running) {
                if (jobTotal > 0) {
                    LinearProgressIndicator(
                        progress = { current.toFloat() / jobTotal.coerceAtLeast(1) },
                        modifier = Modifier.fillMaxWidth(),
                    )
                } else {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
                Text(jobMessage ?: "Фоновая задача выполняется", style = MaterialTheme.typography.bodySmall)
                Text("Операция: ${operationLabel(jobOperation)}", style = MaterialTheme.typography.bodySmall)
                if (jobState == OfflinePrepareService.STATE_WAITING_NETWORK) {
                    Text(
                        "Соединение пропало. Фоновая служба сама повторит запрос, а Snapshot продолжится с checkpoint.",
                        color = MaterialTheme.colorScheme.tertiary,
                        style = MaterialTheme.typography.bodySmall,
                    )
                } else if (jobStage == "snapshot" || jobStage == "images") {
                    Text("Можно свернуть приложение — работа продолжится в фоне.", style = MaterialTheme.typography.bodySmall)
                }
            }

            Button(
                onClick = { start(OfflinePrepareService.OP_REFRESH) },
                enabled = !running,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    when {
                        running -> "ОБНОВЛЕНИЕ ИДЁТ В ФОНЕ"
                        deltaCursor.isNullOrBlank() && checkpointCurrent > 0 -> "ПРОДОЛЖИТЬ OFFLINE"
                        deltaCursor.isNullOrBlank() -> "ПОДГОТОВИТЬ OFFLINE"
                        else -> "DELTA SYNC / ОБНОВИТЬ OFFLINE"
                    }
                )
            }

            if (running) {
                OutlinedButton(
                    onClick = { OfflinePrepareService.stop(context) },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Остановить фоновую задачу") }
            }

            when (jobState) {
                OfflinePrepareService.STATE_READY -> Text(
                    jobMessage ?: "✓ OFFLINE READY",
                    color = MaterialTheme.colorScheme.primary,
                )
                OfflinePrepareService.STATE_ERROR -> Text(
                    jobMessage ?: "Ошибка фонового обновления",
                    color = MaterialTheme.colorScheme.error,
                )
            }

            HorizontalDivider()
            Text("Восстановление Offline", style = MaterialTheme.typography.titleMedium)
            Text(
                "Эти команды нужны, если локальные данные или фотографии выглядят устаревшими. Обычная ежедневная работа должна идти через Delta Sync.",
                style = MaterialTheme.typography.bodySmall,
            )

            OutlinedButton(
                onClick = { requestFullReset(OfflinePrepareService.OP_PRODUCTS) },
                enabled = !running,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Перекачать все товары") }

            OutlinedButton(
                onClick = { requestFullReset(OfflinePrepareService.OP_PRODUCTS_AND_PHOTOS) },
                enabled = !running && imageMode != "none",
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Перекачать товары + фото") }

            OutlinedButton(
                onClick = { start(OfflinePrepareService.OP_PHOTOS) },
                enabled = !running && imageMode != "none",
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Перекачать только фото") }

            OutlinedButton(
                onClick = { start(OfflinePrepareService.OP_VERIFY_PHOTOS) },
                enabled = !running && imageMode != "none",
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Проверить / восстановить фото") }

            Text(
                "«Проверить фото» сравнивает только лёгкую ревизию файла (время изменения + размер) и скачивает лишь отсутствующие или изменённые файлы — даже если имя картинки осталось тем же.",
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}

private fun formatTimestamp(raw: String?): String {
    val millis = raw?.toLongOrNull() ?: return "—"
    return SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(millis))
}

private fun operationLabel(raw: String?): String = when (raw) {
    OfflinePrepareService.OP_PRODUCTS -> "все товары"
    OfflinePrepareService.OP_PRODUCTS_AND_PHOTOS -> "товары + фото"
    OfflinePrepareService.OP_PHOTOS -> "только фото"
    OfflinePrepareService.OP_VERIFY_PHOTOS -> "проверка фото"
    else -> "обычное обновление"
}
