package de.handeltheke.handeldesk.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import de.handeltheke.handeldesk.HandelDeskApp
import de.handeltheke.handeldesk.data.repo.LocalPhotoRepository
import de.handeltheke.handeldesk.ui.ScreenHeader
import de.handeltheke.handeldesk.ui.components.EmptyState
import de.handeltheke.handeldesk.ui.components.SectionCard
import de.handeltheke.handeldesk.ui.components.StatusBadge
import de.handeltheke.handeldesk.ui.components.UriImage
import kotlinx.coroutines.launch

@Composable
fun PhotoInboxScreen(productUuid: String, onBack: () -> Unit, onImported: () -> Unit) {
    val app = LocalContext.current.applicationContext as HandelDeskApp
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf(LocalPhotoRepository.WorkspaceStatus(false)) }
    var items by remember { mutableStateOf<List<LocalPhotoRepository.WorkspacePhoto>>(emptyList()) }
    var selected by remember { mutableStateOf<Set<String>>(emptySet()) }
    var loading by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var sortMode by rememberSaveable { mutableStateOf("oldest") }
    var sortMenuOpen by remember { mutableStateOf(false) }

    suspend fun refresh() {
        loading = true
        status = app.container.localPhotos.workspaceStatus()
        items = if (status.configured && status.error == null) app.container.localPhotos.listInbox() else emptyList()
        selected = selected.intersect(items.map { it.uri }.toSet())
        loading = false
    }

    LaunchedEffect(Unit) { refresh() }

    val sortedItems = remember(items, sortMode) {
        when (sortMode) {
            "newest" -> items.sortedWith(compareByDescending<LocalPhotoRepository.WorkspacePhoto> { it.modifiedAt }.thenBy { it.name.lowercase() })
            "name_asc" -> items.sortedBy { it.name.lowercase() }
            "name_desc" -> items.sortedByDescending { it.name.lowercase() }
            else -> items.sortedWith(compareBy<LocalPhotoRepository.WorkspacePhoto> { it.modifiedAt }.thenBy { it.name.lowercase() })
        }
    }

    val workspacePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) scope.launch {
            busy = true
            runCatching { app.container.localPhotos.configureWorkspace(uri) }
                .onSuccess { refresh() }
                .onFailure { message = it.message ?: "Не удалось настроить папку HandelDesk" }
            busy = false
        }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Входящие фото", "Оригиналы не изменяются", onBack)

        if (!status.configured) {
            Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                SectionCard(Modifier.fillMaxWidth()) {
                    Text("Один раз выбери рабочую папку", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Создай или выбери папку HandelDesk. Приложение создаст внутри 01_Eingang, 02_Bearbeitet и 03_Hochgeladen. Перед работой просто переноси оригиналы камеры в 01_Eingang.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Button(onClick = { workspacePicker.launch(null) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                        Text("ВЫБРАТЬ ПАПКУ HANDELDESK")
                    }
                }
                Text(
                    "Важно: выбирай корневую папку HandelDesk, а не 01_Eingang. Crop и уменьшение применяются только к внутренней рабочей копии; оригинальный файл переносится между статусными папками без перекодирования.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        } else {
            Column(Modifier.padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatusBadge("Eingang ${status.inboxCount}", "primary")
                    StatusBadge("Bearbeitet ${status.processedCount}", "warn")
                    StatusBadge("Hochgeladen ${status.uploadedCount}", "ok")
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(status.rootName.ifBlank { "HandelDesk" }, style = MaterialTheme.typography.labelLarge)
                    TextButton(onClick = { workspacePicker.launch(null) }) { Text("Сменить папку") }
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Сортировка", style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.weight(1f))
                    Box {
                        OutlinedButton(onClick = { sortMenuOpen = true }) {
                            Text(when (sortMode) {
                                "newest" -> "Новые → старые"
                                "name_asc" -> "Имя A → Z"
                                "name_desc" -> "Имя Z → A"
                                else -> "Старые → новые"
                            })
                        }
                        DropdownMenu(expanded = sortMenuOpen, onDismissRequest = { sortMenuOpen = false }) {
                            listOf(
                                "oldest" to "Старые → новые",
                                "newest" to "Новые → старые",
                                "name_asc" to "Имя A → Z",
                                "name_desc" to "Имя Z → A",
                            ).forEach { (key, label) ->
                                DropdownMenuItem(
                                    text = { Text(label) },
                                    onClick = { sortMode = key; sortMenuOpen = false },
                                    leadingIcon = { if (sortMode == key) Text("✓") },
                                )
                            }
                        }
                    }
                }
                status.error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }

            if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
            if (!loading && items.isEmpty()) {
                EmptyState("Eingang пуст", "Перенеси нужные оригиналы в 01_Eingang — они появятся здесь.", Modifier.weight(1f))
            } else {
                LazyColumn(
                    Modifier.weight(1f),
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(sortedItems, key = { it.uri }) { photo ->
                        val checked = photo.uri in selected
                        ElevatedCard(
                            Modifier.fillMaxWidth().clickable {
                                selected = if (checked) selected - photo.uri else selected + photo.uri
                            }
                        ) {
                            Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Checkbox(checked = checked, onCheckedChange = { value ->
                                    selected = if (value) selected + photo.uri else selected - photo.uri
                                })
                                UriImage(photo.uri, size = 76.dp)
                                Column(Modifier.weight(1f)) {
                                    Text(photo.name, style = MaterialTheme.typography.titleSmall, maxLines = 2)
                                    if (photo.size > 0) Text(formatBytes(photo.size), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
                Surface(tonalElevation = 2.dp) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { selected = if (selected.size == sortedItems.size) emptySet() else sortedItems.map { it.uri }.toSet() }) {
                            Text(if (selected.size == sortedItems.size && sortedItems.isNotEmpty()) "Снять все" else "Выбрать все")
                        }
                        Spacer(Modifier.weight(1f))
                        Button(
                            onClick = {
                                scope.launch {
                                    busy = true
                                    runCatching {
                                        app.container.localPhotos.importWorkspaceUris(productUuid, selected.map(Uri::parse))
                                    }.onSuccess { onImported() }
                                        .onFailure { message = it.message ?: "Не удалось добавить фото" }
                                    busy = false
                                }
                            },
                            enabled = selected.isNotEmpty() && !busy,
                        ) { Text(if (busy) "ДОБАВЛЕНИЕ…" else "ДОБАВИТЬ (${selected.size})") }
                    }
                }
            }
        }
    }

    message?.let { text ->
        AlertDialog(
            onDismissRequest = { message = null },
            title = { Text("Фото") },
            text = { Text(text) },
            confirmButton = { TextButton(onClick = { message = null }) { Text("OK") } },
        )
    }
}

private fun formatBytes(bytes: Long): String = when {
    bytes >= 1024L * 1024L -> "%.1f MB".format(bytes.toDouble() / (1024.0 * 1024.0))
    bytes >= 1024L -> "%.0f KB".format(bytes.toDouble() / 1024.0)
    else -> "$bytes B"
}
