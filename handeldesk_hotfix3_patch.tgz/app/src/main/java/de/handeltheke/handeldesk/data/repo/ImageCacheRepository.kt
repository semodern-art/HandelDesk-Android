package de.handeltheke.handeldesk.data.repo

import android.content.Context
import de.handeltheke.handeldesk.data.local.HandelDeskDatabase
import de.handeltheke.handeldesk.data.remote.BridgeClient
import de.handeltheke.handeldesk.data.remote.BridgeException
import de.handeltheke.handeldesk.domain.JsonTools
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.*
import java.io.EOFException
import java.io.File
import java.io.IOException
import java.net.ConnectException
import java.net.SocketException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.security.MessageDigest
import javax.net.ssl.SSLHandshakeException

class ImageCacheRepository(
    context: Context,
    private val db: HandelDeskDatabase,
    private val bridge: BridgeClient,
) {
    private val root = File(context.filesDir, "image-cache").apply { mkdirs() }

    data class Progress(val current: Int, val total: Int, val path: String)
    private data class ImageRef(val revision: String?, val mtime: Long?, val size: Long?)
    data class VerifySummary(
        val checked: Int,
        val downloaded: Int,
        val removed: Int,
        val unchanged: Int,
    ) {
        fun userText() = "Фото: проверено $checked · обновлено $downloaded · удалено $removed · без изменений $unchanged"
    }

    fun cachedFile(remotePath: String): File? {
        if (remotePath.isBlank()) return null
        val file = fileFor(remotePath)
        return file.takeIf { it.isFile && it.length() > 0 }
    }

    suspend fun cache(
        remotePath: String,
        expectedRevision: String? = null,
        expectedMtime: Long? = null,
        expectedSize: Long? = null,
        force: Boolean = false,
    ): File = withContext(Dispatchers.IO) {
        require(remotePath.isNotBlank()) { "Пустой путь изображения" }
        val target = fileFor(remotePath)
        val revisionFile = revisionFileFor(remotePath)
        val localRevision = revisionFile.takeIf(File::isFile)?.readText()?.trim().orEmpty()

        val reusable = target.isFile && target.length() > 0 && !force && (
            expectedRevision.isNullOrBlank() || localRevision == expectedRevision
        )
        if (reusable) return@withContext target

        // Migration from pre-0.1.4 cache: no .rev sidecar existed yet. If the cached file
        // was downloaded after the server file's mtime and has the same size, adopt it
        // without re-downloading thousands of unchanged photos.
        if (!force && target.isFile && target.length() > 0 && localRevision.isBlank() &&
            !expectedRevision.isNullOrBlank() && expectedMtime != null && expectedSize != null &&
            target.length() == expectedSize && target.lastModified() + 2_000L >= expectedMtime * 1000L
        ) {
            revisionFile.writeText(expectedRevision)
            return@withContext target
        }

        val bytes = bridge.getBytes("image_fetch", mapOf("path" to remotePath))
        require(bytes.size >= 16) { "Bridge вернул пустое изображение" }
        val tmp = File(target.parentFile, target.name + ".tmp")
        tmp.writeBytes(bytes)
        if (target.exists()) target.delete()
        require(tmp.renameTo(target)) { "Не удалось сохранить кеш изображения" }

        if (!expectedRevision.isNullOrBlank()) {
            revisionFile.writeText(expectedRevision)
        } else if (revisionFile.exists()) {
            revisionFile.delete()
        }
        target
    }

    suspend fun prepare(mode: String, onProgress: suspend (Progress) -> Unit = {}) {
        if (mode == "none") return
        onProgress(Progress(0, 0, "Считаем уникальные фото"))
        val refs = collectImageRefs(mode)
        val total = refs.size
        if (total == 0) {
            onProgress(Progress(0, 0, "Готово"))
            return
        }
        var processed = 0
        for ((path, ref) in refs) {
            processed++
            onProgress(Progress(processed, total, path))
            try {
                cache(path, ref.revision, ref.mtime, ref.size)
            } catch (t: Throwable) {
                if (isRetryableNetworkError(t)) throw t
                // One broken/removed image must not abort the complete offline package.
            }
        }
        onProgress(Progress(processed, total, "Готово"))
    }

    /**
     * Compares local cached files with the server's cheap image manifest (mtime + filesize).
     * Products are scanned from Room in small keyset batches, so a large catalog never loads
     * all ProductEntity/baseJson/localJson values into the Android heap at once.
     */
    suspend fun verifyAndRepair(
        mode: String,
        onProgress: suspend (Progress) -> Unit = {},
    ): VerifySummary {
        if (mode == "none") return VerifySummary(0, 0, 0, 0)
        onProgress(Progress(0, 0, "Считаем уникальные фото"))
        val refs = collectImageRefs(mode)
        val totalHint = refs.size
        var checked = 0
        var downloaded = 0
        var removed = 0
        var unchanged = 0
        val chunk = ArrayList<String>(MANIFEST_CHUNK_SIZE)

        suspend fun flushChunk() {
            if (chunk.isEmpty()) return
            val body = buildJsonObject {
                put("paths", JsonArray(chunk.map { JsonPrimitive(it) }))
            }
            val root = bridge.post("image_manifest", body)
            val manifest = (root["images"] as? JsonObject).orEmpty()

            for (path in chunk) {
                val meta = manifest[path] as? JsonObject
                val exists = meta?.get("exists")?.jsonPrimitive?.booleanOrNull == true
                val revision = meta?.get("revision")?.jsonPrimitive?.contentOrNull.orEmpty()
                val serverMtime = meta?.get("mtime")?.jsonPrimitive?.longOrNull
                val serverSize = meta?.get("size")?.jsonPrimitive?.longOrNull
                val target = fileFor(path)
                val revFile = revisionFileFor(path)
                val localRevision = revFile.takeIf(File::isFile)?.readText()?.trim().orEmpty()

                checked++
                onProgress(Progress(checked, totalHint, path))

                if (!exists) {
                    var changed = false
                    if (target.exists()) changed = target.delete() || changed
                    if (revFile.exists()) changed = revFile.delete() || changed
                    if (changed) removed++ else unchanged++
                    continue
                }

                if (!target.isFile || target.length() <= 0 || revision.isBlank() || localRevision != revision) {
                    try {
                        val canAdoptLegacy = localRevision.isBlank() && target.isFile && target.length() > 0 &&
                            revision.isNotBlank() && serverSize != null && target.length() == serverSize &&
                            serverMtime != null && target.lastModified() + 2_000L >= serverMtime * 1000L
                        cache(
                            path,
                            revision.takeIf(String::isNotBlank),
                            serverMtime,
                            serverSize,
                            force = false,
                        )
                        if (canAdoptLegacy) unchanged++ else downloaded++
                    } catch (t: Throwable) {
                        if (isRetryableNetworkError(t)) throw t
                        // Keep going when a single image is broken on the server.
                    }
                } else {
                    unchanged++
                }
            }
            chunk.clear()
        }

        for (path in refs.keys) {
            chunk += path
            if (chunk.size >= MANIFEST_CHUNK_SIZE) flushChunk()
        }
        flushChunk()
        onProgress(Progress(checked, checked, "Готово"))
        return VerifySummary(checked, downloaded, removed, unchanged)
    }

    suspend fun clearAll(): Int = withContext(Dispatchers.IO) {
        val files = root.listFiles().orEmpty()
        var deleted = 0
        for (file in files) {
            if (file.isFile && file.delete()) deleted++
        }
        deleted
    }

    suspend fun cacheStats(): Pair<Int, Long> = withContext(Dispatchers.IO) {
        val files = root.listFiles()?.filter { it.isFile && !it.name.endsWith(".rev") }.orEmpty()
        files.size to files.sumOf(File::length)
    }

    private suspend fun collectImageRefs(mode: String): LinkedHashMap<String, ImageRef> {
        val refs = LinkedHashMap<String, ImageRef>()
        var afterUuid = ""

        while (true) {
            val rows = db.products().jsonScanBatch(afterUuid, PRODUCT_SCAN_BATCH_SIZE)
            if (rows.isEmpty()) break

            for (row in rows) {
                val payload = JsonTools.objectOf(row.localJson)
                val imageMeta = (payload["image_meta"] as? JsonObject).orEmpty()

                fun add(rawPath: String) {
                    val path = normalizeRemotePath(rawPath)
                    if (path.isBlank()) return

                    // image_meta normally uses the exact product path. Try both the raw key and
                    // the normalized key so old snapshots remain compatible after normalization.
                    val rawKey = rawPath.trim()
                    val meta = (imageMeta[rawKey] as? JsonObject) ?: (imageMeta[path] as? JsonObject)
                    val incoming = ImageRef(
                        revision = meta?.get("revision")?.jsonPrimitive?.contentOrNull?.takeIf(String::isNotBlank),
                        mtime = meta?.get("mtime")?.jsonPrimitive?.longOrNull,
                        size = meta?.get("size")?.jsonPrimitive?.longOrNull,
                    )
                    val existing = refs[path]
                    refs[path] = if (existing == null) incoming else mergeImageRef(existing, incoming)
                }

                val main = (payload["product"] as? JsonObject)?.get("image")?.jsonPrimitive?.contentOrNull.orEmpty()
                add(main)
                if (mode == "all") {
                    (payload["images"] as? JsonArray).orEmpty().forEach { imageRow ->
                        add((imageRow as? JsonObject)?.get("image")?.jsonPrimitive?.contentOrNull.orEmpty())
                    }
                }
            }

            val next = rows.last().uuid
            if (next <= afterUuid) error("Локальный image scan checkpoint не продвигается")
            afterUuid = next
        }
        return refs
    }

    private fun mergeImageRef(a: ImageRef, b: ImageRef): ImageRef = ImageRef(
        revision = b.revision ?: a.revision,
        mtime = b.mtime ?: a.mtime,
        size = b.size ?: a.size,
    )

    /** Match Bridge safeImagePath normalization without changing case on a case-sensitive server. */
    private fun normalizeRemotePath(rawPath: String): String {
        var path = rawPath.trim().replace('\\', '/')
        path = path.trimStart('/')
        while ("//" in path) path = path.replace("//", "/")
        return path
    }

    private fun isRetryableNetworkError(t: Throwable): Boolean {
        var current: Throwable? = t
        while (current != null) {
            when (current) {
                is UnknownHostException,
                is ConnectException,
                is SocketTimeoutException,
                is SocketException,
                is EOFException -> return true
                is SSLHandshakeException -> return false
                is BridgeException -> {
                    val status = current.status
                    return status == 408 || status == 429 || (status != null && status in 500..599)
                }
                is IOException -> return true
            }
            current = current.cause
        }
        return false
    }

    private fun fileFor(remotePath: String): File {
        val normalized = normalizeRemotePath(remotePath)
        val digest = pathDigest(normalized)
        val ext = normalized.substringAfterLast('.', "img").lowercase()
            .takeIf { it in setOf("jpg", "jpeg", "png", "gif", "webp") } ?: "img"
        return File(root, "$digest.$ext")
    }

    private fun revisionFileFor(remotePath: String): File = File(root, "${pathDigest(normalizeRemotePath(remotePath))}.rev")

    private fun pathDigest(remotePath: String): String = MessageDigest.getInstance("SHA-256")
        .digest(remotePath.toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it) }

    private companion object {
        const val PRODUCT_SCAN_BATCH_SIZE = 50
        const val MANIFEST_CHUNK_SIZE = 200
    }

}
