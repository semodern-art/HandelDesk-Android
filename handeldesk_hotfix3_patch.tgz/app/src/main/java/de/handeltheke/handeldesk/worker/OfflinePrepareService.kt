package de.handeltheke.handeldesk.worker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.ContextCompat
import androidx.core.app.NotificationCompat
import de.handeltheke.handeldesk.HandelDeskApp
import de.handeltheke.handeldesk.data.local.SettingEntity
import de.handeltheke.handeldesk.data.remote.BridgeException
import de.handeltheke.handeldesk.data.remote.BridgeNetworkException
import de.handeltheke.handeldesk.data.repo.ImageCacheRepository
import de.handeltheke.handeldesk.data.repo.SnapshotRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.EOFException
import java.io.IOException
import java.net.ConnectException
import java.net.SocketException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import javax.net.ssl.SSLHandshakeException

class OfflinePrepareService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var app: HandelDeskApp
    private var syncJob: Job? = null
    private var lastImagePublished = -1
    private var completed = false

    override fun onCreate() {
        super.onCreate()
        app = application as HandelDeskApp
        createNotificationChannel()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            scope.launch {
                publishState(STATE_CANCELLED, "Фоновая задача остановлена. Checkpoint сохранён.", 0, 0, "cancelled", notify = false)
                completed = true
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            return START_NOT_STICKY
        }

        if (syncJob?.isActive == true) return START_STICKY

        val requestedImageMode = intent?.getStringExtra(EXTRA_IMAGE_MODE)
            ?.takeIf { it in setOf("none", "main", "all") }
        val requestedOperation = intent?.getStringExtra(EXTRA_OPERATION)
            ?.takeIf { it in OPERATIONS }
        val requestedPreserve = if (intent?.hasExtra(EXTRA_PRESERVE_LOCAL) == true) {
            intent.getBooleanExtra(EXTRA_PRESERVE_LOCAL, true)
        } else null

        startAsForeground("Запуск фонового обновления", 0, 0)
        syncJob = scope.launch { runSyncLoop(requestedImageMode, requestedOperation, requestedPreserve) }
        return START_STICKY
    }

    private suspend fun runSyncLoop(
        requestedImageMode: String?,
        requestedOperation: String?,
        requestedPreserve: Boolean?,
    ) {
        val settings = app.container.db.settings()
        var imageMode = requestedImageMode
            ?: settings.get("offline_image_mode")?.takeIf { it in setOf("none", "main", "all") }
            ?: "main"
        var operation = requestedOperation
            ?: settings.get("offline_job_operation")?.takeIf { it in OPERATIONS }
            ?: OP_REFRESH
        var preserveLocal = requestedPreserve
            ?: settings.get("offline_job_preserve_local")?.toBooleanStrictOrNull()
            ?: true

        if (requestedImageMode != null) settings.put(SettingEntity("offline_image_mode", imageMode))
        if (requestedOperation != null) {
            operation = requestedOperation
            settings.put(SettingEntity("offline_job_operation", operation))
            settings.put(SettingEntity("offline_job_initialized", "0"))
        }
        if (requestedPreserve != null) {
            preserveLocal = requestedPreserve
            settings.put(SettingEntity("offline_job_preserve_local", preserveLocal.toString()))
        }

        var initialized = settings.get("offline_job_initialized") == "1"

        while (scope.isActive) {
            try {
                imageMode = settings.get("offline_image_mode")
                    ?.takeIf { it in setOf("none", "main", "all") }
                    ?: imageMode

                if (!initialized) {
                    // Never delete/rebuild local offline data before we know the Bridge is reachable
                    // and the device configuration (URL/token) is valid. This prevents a reset from
                    // destroying a useful offline cache while the server is unavailable.
                    if (operation == OP_PRODUCTS || operation == OP_PRODUCTS_AND_PHOTOS || operation == OP_PHOTOS) {
                        publishState(
                            STATE_RUNNING,
                            "Проверка Bridge перед очисткой локальных данных",
                            0,
                            0,
                            "preflight",
                            notify = true,
                        )
                        app.container.bridge.get("schema")
                        if (operation == OP_PRODUCTS || operation == OP_PRODUCTS_AND_PHOTOS) {
                            // The Settings test checks only schema. A destructive full reload needs
                            // the endpoints used immediately afterwards to be reachable too.
                            publishState(
                                STATE_RUNNING,
                                "Проверка Offline API перед очисткой",
                                0,
                                0,
                                "preflight",
                                notify = true,
                            )
                            app.container.bridge.get("reference")
                            app.container.bridge.get("snapshot", mapOf("after_id" to "0", "per_page" to "1"))
                        }
                    }
                    initializeOperation(operation, preserveLocal)
                    settings.put(SettingEntity("offline_job_initialized", "1"))
                    initialized = true
                }

                when (operation) {
                    OP_PHOTOS -> {
                        publishState(STATE_RUNNING, "Перекачиваем фото", 0, 0, "images", notify = true)
                        app.container.imageCache.prepare(imageMode) { p -> publishImageProgress(p) }
                        val stats = app.container.imageCache.cacheStats()
                        finishReady("✓ ФОТО ПЕРЕКАЧАНЫ · ${stats.first} файлов")
                    }

                    OP_VERIFY_PHOTOS -> {
                        publishState(STATE_RUNNING, "Проверяем ревизии фото", 0, 0, "images", notify = true)
                        val result = app.container.imageCache.verifyAndRepair(imageMode) { p -> publishImageProgress(p) }
                        finishReady("✓ ПРОВЕРКА ФОТО · ${result.userText()}")
                    }

                    else -> {
                        publishState(STATE_RUNNING, "Проверка соединения", 0, 0, "start", notify = true)
                        val summary = app.container.snapshot.refresh { p -> publishSnapshotProgress(p) }
                        app.container.imageCache.prepare(imageMode) { p -> publishImageProgress(p) }
                        val stats = app.container.imageCache.cacheStats()
                        finishReady("✓ OFFLINE READY · ${summary.userText()} · фото ${stats.first}")
                    }
                }
                return
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (t: Throwable) {
                if (isRetryableNetworkError(t)) {
                    publishState(
                        STATE_WAITING_NETWORK,
                        "Сеть недоступна: ${networkErrorText(t)}. Checkpoint сохранён — повтор через 15 секунд.",
                        0,
                        0,
                        "network",
                        notify = true,
                    )
                    delay(RETRY_DELAY_MS)
                } else {
                    val message = "Ошибка: ${t.message ?: t::class.java.simpleName}"
                    publishState(STATE_ERROR, message, 0, 0, "error", notify = false)
                    completed = true
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                    return
                }
            }
        }
    }

    private suspend fun initializeOperation(operation: String, preserveLocal: Boolean) {
        when (operation) {
            OP_PRODUCTS -> {
                publishState(STATE_RUNNING, "Удаляем локальную серверную копию товаров", 0, 0, "reset", notify = true)
                app.container.snapshot.prepareFullReload(preserveLocal)
            }
            OP_PRODUCTS_AND_PHOTOS -> {
                publishState(STATE_RUNNING, "Полный сброс товаров и кеша фото", 0, 0, "reset", notify = true)
                app.container.snapshot.prepareFullReload(preserveLocal)
                app.container.imageCache.clearAll()
            }
            OP_PHOTOS -> {
                publishState(STATE_RUNNING, "Очищаем кеш фото", 0, 0, "reset", notify = true)
                app.container.imageCache.clearAll()
            }
            OP_VERIFY_PHOTOS, OP_REFRESH -> Unit
        }
    }

    private suspend fun finishReady(message: String) {
        app.container.db.settings().put(SettingEntity("offline_job_initialized", "0"))
        publishState(STATE_READY, message, 0, 0, "done", notify = false)
        completed = true
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private suspend fun publishSnapshotProgress(p: SnapshotRepository.Progress) {
        publishState(STATE_RUNNING, p.message, p.current, p.total, "snapshot", notify = true)
    }

    private suspend fun publishImageProgress(p: ImageCacheRepository.Progress) {
        val shouldPublish = p.current == p.total || p.current == 0 || p.current - lastImagePublished >= 10
        if (!shouldPublish) return
        lastImagePublished = p.current
        val name = p.path.takeLast(60)
        publishState(
            STATE_RUNNING,
            if (p.total > 0) "Фото ${p.current}/${p.total}: $name" else "Подготовка фото",
            p.current,
            p.total,
            "images",
            notify = true,
        )
    }

    private suspend fun publishState(
        state: String,
        message: String,
        current: Int,
        total: Int,
        stage: String,
        notify: Boolean,
    ) {
        val settings = app.container.db.settings()
        settings.put(SettingEntity("offline_job_state", state))
        settings.put(SettingEntity("offline_job_message", message))
        settings.put(SettingEntity("offline_job_current", current.toString()))
        settings.put(SettingEntity("offline_job_total", total.toString()))
        settings.put(SettingEntity("offline_job_stage", stage))
        settings.put(SettingEntity("offline_job_updated_at", System.currentTimeMillis().toString()))
        if (notify) updateNotification(message, current, total)
    }

    private fun startAsForeground(message: String, current: Int, total: Int) {
        val notification = buildNotification(message, current, total)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun updateNotification(message: String, current: Int, total: Int) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, buildNotification(message, current, total))
    }

    private fun buildNotification(message: String, current: Int, total: Int) =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("HandelDesk · Offline")
            .setContentText(message)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setProgress(total.coerceAtLeast(0), current.coerceAtLeast(0), total <= 0)
            .build()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "HandelDesk Offline Sync", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Фоновая подготовка каталога и изображений для офлайн-работы"
                    setShowBadge(false)
                }
            )
        }
    }

    private fun isRetryableNetworkError(t: Throwable): Boolean {
        var current: Throwable? = t
        while (current != null) {
            when (current) {
                is UnknownHostException,
                is ConnectException,
                is SocketTimeoutException,
                is SocketException,
                is EOFException -> return true
                is SSLHandshakeException -> return false
                is BridgeException -> {
                    // status == null is normally a local/configuration/protocol error
                    // (for example missing Device Token or Bridge URL), not a network outage.
                    val status = current.status
                    return status == 408 || status == 429 || (status != null && status in 500..599)
                }
                is IOException -> return true
            }
            current = current.cause
        }
        return false
    }

    private fun networkErrorText(t: Throwable): String {
        var current: Throwable? = t
        while (current != null) {
            when (current) {
                is BridgeNetworkException -> return current.message ?: "сетевой сбой Bridge"
                is UnknownHostException -> return "DNS: ${current.message ?: "имя сервера не найдено"}"
                is ConnectException -> return "сервер недоступен: ${current.message ?: "ошибка соединения"}"
                is SocketTimeoutException -> return "таймаут: ${current.message ?: "сервер не ответил"}"
                is SocketException -> return "соединение прервано: ${current.message ?: "socket error"}"
                is EOFException -> return "сервер преждевременно закрыл соединение"
                is IOException -> return current.message ?: current::class.java.simpleName
            }
            current = current.cause
        }
        return t.message ?: t::class.java.simpleName
    }

    override fun onTimeout(startId: Int, fgsType: Int) {
        scope.launch {
            publishState(
                STATE_ERROR,
                "Android остановил длительную фоновую синхронизацию по системному лимиту. Checkpoint сохранён — открой приложение и продолжи.",
                0,
                0,
                "timeout",
                notify = false,
            )
            completed = true
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf(startId)
        }
    }

    override fun onDestroy() {
        if (!completed && syncJob?.isActive == true) syncJob?.cancel()
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val STATE_RUNNING = "RUNNING"
        const val STATE_WAITING_NETWORK = "WAITING_NETWORK"
        const val STATE_READY = "READY"
        const val STATE_ERROR = "ERROR"
        const val STATE_CANCELLED = "CANCELLED"

        const val OP_REFRESH = "refresh"
        const val OP_PRODUCTS = "products"
        const val OP_PRODUCTS_AND_PHOTOS = "products_photos"
        const val OP_PHOTOS = "photos"
        const val OP_VERIFY_PHOTOS = "verify_photos"
        private val OPERATIONS = setOf(OP_REFRESH, OP_PRODUCTS, OP_PRODUCTS_AND_PHOTOS, OP_PHOTOS, OP_VERIFY_PHOTOS)

        private const val ACTION_START = "de.handeltheke.handeldesk.action.PREPARE_OFFLINE"
        private const val ACTION_STOP = "de.handeltheke.handeldesk.action.STOP_PREPARE_OFFLINE"
        private const val EXTRA_IMAGE_MODE = "image_mode"
        private const val EXTRA_OPERATION = "operation"
        private const val EXTRA_PRESERVE_LOCAL = "preserve_local"
        private const val CHANNEL_ID = "handeldesk_offline_sync"
        private const val NOTIFICATION_ID = 43013
        private const val RETRY_DELAY_MS = 15_000L

        fun start(
            context: Context,
            imageMode: String,
            operation: String = OP_REFRESH,
            preserveLocalChanges: Boolean = true,
        ) {
            val intent = Intent(context, OfflinePrepareService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_IMAGE_MODE, imageMode)
                .putExtra(EXTRA_OPERATION, operation)
                .putExtra(EXTRA_PRESERVE_LOCAL, preserveLocalChanges)
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, OfflinePrepareService::class.java).setAction(ACTION_STOP)
            context.startService(intent)
        }
    }
}
