package de.handeltheke.handeldesk.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val LightColors = lightColorScheme(
    primary = Color(0xFF315C9A),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD9E6FF),
    onPrimaryContainer = Color(0xFF0B2F5D),
    secondary = Color(0xFF48647F),
    secondaryContainer = Color(0xFFD5E4F4),
    tertiary = Color(0xFF3B6E62),
    tertiaryContainer = Color(0xFFBEEBDD),
    background = Color(0xFFF7F8FB),
    surface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFFE8ECF2),
    outline = Color(0xFF77818E),
    error = Color(0xFFBA1A1A),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFA9C7FF),
    onPrimary = Color(0xFF00315F),
    primaryContainer = Color(0xFF174776),
    onPrimaryContainer = Color(0xFFD7E7FF),
    secondary = Color(0xFFB5C9E2),
    secondaryContainer = Color(0xFF304961),
    tertiary = Color(0xFFA3D0C4),
    tertiaryContainer = Color(0xFF225047),
    background = Color(0xFF111318),
    surface = Color(0xFF17191F),
    surfaceVariant = Color(0xFF333840),
    outline = Color(0xFF9099A6),
)

private val AppShapes = Shapes(
    extraSmall = androidx.compose.foundation.shape.RoundedCornerShape(8.dp),
    small = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
    medium = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
    large = androidx.compose.foundation.shape.RoundedCornerShape(22.dp),
    extraLarge = androidx.compose.foundation.shape.RoundedCornerShape(28.dp),
)

@Composable
fun HandelDeskTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        shapes = AppShapes,
        typography = Typography(),
        content = content,
    )
}
