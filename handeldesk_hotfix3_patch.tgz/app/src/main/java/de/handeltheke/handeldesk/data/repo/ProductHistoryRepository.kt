package de.handeltheke.handeldesk.data.repo

import android.content.Context
import androidx.room.withTransaction
import de.handeltheke.handeldesk.data.local.*
import de.handeltheke.handeldesk.domain.JsonTools
import kotlinx.serialization.json.*
import java.io.File

class ProductHistoryRepository(private val context: Context, private val db: HandelDeskDatabase) {
    companion object { const val MAX_PER_PRODUCT = 20 }

    suspend fun captureCurrent(productUuid: String, actionType: String, summary: String): Long? = db.withTransaction {
        val product = db.products().get(productUuid) ?: return@withTransaction null
        val photoJson = encodePhotos(db.photos().forProduct(productUuid))
        val changeJson = encodeChanges(db.changes().pendingForEntity("product", productUuid))
        val queue = db.queue().get(productUuid)
        val latest = db.history().latest(productUuid)
        if (latest != null &&
            latest.actionType == actionType &&
            latest.summary == summary &&
            latest.productIdAtCapture == product.productId &&
            latest.baseRevisionAtCapture == product.baseRevision &&
            latest.baseJsonAtCapture == product.baseJson &&
            latest.stateAtCapture == product.state &&
            latest.localJson == product.localJson &&
            latest.localNote == product.localNote &&
            latest.workflowState == product.workflowState &&
            latest.isDraft == product.isDraft &&
            latest.photoSnapshotJson == photoJson &&
            latest.changeSnapshotJson == changeJson &&
            latest.queuePosition == queue?.position &&
            latest.queueCreatedAt == queue?.createdAt
        ) {
            return@withTransaction latest.id
        }
        val id = db.history().insert(
            ProductHistoryEntity(
                productUuid = product.uuid,
                productIdAtCapture = product.productId,
                createdAt = System.currentTimeMillis(),
                actionType = actionType,
                summary = summary,
                localJson = product.localJson,
                localNote = product.localNote,
                workflowState = product.workflowState,
                isDraft = product.isDraft,
                stateAtCapture = product.state,
                baseRevisionAtCapture = product.baseRevision,
                baseJsonAtCapture = product.baseJson,
                photoSnapshotJson = photoJson,
                changeSnapshotJson = changeJson,
                queuePosition = queue?.position,
                queueCreatedAt = queue?.createdAt,
            )
        )
        db.history().trim(productUuid, MAX_PER_PRODUCT)
        id
    }.also { cleanupPrivatePhotoOrphans(productUuid) }

    private suspend fun cleanupPrivatePhotoOrphans(productUuid: String) {
        val keepIds = mutableSetOf<String>()
        keepIds += db.photos().forProduct(productUuid).map { it.id }
        db.history().listForProduct(productUuid, MAX_PER_PRODUCT).forEach { point ->
            keepIds += decodePhotos(point.photoSnapshotJson).map { it.id }
        }
        val root = File(context.filesDir, "handeldesk_photos/$productUuid")
        root.listFiles()?.filter { it.isDirectory && it.name !in keepIds }?.forEach { dir ->
            runCatching { dir.deleteRecursively() }
        }
    }

    fun encodeChanges(rows: List<ChangeEntity>): String = buildJsonArray {
        rows.sortedWith(compareBy<ChangeEntity> { it.createdAt }.thenBy { it.id }).forEach { c ->
            add(buildJsonObject {
                c.sessionId?.let { put("sessionId", it) }
                put("entityType", c.entityType)
                put("entityUuid", c.entityUuid)
                put("fieldPath", c.fieldPath)
                c.beforeJson?.let { put("beforeJson", it) } ?: put("beforeJson", JsonNull)
                c.afterJson?.let { put("afterJson", it) } ?: put("afterJson", JsonNull)
                put("operationType", c.operationType)
                put("included", c.included)
                put("createdAt", c.createdAt)
            })
        }
    }.toString()

    fun decodeChanges(text: String, productUuid: String): List<ChangeEntity> = runCatching {
        JsonTools.json.parseToJsonElement(text).jsonArray.mapNotNull { e ->
            val o = e as? JsonObject ?: return@mapNotNull null
            val fieldPath = o["fieldPath"]?.jsonPrimitive?.contentOrNull.orEmpty()
            if (fieldPath.isBlank()) return@mapNotNull null
            ChangeEntity(
                sessionId = o["sessionId"]?.jsonPrimitive?.contentOrNull,
                entityType = "product",
                entityUuid = productUuid,
                fieldPath = fieldPath,
                beforeJson = o["beforeJson"]?.takeUnless { it is JsonNull }?.jsonPrimitive?.contentOrNull,
                afterJson = o["afterJson"]?.takeUnless { it is JsonNull }?.jsonPrimitive?.contentOrNull,
                operationType = o["operationType"]?.jsonPrimitive?.contentOrNull ?: "set",
                synced = false,
                included = o["included"]?.jsonPrimitive?.booleanOrNull ?: true,
                createdAt = o["createdAt"]?.jsonPrimitive?.longOrNull ?: System.currentTimeMillis(),
            )
        }
    }.getOrDefault(emptyList())

    fun encodePhotos(rows: List<LocalPhotoEntity>): String = buildJsonArray {
        rows.sortedWith(compareBy<LocalPhotoEntity> { it.sortOrder }.thenBy { it.createdAt }).forEach { p ->
            add(buildJsonObject {
                put("id", p.id); put("productUuid", p.productUuid); put("fileName", p.fileName)
                put("originalPath", p.originalPath); put("processedPath", p.processedPath)
                put("remoteFolder", p.remoteFolder); put("remotePath", p.remotePath)
                put("isMain", p.isMain); put("sortOrder", p.sortOrder)
                put("cropLeft", p.cropLeft); put("cropTop", p.cropTop); put("cropRight", p.cropRight); put("cropBottom", p.cropBottom)
                put("rotationDegrees", p.rotationDegrees); put("targetWidth", p.targetWidth); put("targetHeight", p.targetHeight)
                put("keepAspect", p.keepAspect); put("doNotEnlarge", p.doNotEnlarge)
                put("sourceWidth", p.sourceWidth); put("sourceHeight", p.sourceHeight)
                put("processedWidth", p.processedWidth); put("processedHeight", p.processedHeight)
                put("sha256", p.sha256); put("status", p.status); put("error", p.error)
                p.sourceUri?.let { put("sourceUri", it) }
                p.sourceStage?.let { put("sourceStage", it) }
                p.sourceError?.let { put("sourceError", it) }
                put("createdAt", p.createdAt)
            })
        }
    }.toString()

    fun decodePhotos(text: String): List<LocalPhotoEntity> = runCatching {
        JsonTools.json.parseToJsonElement(text).jsonArray.mapNotNull { e ->
            val o = e as? JsonObject ?: return@mapNotNull null
            fun s(k: String) = o[k]?.jsonPrimitive?.contentOrNull.orEmpty()
            fun si(k: String) = o[k]?.jsonPrimitive?.intOrNull ?: 0
            fun sl(k: String) = o[k]?.jsonPrimitive?.longOrNull ?: 0L
            fun sf(k: String) = o[k]?.jsonPrimitive?.floatOrNull ?: 0f
            fun sb(k: String, d: Boolean = false) = o[k]?.jsonPrimitive?.booleanOrNull ?: d
            val id = s("id"); val uuid = s("productUuid")
            if (id.isBlank() || uuid.isBlank()) return@mapNotNull null
            LocalPhotoEntity(
                id = id, productUuid = uuid, fileName = s("fileName"), originalPath = s("originalPath"), processedPath = s("processedPath"),
                remoteFolder = s("remoteFolder").ifBlank { "Fernbedienungen" }, remotePath = s("remotePath"), isMain = sb("isMain"), sortOrder = si("sortOrder"),
                cropLeft = sf("cropLeft"), cropTop = sf("cropTop"), cropRight = o["cropRight"]?.jsonPrimitive?.floatOrNull ?: 1f,
                cropBottom = o["cropBottom"]?.jsonPrimitive?.floatOrNull ?: 1f, rotationDegrees = si("rotationDegrees"), targetWidth = si("targetWidth"), targetHeight = si("targetHeight"),
                keepAspect = sb("keepAspect", true), doNotEnlarge = sb("doNotEnlarge", true), sourceWidth = si("sourceWidth"), sourceHeight = si("sourceHeight"),
                processedWidth = si("processedWidth"), processedHeight = si("processedHeight"), sha256 = s("sha256"), status = s("status").ifBlank { "IMPORTED" }, error = s("error"),
                galleryUri = null, galleryState = null, galleryError = null,
                sourceUri = o["sourceUri"]?.jsonPrimitive?.contentOrNull, sourceStage = o["sourceStage"]?.jsonPrimitive?.contentOrNull,
                sourceError = o["sourceError"]?.jsonPrimitive?.contentOrNull, createdAt = sl("createdAt"), updatedAt = System.currentTimeMillis()
            )
        }
    }.getOrDefault(emptyList())
}
