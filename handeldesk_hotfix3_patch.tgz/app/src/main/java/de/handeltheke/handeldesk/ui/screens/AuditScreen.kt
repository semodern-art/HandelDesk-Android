package de.handeltheke.handeldesk.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import de.handeltheke.handeldesk.HandelDeskApp
import de.handeltheke.handeldesk.data.local.AuditEventEntity
import de.handeltheke.handeldesk.domain.JsonTools
import de.handeltheke.handeldesk.ui.ScreenHeader
import kotlinx.coroutines.launch
import kotlinx.serialization.json.longOrNull
import kotlinx.serialization.json.jsonPrimitive
import java.text.DateFormat
import java.util.Date

@Composable
fun AuditScreen(onBack: () -> Unit) {
    val app = LocalContext.current.applicationContext as HandelDeskApp
    val events by app.container.db.audit().observeRecent().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var restoreEvent by remember { mutableStateOf<Pair<AuditEventEntity, Long>?>(null) }
    var existingHistoryIds by remember { mutableStateOf<Set<Long>>(emptySet()) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(events) {
        val ids = events.mapNotNull { event ->
            event.detailsJson?.let { text ->
                runCatching { JsonTools.objectOf(text)["history_id"]?.jsonPrimitive?.longOrNull }.getOrNull()
            }
        }.distinct()
        existingHistoryIds = if (ids.isEmpty()) emptySet() else app.container.db.history().existingIds(ids).toSet()
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Лог действий", "История изменений и служебных операций", onBack)
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(events, key = { it.id }) { event ->
                val historyId = remember(event.detailsJson) {
                    event.detailsJson?.let { text ->
                        runCatching { JsonTools.objectOf(text)["history_id"]?.jsonPrimitive?.longOrNull }.getOrNull()
                    }
                }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(event.summary.ifBlank { event.eventType }, style = MaterialTheme.typography.titleSmall)
                        Text("${DateFormat.getDateTimeInstance().format(Date(event.createdAt))} · ${event.source}", style = MaterialTheme.typography.bodySmall)
                        if (!event.entityUuid.isNullOrBlank()) Text("${event.entityType}: ${event.entityUuid}", style = MaterialTheme.typography.bodySmall)
                        if (historyId != null && historyId in existingHistoryIds && event.entityType == "product") {
                            FilledTonalButton(
                                enabled = !busy,
                                onClick = { restoreEvent = event to historyId },
                                modifier = Modifier.fillMaxWidth(),
                            ) { Text("↩ Вернуть состояние до этого действия") }
                        }
                    }
                }
            }
        }
    }

    restoreEvent?.let { (event, historyId) ->
        AlertDialog(
            onDismissRequest = { if (!busy) restoreEvent = null },
            title = { Text("Выполнить откат?") },
            text = {
                Text(
                    "Будет восстановлено состояние товара ДО действия «${event.summary}». " +
                        "Если товар уже синхронизировался позже, сайт не изменится автоматически — появятся новые локальные изменения для Sync."
                )
            },
            confirmButton = {
                Button(enabled = !busy, onClick = {
                    busy = true
                    scope.launch {
                        runCatching { app.container.undo.restore(historyId) }
                            .onSuccess { result ->
                                message = if (result.restoredAfterSync) {
                                    "Состояние восстановлено локально. Для изменения сайта выполните Sync."
                                } else "Состояние восстановлено."
                            }
                            .onFailure { message = it.message ?: "Не удалось выполнить откат" }
                        busy = false
                        restoreEvent = null
                    }
                }) { Text(if (busy) "…" else "Восстановить") }
            },
            dismissButton = { TextButton(enabled = !busy, onClick = { restoreEvent = null }) { Text("Отмена") } },
        )
    }

    message?.let { text ->
        AlertDialog(
            onDismissRequest = { message = null },
            confirmButton = { TextButton(onClick = { message = null }) { Text("OK") } },
            title = { Text("Лог действий") },
            text = { Text(text) },
        )
    }
}
