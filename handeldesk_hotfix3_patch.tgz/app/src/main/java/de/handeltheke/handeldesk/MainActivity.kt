package de.handeltheke.handeldesk

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.Surface
import de.handeltheke.handeldesk.ui.HandelDeskRoot
import de.handeltheke.handeldesk.ui.theme.HandelDeskTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            HandelDeskTheme {
                Surface { HandelDeskRoot() }
            }
        }
    }
}
