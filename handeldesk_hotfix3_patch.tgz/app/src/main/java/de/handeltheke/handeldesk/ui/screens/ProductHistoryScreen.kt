package de.handeltheke.handeldesk.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import de.handeltheke.handeldesk.HandelDeskApp
import de.handeltheke.handeldesk.data.local.ProductHistoryEntity
import de.handeltheke.handeldesk.domain.JsonTools
import de.handeltheke.handeldesk.ui.ScreenHeader
import kotlinx.coroutines.launch
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.text.DateFormat
import java.util.Date

@Composable
fun ProductHistoryScreen(productUuid: String, onBack: () -> Unit) {
    val app = LocalContext.current.applicationContext as HandelDeskApp
    val points by app.container.db.history().observeForProduct(productUuid, 20).collectAsState(initial = emptyList())
    val product by app.container.db.products().observe(productUuid).collectAsState(initial = null)
    val scope = rememberCoroutineScope()
    var confirm by remember { mutableStateOf<ProductHistoryEntity?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(
            "История товара",
            "До 20 локальных точек восстановления · сайт меняется только через Sync",
            onBack,
        )
        if (points.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(24.dp)) {
                Text("Точек отката пока нет. Они создаются автоматически перед изменениями товара и фото.")
            }
        } else {
            LazyColumn(
                Modifier.weight(1f),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(points, key = { it.id }) { point ->
                    val payload = remember(point.localJson) { JsonTools.objectOf(point.localJson) }
                    val model = payload["product"]?.jsonObject?.get("model")?.jsonPrimitive?.contentOrNull.orEmpty()
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text(
                                if (point.actionType == "history_restore") "Состояние перед откатом"
                                else if (point.actionType == "sync_checkpoint") "Контрольная точка перед Sync"
                                else "До действия: ${point.summary}",
                                style = MaterialTheme.typography.titleSmall,
                            )
                            if (point.actionType in setOf("history_restore", "sync_checkpoint")) {
                                Text(point.summary, style = MaterialTheme.typography.bodySmall)
                            }
                            Text(DateFormat.getDateTimeInstance().format(Date(point.createdAt)), style = MaterialTheme.typography.bodySmall)
                            if (model.isNotBlank()) Text("Model: $model", style = MaterialTheme.typography.bodyMedium)
                            Text(
                                if (point.productIdAtCapture == null) "Локальный товар" else "Server #${point.productIdAtCapture} · ${point.stateAtCapture}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            FilledTonalButton(
                                enabled = !busy && product != null,
                                onClick = { confirm = point },
                                modifier = Modifier.fillMaxWidth(),
                            ) { Text(if (point.actionType == "history_restore") "↪ Вернуть состояние до отката" else "↩ Восстановить это состояние") }
                        }
                    }
                }
            }
        }
    }

    confirm?.let { point ->
        AlertDialog(
            onDismissRequest = { if (!busy) confirm = null },
            title = { Text("Восстановить состояние?") },
            text = {
                Text(
                    "Карточка и локальное состояние фото вернутся к моменту ДО действия «${point.summary}». " +
                        "Если товар уже синхронизировался позже, сайт сейчас не откатится — будут созданы новые локальные изменения для следующего Sync."
                )
            },
            confirmButton = {
                Button(enabled = !busy, onClick = {
                    busy = true
                    scope.launch {
                        runCatching { app.container.undo.restore(point.id) }
                            .onSuccess { result ->
                                message = if (result.restoredAfterSync) {
                                    "Состояние восстановлено локально. Сайт не изменён; для отправки отката выполните Sync."
                                } else if (result.pendingChanges > 0) {
                                    "Состояние восстановлено. Локальных изменений: ${result.pendingChanges}."
                                } else "Состояние восстановлено."
                            }
                            .onFailure { message = it.message ?: "Не удалось восстановить состояние" }
                        busy = false
                        confirm = null
                    }
                }) { Text(if (busy) "Восстановление…" else "Восстановить") }
            },
            dismissButton = { TextButton(enabled = !busy, onClick = { confirm = null }) { Text("Отмена") } },
        )
    }

    message?.let { text ->
        AlertDialog(
            onDismissRequest = { message = null },
            confirmButton = { TextButton(onClick = { message = null }) { Text("OK") } },
            title = { Text("История") },
            text = { Text(text) },
        )
    }
}
