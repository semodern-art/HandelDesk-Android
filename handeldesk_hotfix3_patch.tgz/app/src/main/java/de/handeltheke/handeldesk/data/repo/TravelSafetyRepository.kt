package de.handeltheke.handeldesk.data.repo

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import android.os.Build
import android.os.StatFs
import androidx.room.withTransaction
import de.handeltheke.handeldesk.BuildConfig
import de.handeltheke.handeldesk.data.local.HandelDeskDatabase
import de.handeltheke.handeldesk.data.local.SettingEntity
import de.handeltheke.handeldesk.data.remote.BridgeClient
import de.handeltheke.handeldesk.security.SecureBridgeSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.*
import java.io.*
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class TravelSafetyRepository(
    private val context: Context,
    private val db: HandelDeskDatabase,
    private val bridgeSettings: SecureBridgeSettings,
    private val bridge: BridgeClient,
    private val localPhotos: LocalPhotoRepository,
    private val imageCache: ImageCacheRepository,
) {
    companion object {
        private const val DB_NAME = "handeldesk.db"
        private const val BACKUP_FORMAT = 1
        private const val EXPECTED_DB_VERSION = 5
        private val TABLES = listOf(
            "products", "categories", "manufacturers", "changes", "audit_events",
            "product_history", "work_queue", "sessions", "settings", "local_photos"
        )
    }

    enum class CheckState { OK, WARN, ERROR }

    data class ReadinessItem(val title: String, val detail: String, val state: CheckState)
    data class ReadinessReport(
        val items: List<ReadinessItem>,
        val products: Int,
        val changed: Int,
        val drafts: Int,
        val pendingPhotos: Int,
        val freeBytes: Long,
        val cacheBytes: Long,
        val cacheFiles: Int,
        val generatedAt: Long = System.currentTimeMillis(),
    ) {
        val errors get() = items.count { it.state == CheckState.ERROR }
        val warnings get() = items.count { it.state == CheckState.WARN }
        val ready get() = errors == 0
    }

    data class BackupResult(val bytes: Long, val files: Int, val createdAt: Long)
    data class RestoreResult(val createdAt: Long, val includedImageCache: Boolean, val fileCount: Int)

    suspend fun readiness(): ReadinessReport = withContext(Dispatchers.IO) {
        val products = db.products().totalCount()
        val changed = scalarInt("SELECT COUNT(*) FROM products WHERE state!='SYNCED'")
        val drafts = scalarInt("SELECT COUNT(*) FROM products WHERE isDraft=1")
        val pendingChanges = scalarInt("SELECT COUNT(*) FROM changes WHERE synced=0")
        val pendingPhotos = scalarInt("SELECT COUNT(*) FROM local_photos WHERE status IN ('READY','ERROR','UPLOADING','UPLOADED')")
        val categories = scalarInt("SELECT COUNT(*) FROM categories")
        val manufacturers = scalarInt("SELECT COUNT(*) FROM manufacturers")
        val historyCount = scalarInt("SELECT COUNT(*) FROM product_history")
        val workspace = localPhotos.workspaceStatus()
        val cache = imageCache.cacheStats()
        val stat = StatFs(context.filesDir.absolutePath)
        val free = stat.availableBytes
        val lastBackup = db.settings().get("last_backup_at")?.toLongOrNull()
        val lastFull = db.settings().get("last_full_snapshot_at")?.toLongOrNull()
        val lastDelta = db.settings().get("last_delta_sync_at")?.toLongOrNull()
        val lastOffline = listOfNotNull(lastFull, lastDelta).maxOrNull()
        val now = System.currentTimeMillis()
        val jobState = db.settings().get("offline_job_state")
        val dbOk = runCatching { scalarString("PRAGMA quick_check") == "ok" }.getOrDefault(false)

        val items = buildList {
            add(ReadinessItem(
                "Локальная база",
                if (dbOk) "$products товаров · БД исправна" else "SQLite quick_check не прошёл",
                if (dbOk && products > 0) CheckState.OK else CheckState.ERROR,
            ))
            add(ReadinessItem(
                "Справочники",
                "$categories категорий · $manufacturers производителей",
                if (categories > 0 && manufacturers > 0) CheckState.OK else CheckState.WARN,
            ))
            add(ReadinessItem(
                "Папка HandelDesk",
                when {
                    !workspace.configured -> "Корневая папка ещё не выбрана"
                    workspace.error != null -> workspace.error
                    else -> "${workspace.rootName} · Eingang ${workspace.inboxCount} · Bearbeitet ${workspace.processedCount} · Hochgeladen ${workspace.uploadedCount}"
                },
                when {
                    !workspace.configured || workspace.error != null -> CheckState.ERROR
                    else -> CheckState.OK
                },
            ))
            add(ReadinessItem(
                "Свободное место",
                formatBytes(free),
                when {
                    free < 2L * 1024 * 1024 * 1024 -> CheckState.ERROR
                    free < 5L * 1024 * 1024 * 1024 -> CheckState.WARN
                    else -> CheckState.OK
                },
            ))
            add(ReadinessItem(
                "Offline-кэш фото",
                "${cache.first} файлов · ${formatBytes(cache.second)}",
                if (cache.first > 0) CheckState.OK else CheckState.WARN,
            ))
            add(ReadinessItem(
                "Последнее offline-обновление",
                lastOffline?.let(::formatDateTime) ?: "ещё не выполнялось",
                when {
                    lastOffline == null -> CheckState.WARN
                    now - lastOffline > 7L * 24 * 60 * 60 * 1000 -> CheckState.WARN
                    else -> CheckState.OK
                },
            ))
            add(ReadinessItem(
                "Bridge",
                when {
                    bridgeSettings.baseUrl.isBlank() -> "URL не настроен"
                    !bridgeSettings.hasToken() -> "URL есть, Device Token отсутствует"
                    else -> "Настроен · token в Android Keystore"
                },
                if (bridgeSettings.baseUrl.isNotBlank() && bridgeSettings.hasToken()) CheckState.OK else CheckState.ERROR,
            ))
            add(ReadinessItem(
                "Резервная копия",
                lastBackup?.let(::formatDateTime) ?: "ещё не создавалась",
                when {
                    lastBackup == null -> CheckState.ERROR
                    now - lastBackup > 2L * 24 * 60 * 60 * 1000 -> CheckState.WARN
                    else -> CheckState.OK
                },
            ))
            add(ReadinessItem(
                "Несинхронизированная работа",
                "$changed товаров · $pendingChanges операций · $pendingPhotos фото · $drafts черновиков",
                if (pendingChanges > 0 || pendingPhotos > 0 || changed > 0) CheckState.WARN else CheckState.OK,
            ))
            add(ReadinessItem(
                "History / Undo",
                "$historyCount точек восстановления",
                CheckState.OK,
            ))
            if (jobState in setOf("RUNNING", "WAITING_NETWORK")) {
                add(ReadinessItem("Фоновая задача", "Offline-задача ещё выполняется", CheckState.WARN))
            }
        }

        ReadinessReport(items, products, changed, drafts, pendingPhotos, free, cache.second, cache.first)
    }

    suspend fun testBridge(): String = withContext(Dispatchers.IO) {
        require(bridgeSettings.baseUrl.isNotBlank()) { "Bridge URL не настроен" }
        require(bridgeSettings.hasToken()) { "Device Token не сохранён" }
        bridge.get("schema")
        "✓ Bridge доступен"
    }

    suspend fun createBackup(
        destination: Uri,
        includeImageCache: Boolean,
        onProgress: (String) -> Unit = {},
    ): BackupResult = withContext(Dispatchers.IO) {
        val createdAt = System.currentTimeMillis()
        val stage = File(context.cacheDir, "backup_${createdAt}").apply { deleteRecursively(); mkdirs() }
        val dbStage = File(stage, "db").apply { mkdirs() }
        val tmpZip = File(context.cacheDir, "HandelDesk-backup-${createdAt}.zip")
        try {
            onProgress("Подготавливаю базу…")
            checkpointAndCopyDatabase(dbStage)

            val bridgeJson = buildJsonObject {
                put("baseUrl", bridgeSettings.baseUrl)
                put("deviceName", bridgeSettings.deviceName)
                put("tokenIncluded", false)
                put("tokenNote", "Device Token deliberately stays in Android Keystore and is never written to backup ZIP")
            }
            File(stage, "bridge.json").writeText(bridgeJson.toString())

            val entries = mutableListOf<JsonObject>()
            onProgress("Упаковываю резервную копию…")
            ZipOutputStream(BufferedOutputStream(FileOutputStream(tmpZip))).use { zip ->
                dbStage.listFiles().orEmpty().filter { it.isFile }.forEach { file ->
                    addFile(zip, file, "db/${file.name}", entries)
                }
                addFile(zip, File(stage, "bridge.json"), "bridge.json", entries)
                addDirectoryFiles(zip, File(context.filesDir, "handeldesk_photos"), "private/handeldesk_photos", entries)
                if (includeImageCache) {
                    addDirectoryFiles(zip, File(context.filesDir, "image-cache"), "private/image-cache", entries)
                }
                val manifest = buildJsonObject {
                    put("formatVersion", BACKUP_FORMAT)
                    put("createdAt", createdAt)
                    put("appVersionName", BuildConfig.VERSION_NAME)
                    put("appVersionCode", BuildConfig.VERSION_CODE)
                    put("dbVersion", EXPECTED_DB_VERSION)
                    put("includesImageCache", includeImageCache)
                    put("files", JsonArray(entries))
                }.toString().toByteArray(Charsets.UTF_8)
                zip.putNextEntry(ZipEntry("manifest.json"))
                zip.write(manifest)
                zip.closeEntry()
            }

            onProgress("Сохраняю файл…")
            context.contentResolver.openOutputStream(destination, "w")?.use { output ->
                FileInputStream(tmpZip).use { it.copyTo(output) }
            } ?: error("Не удалось открыть выбранный файл для записи")

            db.settings().put(SettingEntity("last_backup_at", createdAt.toString()))
            db.settings().put(SettingEntity("last_backup_size", tmpZip.length().toString()))
            BackupResult(tmpZip.length(), entries.size, createdAt)
        } finally {
            stage.deleteRecursively()
            tmpZip.delete()
        }
    }

    suspend fun restoreBackup(source: Uri, onProgress: (String) -> Unit = {}): RestoreResult = withContext(Dispatchers.IO) {
        val started = System.currentTimeMillis()
        val stage = File(context.cacheDir, "restore_${started}").apply { deleteRecursively(); mkdirs() }
        val zipFile = File(stage, "backup.zip")
        try {
            onProgress("Читаю архив…")
            context.contentResolver.openInputStream(source)?.use { input ->
                FileOutputStream(zipFile).use { input.copyTo(it) }
            } ?: error("Не удалось открыть резервную копию")

            val extract = File(stage, "extract").apply { mkdirs() }
            safeUnzip(zipFile, extract)
            val manifestFile = File(extract, "manifest.json")
            require(manifestFile.isFile) { "В архиве нет manifest.json" }
            val manifest = Json.parseToJsonElement(manifestFile.readText()).jsonObject
            require(manifest["formatVersion"]?.jsonPrimitive?.intOrNull == BACKUP_FORMAT) { "Неподдерживаемый формат резервной копии" }
            require(manifest["dbVersion"]?.jsonPrimitive?.intOrNull == EXPECTED_DB_VERSION) {
                "Резервная копия создана для другой версии базы данных"
            }
            val createdAt = manifest["createdAt"]?.jsonPrimitive?.longOrNull ?: 0L
            val includesCache = manifest["includesImageCache"]?.jsonPrimitive?.booleanOrNull ?: false
            val fileRows = manifest["files"]?.jsonArray.orEmpty()

            onProgress("Проверяю целостность…")
            fileRows.forEach { element ->
                val row = element.jsonObject
                val path = row["path"]?.jsonPrimitive?.contentOrNull ?: error("Повреждён manifest")
                val expectedSize = row["size"]?.jsonPrimitive?.longOrNull ?: error("Повреждён manifest")
                val expectedSha = row["sha256"]?.jsonPrimitive?.contentOrNull ?: error("Повреждён manifest")
                val file = safeChild(extract, path)
                require(file.isFile && file.length() == expectedSize) { "Файл $path повреждён или отсутствует" }
                require(sha256(file).equals(expectedSha, ignoreCase = true)) { "Контрольная сумма $path не совпадает" }
            }

            val backupDb = File(extract, "db/$DB_NAME")
            require(backupDb.isFile) { "В архиве нет базы данных" }
            validateAndCheckpointBackupDb(backupDb)

            onProgress("Подготавливаю локальные фото…")
            val photoSwap = prepareDirectorySwap(File(extract, "private/handeldesk_photos"), "handeldesk_photos")
            val cacheSwap = if (includesCache) prepareDirectorySwap(File(extract, "private/image-cache"), "image-cache") else null
            try {
                photoSwap.activate()
                cacheSwap?.activate()
                onProgress("Восстанавливаю базу…")
                importDatabase(backupDb)
                photoSwap.commit()
                cacheSwap?.commit()
            } catch (t: Throwable) {
                cacheSwap?.rollback()
                photoSwap.rollback()
                throw t
            }

            File(extract, "bridge.json").takeIf(File::isFile)?.let { bridgeFile ->
                runCatching {
                    val bridgeJson = Json.parseToJsonElement(bridgeFile.readText()).jsonObject
                    bridgeSettings.baseUrl = bridgeJson["baseUrl"]?.jsonPrimitive?.contentOrNull.orEmpty()
                    bridgeSettings.deviceName = bridgeJson["deviceName"]?.jsonPrimitive?.contentOrNull.orEmpty().ifBlank { "Android" }
                }
            }
            db.settings().put(SettingEntity("last_restore_at", System.currentTimeMillis().toString()))
            if (createdAt > 0) db.settings().put(SettingEntity("last_backup_at", createdAt.toString()))
            db.invalidationTracker.refreshAsync()
            RestoreResult(createdAt, includesCache, fileRows.size)
        } finally {
            stage.deleteRecursively()
        }
    }

    suspend fun diagnosticText(): String = withContext(Dispatchers.IO) {
        val report = readiness()
        val workspace = localPhotos.workspaceStatus()
        val recentAudit = runCatching { db.audit().observeRecent(50).first() }.getOrDefault(emptyList())
        val crash = File(context.filesDir, "diagnostics/last_crash.txt").takeIf(File::isFile)?.readText().orEmpty()
        buildString {
            appendLine("HandelDesk diagnostics")
            appendLine("Generated: ${formatDateTime(System.currentTimeMillis())}")
            appendLine("App: ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})")
            appendLine("Android: ${Build.VERSION.RELEASE} / API ${Build.VERSION.SDK_INT}")
            appendLine("Device: ${Build.MANUFACTURER} ${Build.MODEL}")
            appendLine("DB schema: ${scalarInt("PRAGMA user_version")}")
            appendLine("DB quick_check: ${scalarString("PRAGMA quick_check")}")
            appendLine("Products: ${report.products}; changed=${report.changed}; drafts=${report.drafts}")
            appendLine("Pending photo uploads: ${report.pendingPhotos}")
            appendLine("Categories: ${scalarInt("SELECT COUNT(*) FROM categories")}; manufacturers=${scalarInt("SELECT COUNT(*) FROM manufacturers")}")
            appendLine("Queue: ${scalarInt("SELECT COUNT(*) FROM work_queue")}; history=${scalarInt("SELECT COUNT(*) FROM product_history")}")
            appendLine("Free storage: ${formatBytes(report.freeBytes)}")
            appendLine("Image cache: ${report.cacheFiles} files / ${formatBytes(report.cacheBytes)}")
            appendLine("Workspace: configured=${workspace.configured}; root=${workspace.rootName}; inbox=${workspace.inboxCount}; processed=${workspace.processedCount}; uploaded=${workspace.uploadedCount}; error=${workspace.error.orEmpty()}")
            appendLine("Bridge URL: ${bridgeSettings.baseUrl}")
            appendLine("Bridge token present: ${bridgeSettings.hasToken()} (token value is NEVER exported)")
            appendLine("Last full snapshot: ${db.settings().get("last_full_snapshot_at")?.toLongOrNull()?.let(::formatDateTime) ?: "—"}")
            appendLine("Last delta sync: ${db.settings().get("last_delta_sync_at")?.toLongOrNull()?.let(::formatDateTime) ?: "—"}")
            appendLine("Last backup: ${db.settings().get("last_backup_at")?.toLongOrNull()?.let(::formatDateTime) ?: "—"}")
            appendLine("Offline job: ${db.settings().get("offline_job_state").orEmpty()} · ${db.settings().get("offline_job_message").orEmpty()}")
            appendLine()
            appendLine("READINESS")
            report.items.forEach { appendLine("[${it.state}] ${it.title}: ${it.detail}") }
            appendLine()
            appendLine("RECENT AUDIT (${recentAudit.size})")
            recentAudit.forEach { event ->
                appendLine("${formatDateTime(event.createdAt)} | ${event.eventType} | ${event.summary} | entity=${event.entityUuid.orEmpty()}")
            }
            if (crash.isNotBlank()) {
                appendLine()
                appendLine("LAST CRASH")
                appendLine(crash.take(40_000))
            }
        }
    }

    suspend fun writeDiagnostics(destination: Uri): Long = withContext(Dispatchers.IO) {
        val text = diagnosticText()
        val bytes = text.toByteArray(Charsets.UTF_8)
        context.contentResolver.openOutputStream(destination, "w")?.use { it.write(bytes) }
            ?: error("Не удалось создать диагностический файл")
        db.settings().put(SettingEntity("last_diagnostics_at", System.currentTimeMillis().toString()))
        bytes.size.toLong()
    }

    private fun checkpointAndCopyDatabase(targetDir: File) {
        val sqlite = db.openHelper.writableDatabase
        runCatching { sqlite.query("PRAGMA wal_checkpoint(FULL)").use { while (it.moveToNext()) Unit } }
        val source = context.getDatabasePath(DB_NAME)
        require(source.isFile) { "Локальная база данных не найдена" }
        // Keep other writers out while the database + WAL set is copied.
        sqlite.beginTransaction()
        try {
            listOf(source, File(source.path + "-wal"), File(source.path + "-shm")).forEach { file ->
                if (file.isFile) file.copyTo(File(targetDir, file.name), overwrite = true)
            }
            sqlite.setTransactionSuccessful()
        } finally {
            sqlite.endTransaction()
        }
    }

    private fun validateAndCheckpointBackupDb(file: File) {
        val sqlite = SQLiteDatabase.openDatabase(file.absolutePath, null, SQLiteDatabase.OPEN_READWRITE)
        try {
            val version = sqlite.rawQuery("PRAGMA user_version", null).use { c -> if (c.moveToFirst()) c.getInt(0) else -1 }
            require(version == EXPECTED_DB_VERSION) { "Версия базы $version, ожидается $EXPECTED_DB_VERSION" }
            val integrity = sqlite.rawQuery("PRAGMA integrity_check", null).use { c -> if (c.moveToFirst()) c.getString(0) else "" }
            require(integrity.equals("ok", ignoreCase = true)) { "SQLite integrity_check: $integrity" }
            val tables = sqlite.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null).use { c ->
                buildSet { while (c.moveToNext()) add(c.getString(0)) }
            }
            require(TABLES.all { it in tables }) { "В резервной базе отсутствуют обязательные таблицы" }
            runCatching { sqlite.rawQuery("PRAGMA wal_checkpoint(TRUNCATE)", null).use { while (it.moveToNext()) Unit } }
        } finally {
            sqlite.close()
        }
    }

    private fun importDatabase(backupDb: File) {
        val sqlite = db.openHelper.writableDatabase
        val escaped = backupDb.absolutePath.replace("'", "''")
        sqlite.execSQL("ATTACH DATABASE '$escaped' AS restore_db")
        try {
            sqlite.beginTransaction()
            try {
                // Delete dependent rows first. No FK constraints exist today, but this order also
                // keeps the operation safe if they are added later.
                listOf("changes", "audit_events", "product_history", "work_queue", "local_photos", "sessions", "categories", "manufacturers", "products", "settings")
                    .forEach { sqlite.execSQL("DELETE FROM `$it`") }
                listOf("products", "categories", "manufacturers", "changes", "audit_events", "product_history", "work_queue", "sessions", "settings", "local_photos")
                    .forEach { sqlite.execSQL("INSERT INTO main.`$it` SELECT * FROM restore_db.`$it`") }
                sqlite.setTransactionSuccessful()
            } finally {
                sqlite.endTransaction()
            }
        } finally {
            runCatching { sqlite.execSQL("DETACH DATABASE restore_db") }
        }
    }

    private data class DirectorySwap(
        val target: File,
        val incoming: File,
        val previous: File,
        var activated: Boolean = false,
    ) {
        fun activate() {
            if (activated) return
            previous.deleteRecursively()
            if (target.exists()) require(target.renameTo(previous)) { "Не удалось подготовить восстановление ${target.name}" }
            if (!incoming.renameTo(target)) {
                if (previous.exists()) previous.renameTo(target)
                error("Не удалось активировать восстановленные файлы ${target.name}")
            }
            activated = true
        }
        fun commit() {
            previous.deleteRecursively()
            incoming.deleteRecursively()
        }
        fun rollback() {
            if (activated) target.deleteRecursively()
            if (previous.exists()) previous.renameTo(target)
            incoming.deleteRecursively()
            activated = false
        }
    }

    private fun prepareDirectorySwap(extracted: File, targetName: String): DirectorySwap {
        val target = File(context.filesDir, targetName)
        val incoming = File(context.filesDir, ".$targetName.restore_tmp").apply { deleteRecursively(); mkdirs() }
        if (extracted.exists()) extracted.copyRecursively(incoming, overwrite = true)
        val previous = File(context.filesDir, ".$targetName.pre_restore").apply { deleteRecursively() }
        return DirectorySwap(target, incoming, previous)
    }

    private fun addDirectoryFiles(zip: ZipOutputStream, root: File, prefix: String, entries: MutableList<JsonObject>) {
        if (!root.exists()) return
        root.walkTopDown().filter { it.isFile }.forEach { file ->
            val relative = file.relativeTo(root).invariantSeparatorsPath
            addFile(zip, file, "$prefix/$relative", entries)
        }
    }

    private fun addFile(zip: ZipOutputStream, file: File, path: String, entries: MutableList<JsonObject>) {
        val digest = MessageDigest.getInstance("SHA-256")
        val sizeBefore = file.length()
        val modifiedBefore = file.lastModified()
        var written = 0L
        zip.putNextEntry(ZipEntry(path).apply { time = modifiedBefore })
        FileInputStream(file).use { input ->
            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                digest.update(buffer, 0, read)
                zip.write(buffer, 0, read)
                written += read
            }
        }
        zip.closeEntry()
        require(sizeBefore == file.length() && modifiedBefore == file.lastModified() && written == sizeBefore) {
            "Файл изменился во время backup: $path. Повторите создание резервной копии."
        }
        entries += buildJsonObject {
            put("path", path)
            put("size", written)
            put("sha256", digest.digest().joinToString("") { "%02x".format(it) })
        }
    }

    private fun safeUnzip(zipFile: File, target: File) {
        ZipInputStream(BufferedInputStream(FileInputStream(zipFile))).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                val out = safeChild(target, entry.name)
                if (entry.isDirectory) out.mkdirs() else {
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { zip.copyTo(it) }
                }
                zip.closeEntry()
            }
        }
    }

    private fun safeChild(root: File, relative: String): File {
        val file = File(root, relative)
        val rootPath = root.canonicalFile.toPath()
        val filePath = file.canonicalFile.toPath()
        require(filePath.startsWith(rootPath)) { "Недопустимый путь в ZIP: $relative" }
        return file
    }

    private fun scalarInt(sql: String): Int = db.openHelper.readableDatabase.query(sql).use { c -> if (c.moveToFirst()) c.getInt(0) else 0 }
    private fun scalarString(sql: String): String = db.openHelper.readableDatabase.query(sql).use { c -> if (c.moveToFirst()) c.getString(0).orEmpty() else "" }

    private fun sha256(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                md.update(buffer, 0, read)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun formatDateTime(value: Long): String = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(value))
    private fun formatBytes(value: Long): String = when {
        value >= 1024L * 1024 * 1024 -> "%.1f GB".format(value / (1024.0 * 1024 * 1024))
        value >= 1024L * 1024 -> "%.1f MB".format(value / (1024.0 * 1024))
        value >= 1024L -> "%.1f KB".format(value / 1024.0)
        else -> "$value B"
    }
}
