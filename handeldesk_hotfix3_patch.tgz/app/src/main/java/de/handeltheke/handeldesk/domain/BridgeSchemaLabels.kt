package de.handeltheke.handeldesk.domain

import kotlinx.serialization.json.*

data class BridgeOptionValueDefinition(
    val id: String,
    val name: String,
    val sortOrder: Int = 0,
)

data class BridgeOptionDefinition(
    val id: String,
    val name: String,
    val type: String,
    val sortOrder: Int = 0,
    val values: List<BridgeOptionValueDefinition> = emptyList(),
)

/**
 * Human-readable labels supplied by the OpenCart Bridge schema.
 *
 * IDs remain stable transport/storage keys. UI code must resolve them through this
 * schema instead of exposing language_id / option_id / option_value_id to users.
 * The Bridge schema is the source of truth, so renaming a language/option in OpenCart
 * is reflected on the next sync without an Android app update.
 */
data class BridgeSchemaLabels(
    val languageNames: Map<String, String> = emptyMap(),
    val languageCodes: Map<String, String> = emptyMap(),
    val optionNames: Map<String, String> = emptyMap(),
    val optionValueNames: Map<String, String> = emptyMap(),
    val optionDefinitions: List<BridgeOptionDefinition> = emptyList(),
) {
    fun language(id: String?): String {
        val key = id.orEmpty()
        return languageNames[key]?.takeIf(String::isNotBlank)
            ?: languageCodes[key]?.takeIf(String::isNotBlank)
            ?: "Неизвестный язык"
    }

    fun option(id: String?): String {
        val key = id.orEmpty()
        return optionNames[key]?.takeIf(String::isNotBlank)
            ?: optionDefinitions.firstOrNull { it.id == key }?.name?.takeIf(String::isNotBlank)
            ?: "Неизвестная опция"
    }

    fun optionValue(id: String?): String {
        val key = id.orEmpty()
        return optionValueNames[key]?.takeIf(String::isNotBlank)
            ?: optionDefinitions.asSequence().flatMap { it.values.asSequence() }.firstOrNull { it.id == key }?.name?.takeIf(String::isNotBlank)
            ?: "Неизвестное значение"
    }

    fun optionDefinition(id: String?): BridgeOptionDefinition? = optionDefinitions.firstOrNull { it.id == id.orEmpty() }

    companion object {
        fun fromSchemaJson(raw: String?): BridgeSchemaLabels {
            if (raw.isNullOrBlank()) return BridgeSchemaLabels()
            val schema = runCatching { JsonTools.objectOf(raw) }.getOrElse { return BridgeSchemaLabels() }

            val languageNames = linkedMapOf<String, String>()
            val languageCodes = linkedMapOf<String, String>()
            schema["languages"]?.jsonArray.orEmpty().forEach { element ->
                val row = element.jsonObject
                val id = row["language_id"]?.jsonPrimitive?.contentOrNull.orEmpty()
                if (id.isNotBlank()) {
                    row["name"]?.jsonPrimitive?.contentOrNull?.let { languageNames[id] = it }
                    row["code"]?.jsonPrimitive?.contentOrNull?.let { languageCodes[id] = it }
                }
            }

            val optionNames = linkedMapOf<String, String>()
            val optionValueNames = linkedMapOf<String, String>()
            val definitions = mutableListOf<BridgeOptionDefinition>()
            schema["options"]?.jsonArray.orEmpty().forEach { element ->
                val option = element.jsonObject
                val optionId = option["option_id"]?.jsonPrimitive?.contentOrNull.orEmpty()
                val optionName = option["name"]?.jsonPrimitive?.contentOrNull.orEmpty().ifBlank { "Опция $optionId" }
                if (optionId.isBlank()) return@forEach
                optionNames[optionId] = optionName
                val values = option["values"]?.jsonArray.orEmpty().mapNotNull { valueElement ->
                    val value = valueElement.jsonObject
                    val valueId = value["option_value_id"]?.jsonPrimitive?.contentOrNull.orEmpty()
                    if (valueId.isBlank()) return@mapNotNull null
                    val valueName = value["name"]?.jsonPrimitive?.contentOrNull.orEmpty().ifBlank { "Значение $valueId" }
                    optionValueNames[valueId] = valueName
                    BridgeOptionValueDefinition(
                        id = valueId,
                        name = valueName,
                        sortOrder = value["sort_order"]?.jsonPrimitive?.intOrNull ?: 0,
                    )
                }.sortedWith(compareBy<BridgeOptionValueDefinition> { it.sortOrder }.thenBy { it.name.lowercase() })
                definitions += BridgeOptionDefinition(
                    id = optionId,
                    name = optionName,
                    type = option["type"]?.jsonPrimitive?.contentOrNull.orEmpty(),
                    sortOrder = option["sort_order"]?.jsonPrimitive?.intOrNull ?: 0,
                    values = values,
                )
            }

            return BridgeSchemaLabels(
                languageNames = languageNames,
                languageCodes = languageCodes,
                optionNames = optionNames,
                optionValueNames = optionValueNames,
                optionDefinitions = definitions.sortedWith(compareBy<BridgeOptionDefinition> { it.sortOrder }.thenBy { it.name.lowercase() }),
            )
        }
    }
}
