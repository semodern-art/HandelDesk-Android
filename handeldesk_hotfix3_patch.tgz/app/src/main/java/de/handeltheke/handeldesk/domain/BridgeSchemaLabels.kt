package de.handeltheke.handeldesk.domain

import kotlinx.serialization.json.*

/**
 * Human-readable labels supplied by the OpenCart Bridge schema.
 *
 * IDs remain stable transport/storage keys. UI code must resolve them through this
 * schema instead of exposing language_id / option_id / option_value_id to users.
 * The Bridge schema is the source of truth, so renaming a language/option in OpenCart
 * is reflected on the next sync without an Android app update.
 */
data class BridgeSchemaLabels(
    val languageNames: Map<String, String> = emptyMap(),
    val languageCodes: Map<String, String> = emptyMap(),
    val optionNames: Map<String, String> = emptyMap(),
    val optionValueNames: Map<String, String> = emptyMap(),
) {
    fun language(id: String?): String {
        val key = id.orEmpty()
        return languageNames[key]?.takeIf(String::isNotBlank)
            ?: languageCodes[key]?.takeIf(String::isNotBlank)
            ?: "Неизвестный язык"
    }

    fun option(id: String?): String {
        val key = id.orEmpty()
        return optionNames[key]?.takeIf(String::isNotBlank)
            ?: "Неизвестная опция"
    }

    fun optionValue(id: String?): String {
        val key = id.orEmpty()
        return optionValueNames[key]?.takeIf(String::isNotBlank)
            ?: "Неизвестное значение"
    }

    companion object {
        fun fromSchemaJson(raw: String?): BridgeSchemaLabels {
            if (raw.isNullOrBlank()) return BridgeSchemaLabels()
            val schema = runCatching { JsonTools.objectOf(raw) }.getOrElse { return BridgeSchemaLabels() }

            val languageNames = linkedMapOf<String, String>()
            val languageCodes = linkedMapOf<String, String>()
            schema["languages"]?.jsonArray.orEmpty().forEach { element ->
                val row = element.jsonObject
                val id = row["language_id"]?.jsonPrimitive?.contentOrNull.orEmpty()
                if (id.isNotBlank()) {
                    row["name"]?.jsonPrimitive?.contentOrNull?.let { languageNames[id] = it }
                    row["code"]?.jsonPrimitive?.contentOrNull?.let { languageCodes[id] = it }
                }
            }

            val optionNames = linkedMapOf<String, String>()
            val optionValueNames = linkedMapOf<String, String>()
            schema["options"]?.jsonArray.orEmpty().forEach { element ->
                val option = element.jsonObject
                val optionId = option["option_id"]?.jsonPrimitive?.contentOrNull.orEmpty()
                if (optionId.isNotBlank()) {
                    option["name"]?.jsonPrimitive?.contentOrNull?.let { optionNames[optionId] = it }
                }
                option["values"]?.jsonArray.orEmpty().forEach { valueElement ->
                    val value = valueElement.jsonObject
                    val valueId = value["option_value_id"]?.jsonPrimitive?.contentOrNull.orEmpty()
                    if (valueId.isNotBlank()) {
                        value["name"]?.jsonPrimitive?.contentOrNull?.let { optionValueNames[valueId] = it }
                    }
                }
            }

            return BridgeSchemaLabels(languageNames, languageCodes, optionNames, optionValueNames)
        }
    }
}
