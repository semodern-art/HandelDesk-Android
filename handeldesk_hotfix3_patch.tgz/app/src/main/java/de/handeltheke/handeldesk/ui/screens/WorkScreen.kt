package de.handeltheke.handeldesk.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import de.handeltheke.handeldesk.HandelDeskApp
import de.handeltheke.handeldesk.data.local.LocalPhotoEntity
import de.handeltheke.handeldesk.data.local.ProductEntity
import de.handeltheke.handeldesk.domain.JsonTools
import de.handeltheke.handeldesk.ui.ScreenHeader
import de.handeltheke.handeldesk.ui.components.EmptyState
import de.handeltheke.handeldesk.ui.components.ProductThumbnail
import de.handeltheke.handeldesk.ui.components.StatusBadge
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

@Composable
fun WorkScreen(onOpen: (String) -> Unit) {
    val app = LocalContext.current.applicationContext as HandelDeskApp
    val queue by app.container.db.queue().observeQueue().collectAsState(initial = emptyList())
    val localPhotos by app.container.db.photos().observeAll().collectAsState(initial = emptyList())
    val changedCount by app.container.db.products().observeChangedCount().collectAsState(initial = 0)
    val draftCount by app.container.db.products().observeDraftCount().collectAsState(initial = 0)
    var products by remember { mutableStateOf<List<ProductEntity>>(emptyList()) }
    LaunchedEffect(queue) { products = queue.mapNotNull { app.container.db.products().get(it.productUuid) } }
    val photoMap = remember(localPhotos) { localPhotos.groupBy { it.productUuid } }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Работа", "Твоя локальная рабочая очередь")
        Row(Modifier.padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            StatusBadge("Очередь ${queue.size}", "primary")
            StatusBadge("Изменено $changedCount", "warn")
            StatusBadge("Черновики $draftCount")
        }
        if (products.isEmpty()) {
            EmptyState("Рабочая очередь пуста", "Добавляй товары в работу и обрабатывай их последовательно даже без интернета.")
        } else {
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                items(products, key = { it.uuid }) { p -> WorkProductCard(p, photoMap[p.uuid].orEmpty(), onOpen) }
            }
        }
    }
}

@Composable
private fun WorkProductCard(product: ProductEntity, photos: List<LocalPhotoEntity>, onOpen: (String) -> Unit) {
    val remoteImage = remember(product.localJson) {
        JsonTools.objectOf(product.localJson)["product"]?.jsonObject?.get("image")?.jsonPrimitive?.contentOrNull.orEmpty()
    }
    ElevatedCard(Modifier.fillMaxWidth().clickable { onOpen(product.uuid) }) {
        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            ProductThumbnail(remoteImage, photos, size = 88.dp)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(product.name.ifBlank { "Новый товар" }, style = MaterialTheme.typography.titleMedium, maxLines = 2)
                Text("${product.model}  ·  ${"%.2f".format(product.price)} €  ·  Qty ${product.quantity}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    StatusBadge(product.state, if (product.state == "SYNCED") "ok" else "warn")
                    if (photos.isNotEmpty()) {
                        val pending = photos.count { it.status != "ATTACHED" }
                        StatusBadge(if (pending > 0) "Фото $pending ждут" else "Фото ✓", if (pending > 0) "primary" else "ok")
                    }
                }
            }
            Text("›", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
