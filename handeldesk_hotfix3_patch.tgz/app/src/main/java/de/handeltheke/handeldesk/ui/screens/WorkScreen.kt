package de.handeltheke.handeldesk.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import de.handeltheke.handeldesk.HandelDeskApp
import de.handeltheke.handeldesk.data.local.LocalPhotoEntity
import de.handeltheke.handeldesk.data.local.ProductEntity
import de.handeltheke.handeldesk.domain.JsonTools
import de.handeltheke.handeldesk.ui.ScreenHeader
import de.handeltheke.handeldesk.ui.components.CachedProductImage
import de.handeltheke.handeldesk.ui.components.LocalFileImage
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

@Composable
fun WorkScreen(onOpen: (String) -> Unit) {
    val app = LocalContext.current.applicationContext as HandelDeskApp
    val queue by app.container.db.queue().observeQueue().collectAsState(initial = emptyList())
    val localPhotos by app.container.db.photos().observeAll().collectAsState(initial = emptyList())
    val changedCount by app.container.db.products().observeChangedCount().collectAsState(initial = 0)
    val draftCount by app.container.db.products().observeDraftCount().collectAsState(initial = 0)
    var products by remember { mutableStateOf<List<ProductEntity>>(emptyList()) }
    LaunchedEffect(queue) { products = queue.mapNotNull { app.container.db.products().get(it.productUuid) } }
    val photoMap = remember(localPhotos) { localPhotos.groupBy { it.productUuid } }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Работа", "Очередь ${queue.size} · Изменено $changedCount · Черновики $draftCount")
        if (products.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(24.dp)) { Text("Рабочая очередь пуста. Добавляй товары из карточки — и в самолёте можно идти по ним последовательно.") }
        } else {
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(products, key = { it.uuid }) { p ->
                    WorkProductCard(p, photoMap[p.uuid].orEmpty(), onOpen)
                }
            }
        }
    }
}

@Composable
private fun WorkProductCard(product: ProductEntity, photos: List<LocalPhotoEntity>, onOpen: (String) -> Unit) {
    val localMain = photos.firstOrNull { it.isMain && it.processedPath.isNotBlank() }
        ?: photos.firstOrNull { it.processedPath.isNotBlank() }
    val remoteImage = remember(product.localJson) {
        JsonTools.objectOf(product.localJson)["product"]?.jsonObject?.get("image")?.jsonPrimitive?.contentOrNull.orEmpty()
    }
    Card(Modifier.fillMaxWidth().clickable { onOpen(product.uuid) }) {
        Row(Modifier.padding(10.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            when {
                localMain != null -> LocalFileImage(localMain.processedPath, size = 82.dp)
                remoteImage.isNotBlank() -> CachedProductImage(remoteImage, size = 82.dp)
                else -> Surface(Modifier.size(82.dp), color = MaterialTheme.colorScheme.surfaceVariant) {}
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(product.name.ifBlank { "Новый товар" }, style = MaterialTheme.typography.titleMedium)
                Text("${product.model} · ${"%.2f".format(product.price)} € · Qty ${product.quantity}")
                if (photos.isNotEmpty()) {
                    val pending = photos.count { it.status !in setOf("ATTACHED") }
                    Text("Фото: ${photos.size}${if (pending > 0) " · ожидают $pending" else " · ✓"}", style = MaterialTheme.typography.bodySmall)
                }
                Text("${product.state} · ${product.workflowState}", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
