package de.handeltheke.handeldesk.data.repo

import android.content.ContentValues
import android.content.Intent
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.os.Build
import android.os.Environment
import android.net.Uri
import android.provider.MediaStore
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.util.Base64
import androidx.exifinterface.media.ExifInterface
import androidx.documentfile.provider.DocumentFile
import androidx.room.withTransaction
import de.handeltheke.handeldesk.data.local.HandelDeskDatabase
import de.handeltheke.handeldesk.data.local.LocalPhotoEntity
import de.handeltheke.handeldesk.data.local.SettingEntity
import de.handeltheke.handeldesk.data.remote.BridgeClient
import de.handeltheke.handeldesk.data.remote.BridgeException
import de.handeltheke.handeldesk.domain.JsonTools
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.UUID
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class LocalPhotoRepository(
    private val context: Context,
    private val db: HandelDeskDatabase,
    private val bridge: BridgeClient,
    private val productEditor: ProductEditorRepository,
    private val history: ProductHistoryRepository,
) {
    companion object {
        val TARGET_FOLDERS = listOf(
            "Fernbedienungen", "Kabel", "Freader", "Sonstiges", "GPSundKonsole",
            "Laptop", "HDD-Ersatzteile", "monitor", "Tab"
        )
        val FAST_FOLDERS = listOf("Fernbedienungen", "Kabel")
        const val WORKSPACE_SETTING = "photo_workspace_tree_uri"
        const val STAGE_INBOX = "INBOX"
        const val STAGE_PROCESSED = "PROCESSED"
        const val STAGE_UPLOADED = "UPLOADED"
        const val STAGE_EXTERNAL = "EXTERNAL"
        const val DIR_INBOX = "01_Eingang"
        const val DIR_PROCESSED = "02_Bearbeitet"
        const val DIR_UPLOADED = "03_Hochgeladen"
        private const val COLLISION_PREFIX = "PHOTO_NAME_CONFLICT:"
        private const val LEGACY_COLLISION_PREFIX = "A different image already exists at "

        fun collisionPath(error: String): String? = when {
            error.startsWith(COLLISION_PREFIX) -> error.removePrefix(COLLISION_PREFIX).trim().takeIf { it.isNotBlank() }
            error.startsWith(LEGACY_COLLISION_PREFIX) -> error.removePrefix(LEGACY_COLLISION_PREFIX).trim().takeIf { it.isNotBlank() }
            else -> null
        }
    }

    data class PreviewBitmap(val bitmap: Bitmap, val width: Int, val height: Int)
    data class WorkspacePhoto(val uri: String, val name: String, val size: Long, val modifiedAt: Long)
    data class WorkspaceStatus(
        val configured: Boolean,
        val rootName: String = "",
        val inboxCount: Int = 0,
        val processedCount: Int = 0,
        val uploadedCount: Int = 0,
        val error: String? = null,
    )

    suspend fun importUris(productUuid: String, uris: List<Uri>): List<String> =
        importInternal(productUuid, uris, STAGE_EXTERNAL)

    suspend fun importWorkspaceUris(productUuid: String, uris: List<Uri>): List<String> =
        importInternal(productUuid, uris, STAGE_INBOX)

    private suspend fun importInternal(productUuid: String, uris: List<Uri>, sourceStage: String): List<String> = withContext(Dispatchers.IO) {
        if (uris.isEmpty()) return@withContext emptyList()
        val usedSourceUris = if (sourceStage == STAGE_INBOX) db.photos().usedSourceUris().toSet() else emptySet()
        val uniqueUris = uris.distinctBy { it.toString() }.filterNot { it.toString() in usedSourceUris }
        if (uniqueUris.isEmpty()) return@withContext emptyList()
        val historyId = history.captureCurrent(productUuid, "photo_import", "Добавление фото (${uniqueUris.size})")
        val folder = suggestFolder(productUuid)
        val product = db.products().get(productUuid)
        val currentMain = product?.let { JsonTools.path(JsonTools.objectOf(it.localJson), "product.image")?.jsonPrimitive?.contentOrNull }.orEmpty()
        val hadMain = db.photos().forProduct(productUuid).any { it.isMain } || currentMain.isNotBlank()
        val created = mutableListOf<String>()
        uniqueUris.forEachIndexed { index, uri ->
            val id = UUID.randomUUID().toString()
            val name = safeDisplayName(uri, id)
            val itemDir = File(context.filesDir, "handeldesk_photos/$productUuid/$id")
            val originalDir = File(itemDir, "original").apply { mkdirs() }
            val original = File(originalDir, name)
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(original).use { output -> input.copyTo(output) }
            } ?: error("Не удалось открыть $name")
            val (w, h) = orientedDimensions(original)
            val now = System.currentTimeMillis()
            val sort = db.photos().nextSortOrder(productUuid)
            val row = LocalPhotoEntity(
                id = id,
                productUuid = productUuid,
                fileName = name,
                originalPath = original.absolutePath,
                remoteFolder = folder,
                remotePath = remotePath(folder, name),
                isMain = !hadMain && index == 0,
                sortOrder = sort,
                sourceWidth = w,
                sourceHeight = h,
                sourceUri = if (sourceStage == STAGE_INBOX) uri.toString() else null,
                sourceStage = sourceStage,
                sourceError = null,
                createdAt = now,
                updatedAt = now,
            )
            db.photos().put(row)
            created += id
        }
        if (created.isNotEmpty()) auditPhoto(productUuid, "photo_import", "Добавлено фото: ${created.size}", historyId)
        created
    }

    suspend fun loadPreview(photoId: String, maxDimension: Int = 1800, rotationDegrees: Int? = null): PreviewBitmap = withContext(Dispatchers.IO) {
        val row = db.photos().get(photoId) ?: error("Фото не найдено")
        val file = File(row.originalPath)
        val oriented = decodeOriented(file, maxDimension, rotationDegrees ?: row.rotationDegrees)
        PreviewBitmap(oriented, oriented.width, oriented.height)
    }

    suspend fun process(
        photoId: String,
        cropLeft: Float,
        cropTop: Float,
        cropRight: Float,
        cropBottom: Float,
        rotationDegrees: Int,
        targetWidth: Int,
        targetHeight: Int,
        keepAspect: Boolean,
        doNotEnlarge: Boolean,
    ): LocalPhotoEntity = withContext(Dispatchers.IO) {
        val row = db.photos().get(photoId) ?: error("Фото не найдено")
        val historyId = history.captureCurrent(row.productUuid, "photo_process", "Обработка фото ${row.fileName}")
        val source = decodeOriented(File(row.originalPath), 0, rotationDegrees)
        try {
            val left = (cropLeft.coerceIn(0f, 0.98f) * source.width).roundToInt().coerceIn(0, source.width - 2)
            val top = (cropTop.coerceIn(0f, 0.98f) * source.height).roundToInt().coerceIn(0, source.height - 2)
            val right = (cropRight.coerceIn(0.02f, 1f) * source.width).roundToInt().coerceIn(left + 1, source.width)
            val bottom = (cropBottom.coerceIn(0.02f, 1f) * source.height).roundToInt().coerceIn(top + 1, source.height)
            val cropped = Bitmap.createBitmap(source, left, top, right - left, bottom - top)
            try {
                val (outW, outH) = outputSize(cropped.width, cropped.height, targetWidth, targetHeight, keepAspect, doNotEnlarge)
                val outputBitmap = if (outW == cropped.width && outH == cropped.height) cropped else Bitmap.createScaledBitmap(cropped, outW, outH, true)
                try {
                    val itemDir = File(row.originalPath).parentFile?.parentFile ?: error("Повреждён локальный путь фото")
                    val processedDir = File(itemDir, "processed").apply { mkdirs() }
                    val outFile = File(processedDir, row.fileName)
                    FileOutputStream(outFile).use { stream ->
                        when (outFile.extension.lowercase()) {
                            "png" -> outputBitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
                            "webp" -> {
                                @Suppress("DEPRECATION")
                                val format = if (android.os.Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP
                                outputBitmap.compress(format, 95, stream)
                            }
                            else -> outputBitmap.compress(Bitmap.CompressFormat.JPEG, 95, stream)
                        }
                    }
                    val sha = sha256(outFile)
                    val now = System.currentTimeMillis()
                    val updated = row.copy(
                        processedPath = outFile.absolutePath,
                        remotePath = remotePath(row.remoteFolder, row.fileName),
                        cropLeft = cropLeft.coerceIn(0f, 1f), cropTop = cropTop.coerceIn(0f, 1f),
                        cropRight = cropRight.coerceIn(0f, 1f), cropBottom = cropBottom.coerceIn(0f, 1f),
                        rotationDegrees = normalizedRotation(rotationDegrees),
                        targetWidth = targetWidth.coerceAtLeast(0), targetHeight = targetHeight.coerceAtLeast(0),
                        keepAspect = keepAspect, doNotEnlarge = doNotEnlarge,
                        processedWidth = outW, processedHeight = outH,
                        sha256 = sha, status = "READY", error = "", updatedAt = now,
                    )
                    val moved = if (updated.sourceStage == STAGE_INBOX) {
                        moveWorkspaceOriginal(updated, STAGE_PROCESSED)
                    } else updated
                    db.photos().put(moved)
                    refreshProductImageFields(row.productUuid)
                    auditPhoto(row.productUuid, "photo_process", "Фото обработано: ${row.fileName}", historyId)
                    moved
                } finally {
                    if (outputBitmap !== cropped) outputBitmap.recycle()
                }
            } finally {
                if (cropped !== source) cropped.recycle()
            }
        } finally {
            if (!source.isRecycled) source.recycle()
        }
    }

    suspend fun setProductFolder(productUuid: String, folder: String) {
        require(folder in TARGET_FOLDERS) { "Неизвестная папка фото" }
        val beforeRows = db.photos().forProduct(productUuid)
        if (beforeRows.isEmpty() || beforeRows.all { it.remoteFolder == folder }) return
        val historyId = history.captureCurrent(productUuid, "photo_folder", "Папка фото → $folder")
        db.withTransaction {
            val now = System.currentTimeMillis()
            val rows = db.photos().forProduct(productUuid)
            db.photos().putAll(rows.map { row ->
                val nextStatus = when {
                    row.processedPath.isBlank() -> "IMPORTED"
                    row.status == "ATTACHED" || row.status == "UPLOADED" -> "READY"
                    else -> row.status
                }
                row.copy(remoteFolder = folder, remotePath = remotePath(folder, row.fileName), status = nextStatus, error = "", updatedAt = now)
            })
        }
        refreshProductImageFields(productUuid)
        auditPhoto(productUuid, "photo_folder", "Папка фото изменена: $folder", historyId)
    }

    suspend fun setMain(photoId: String) {
        val selectedBefore = db.photos().get(photoId) ?: return
        val beforeRows = db.photos().forProduct(selectedBefore.productUuid)
        if (selectedBefore.isMain && beforeRows.count { it.isMain } == 1) return
        val historyId = history.captureCurrent(selectedBefore.productUuid, "photo_main", "Главное фото → ${selectedBefore.fileName}")
        val productUuid = db.withTransaction {
            val selected = db.photos().get(photoId) ?: return@withTransaction null
            val now = System.currentTimeMillis()
            db.photos().putAll(db.photos().forProduct(selected.productUuid).map { it.copy(isMain = it.id == photoId, updatedAt = now) })
            selected.productUuid
        } ?: return
        refreshProductImageFields(productUuid)
        auditPhoto(productUuid, "photo_main", "Назначено главное фото: ${selectedBefore.fileName}", historyId)
    }

    suspend fun delete(photoId: String) {
        var before = db.photos().get(photoId) ?: return
        val historyId = history.captureCurrent(before.productUuid, "photo_delete", "Удаление фото ${before.fileName}")
        removeGalleryMarker(before) // legacy 0.2.2 marker only
        if (before.status !in setOf("ATTACHED", "UPLOADED") && before.sourceStage == STAGE_PROCESSED) {
            before = moveWorkspaceOriginal(before, STAGE_INBOX)
            db.photos().put(before)
        }
        val productUuid = db.withTransaction {
            val row = db.photos().get(photoId) ?: return@withTransaction null
            // Keep private originals/processed files while history can still restore this photo.
            db.photos().delete(photoId)
            val remaining = db.photos().forProduct(row.productUuid)
            if (row.isMain && remaining.isNotEmpty()) {
                val product = db.products().get(row.productUuid)
                val existingMain = product?.let { JsonTools.path(JsonTools.objectOf(it.localJson), "product.image")?.jsonPrimitive?.contentOrNull }.orEmpty()
                if (product?.productId == null || existingMain.isBlank() || existingMain == row.remotePath) {
                    val first = remaining.minBy { it.sortOrder }
                    db.photos().putAll(remaining.map { it.copy(isMain = it.id == first.id, updatedAt = System.currentTimeMillis()) })
                }
            }
            row.productUuid
        } ?: return

        val product = db.products().get(productUuid) ?: return
        val remaining = db.photos().forProduct(productUuid)
        if (product.productId == null) {
            if (remaining.isEmpty()) {
                productEditor.updateField(productUuid, "product.image", JsonPrimitive(""), recordHistory = false, auditChange = false)
                productEditor.updateField(productUuid, "images", JsonArray(emptyList()), recordHistory = false, auditChange = false)
            } else {
                refreshProductImageFields(productUuid)
            }
            auditPhoto(productUuid, "photo_delete", "Фото удалено из карточки: ${before.fileName}", historyId)
            return
        }

        // Existing server product: remove only this phone-managed path and preserve all other images.
        val payload = JsonTools.objectOf(product.localJson)
        val oldMain = JsonTools.path(payload, "product.image")?.jsonPrimitive?.contentOrNull.orEmpty()
        val surviving = (payload["images"] as? JsonArray).orEmpty().mapNotNull { element ->
            (element as? kotlinx.serialization.json.JsonObject)?.get("image")?.jsonPrimitive?.contentOrNull
        }.filter { it.isNotBlank() && it != before.remotePath }.distinct().toMutableList()
        var newMain = oldMain
        if (oldMain == before.remotePath) {
            newMain = surviving.firstOrNull().orEmpty()
        }
        if (newMain.isNotBlank()) {
            surviving.remove(newMain)
            surviving.add(0, newMain)
        }
        productEditor.updateField(productUuid, "product.image", JsonPrimitive(newMain), recordHistory = false, auditChange = false)
        productEditor.updateField(productUuid, "images", JsonArray(surviving.mapIndexed { index, path ->
            buildJsonObject { put("image", JsonPrimitive(path)); put("sort_order", JsonPrimitive(index)) }
        }), recordHistory = false, auditChange = false)
        auditPhoto(productUuid, "photo_delete", "Фото удалено из карточки: ${before.fileName}", historyId)
    }

    suspend fun uploadPending(allowedProductUuids: Set<String>): Int = withContext(Dispatchers.IO) {
        if (allowedProductUuids.isEmpty()) return@withContext 0
        var uploaded = 0
        var firstCollision: BridgeException? = null
        for (row0 in db.photos().pendingUploads()) {
            if (row0.productUuid !in allowedProductUuids) continue
            val row = db.photos().get(row0.id) ?: continue
            if (row.processedPath.isBlank()) continue
            if (!row.sourceUri.isNullOrBlank() && row.sourceStage == STAGE_INBOX) {
                db.photos().put(row.copy(
                    status = "ERROR",
                    error = row.sourceError ?: "Оригинал ещё находится в 01_Eingang; сначала завершите обработку/перемещение",
                    updatedAt = System.currentTimeMillis(),
                ))
                continue
            }
            val file = File(row.processedPath)
            if (!file.isFile) {
                db.photos().put(row.copy(status = "ERROR", error = "Обработанный файл отсутствует", updatedAt = System.currentTimeMillis()))
                continue
            }
            db.photos().put(row.copy(status = "UPLOADING", error = "", updatedAt = System.currentTimeMillis()))
            try {
                val bytes = file.readBytes()
                val sha = sha256(bytes)
                val productBeforeUpload = db.products().get(row.productUuid)
                val mayReplaceExisting = productBeforeUpload?.productId != null && payloadReferencesPath(JsonTools.objectOf(productBeforeUpload.baseJson), row.remotePath)
                val result = bridge.post("image_upload", buildJsonObject {
                    put("file_id", JsonPrimitive(row.id))
                    put("folder", JsonPrimitive(row.remoteFolder))
                    put("filename", JsonPrimitive(row.fileName))
                    put("sha256", JsonPrimitive(sha))
                    put("replace", JsonPrimitive(mayReplaceExisting))
                    put("data_base64", JsonPrimitive(Base64.encodeToString(bytes, Base64.NO_WRAP)))
                })
                val returnedPath = result["path"]?.jsonPrimitive?.content.orEmpty()
                val expected = remotePath(row.remoteFolder, row.fileName)
                if (returnedPath != expected) error("Bridge вернул неожиданный путь: $returnedPath")
                val product = db.products().get(row.productUuid)
                val alreadyReferencedOnServer = product?.productId != null && payloadReferencesPath(JsonTools.objectOf(product.baseJson), returnedPath)
                db.photos().put(row.copy(
                    remotePath = returnedPath, sha256 = sha,
                    status = if (alreadyReferencedOnServer) "ATTACHED" else "UPLOADED",
                    error = "", updatedAt = System.currentTimeMillis()
                ))
                uploaded++
            } catch (e: Exception) {
                val collision = e is BridgeException && e.status == 409 && collisionPath(e.message.orEmpty()) != null
                val storedError = if (collision) "$COLLISION_PREFIX${row.remotePath}" else (e.message ?: "Ошибка загрузки")
                db.photos().put(row.copy(status = "ERROR", error = storedError, updatedAt = System.currentTimeMillis()))
                if (collision) {
                    if (firstCollision == null) firstCollision = e as BridgeException
                    continue
                }
                throw e
            }
        }
        firstCollision?.let {
            throw BridgeException("Есть фото с одинаковым именем, но другим содержимым. Выберите вариант для каждого конфликта ниже.", 409)
        }
        uploaded
    }

    suspend fun useServerImage(photoId: String) = withContext(Dispatchers.IO) {
        val row = db.photos().get(photoId) ?: error("Фото не найдено")
        val path = row.remotePath.ifBlank { remotePath(row.remoteFolder, row.fileName) }
        require(collisionPath(row.error) != null) { "У фото нет конфликта имени" }
        val bytes = bridge.getBytes("image_fetch", mapOf("path" to path))
        require(bytes.size >= 16) { "Серверное фото пустое" }
        val serverSha = sha256(bytes)
        val processed = File(row.processedPath)
        if (row.processedPath.isNotBlank() && processed.parentFile?.let { it.exists() || it.mkdirs() } == true) {
            processed.writeBytes(bytes)
        }
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        db.photos().put(row.copy(
            remotePath = path,
            sha256 = serverSha,
            processedWidth = bounds.outWidth.coerceAtLeast(0),
            processedHeight = bounds.outHeight.coerceAtLeast(0),
            status = "UPLOADED",
            error = "",
            updatedAt = System.currentTimeMillis(),
        ))
        auditPhoto(row.productUuid, "photo_collision_server", "Оставлено фото с сервера: ${row.fileName}", null)
    }

    suspend fun renameCollisionAndRetry(photoId: String): String = withContext(Dispatchers.IO) {
        val row = db.photos().get(photoId) ?: error("Фото не найдено")
        require(collisionPath(row.error) != null) { "У фото нет конфликта имени" }
        val dot = row.fileName.lastIndexOf('.')
        val stem = if (dot > 0) row.fileName.substring(0, dot) else row.fileName
        val ext = if (dot > 0) row.fileName.substring(dot) else ""
        var chosen: String? = null
        for (index in 2..9999) {
            val candidate = "${stem}_$index$ext"
            val path = remotePath(row.remoteFolder, candidate)
            val root = bridge.post("image_manifest", buildJsonObject {
                put("paths", JsonArray(listOf(JsonPrimitive(path))))
            })
            val exists = ((root["images"] as? kotlinx.serialization.json.JsonObject)
                ?.get(path) as? kotlinx.serialization.json.JsonObject)
                ?.get("exists")?.jsonPrimitive?.booleanOrNull == true
            val usedLocally = db.photos().countRemotePathExcept(path, row.id) > 0
            if (!exists && !usedLocally) {
                chosen = candidate
                break
            }
        }
        val filename = chosen ?: error("Не удалось подобрать свободное имя фото")
        val path = remotePath(row.remoteFolder, filename)
        db.photos().put(row.copy(
            fileName = filename,
            remotePath = path,
            sha256 = "",
            status = "READY",
            error = "",
            updatedAt = System.currentTimeMillis(),
        ))
        refreshProductImageFields(row.productUuid)
        auditPhoto(row.productUuid, "photo_collision_rename", "Фото будет загружено как $filename", null)
        filename
    }

    suspend fun replaceServerImage(photoId: String) = withContext(Dispatchers.IO) {
        val row = db.photos().get(photoId) ?: error("Фото не найдено")
        require(collisionPath(row.error) != null) { "У фото нет конфликта имени" }
        val file = File(row.processedPath)
        require(file.isFile) { "Обработанный файл отсутствует" }
        val bytes = file.readBytes()
        val sha = sha256(bytes)
        val expected = row.remotePath.ifBlank { remotePath(row.remoteFolder, row.fileName) }
        val result = bridge.post("image_upload", buildJsonObject {
            put("file_id", JsonPrimitive(row.id))
            put("folder", JsonPrimitive(row.remoteFolder))
            put("filename", JsonPrimitive(row.fileName))
            put("sha256", JsonPrimitive(sha))
            put("replace", JsonPrimitive(true))
            put("data_base64", JsonPrimitive(Base64.encodeToString(bytes, Base64.NO_WRAP)))
        })
        val returnedPath = result["path"]?.jsonPrimitive?.content.orEmpty()
        if (returnedPath != expected) error("Bridge вернул неожиданный путь: $returnedPath")
        db.photos().put(row.copy(
            remotePath = returnedPath,
            sha256 = sha,
            status = "UPLOADED",
            error = "",
            updatedAt = System.currentTimeMillis(),
        ))
        auditPhoto(row.productUuid, "photo_collision_replace", "Серверное фото заменено: ${row.fileName}", null)
    }

    suspend fun markProductAttached(productUuid: String) = withContext(Dispatchers.IO) {
        db.photos().markUploadedAttached(productUuid, System.currentTimeMillis())
        db.photos().forProduct(productUuid).forEach { row ->
            if (row.status == "ATTACHED" && row.sourceStage == STAGE_PROCESSED) {
                val moved = moveWorkspaceOriginal(row, STAGE_UPLOADED)
                db.photos().put(moved)
            }
        }
    }

    suspend fun refreshProductImageFields(productUuid: String) {
        val product = db.products().get(productUuid) ?: return
        val payload = JsonTools.objectOf(product.localJson)
        val currentMain = JsonTools.path(payload, "product.image")?.jsonPrimitive?.contentOrNull.orEmpty()
        val all = db.photos().forProduct(productUuid).sortedBy { it.sortOrder }
        val processed = all.filter { it.processedPath.isNotBlank() }
        if (processed.isEmpty()) return

        val declaredLocalMain = all.firstOrNull { it.isMain && it.processedPath.isNotBlank() }
        val mainPath = when {
            declaredLocalMain != null -> declaredLocalMain.remotePath
            product.productId != null && currentMain.isNotBlank() -> currentMain
            else -> processed.first().remotePath
        }

        val localPaths = all.map { it.remotePath }.filter { it.isNotBlank() }.toSet()
        val localExtras = processed
            .filter { it.remotePath != mainPath }
            .sortedBy { it.sortOrder }
            .map { it.remotePath }

        val extraPaths = if (product.productId == null) {
            localExtras
        } else {
            val existingRows = (payload["images"] as? JsonArray).orEmpty()
            val existingExtras = existingRows.mapNotNull { element ->
                (element as? kotlinx.serialization.json.JsonObject)?.get("image")?.jsonPrimitive?.contentOrNull
            }.filter { path ->
                path.isNotBlank() && path != currentMain && path != mainPath && path !in localPaths
            }
            buildList {
                if (mainPath != currentMain && currentMain.isNotBlank()) add(currentMain)
                addAll(existingExtras)
                addAll(localExtras)
            }.distinct()
        }

        productEditor.updateField(productUuid, "product.image", JsonPrimitive(mainPath), recordHistory = false, auditChange = false)
        // Theme contract: the main photo is duplicated at additional image sort_order=0.
        val ordered = buildList {
            if (mainPath.isNotBlank()) add(mainPath)
            addAll(extraPaths.filter { it != mainPath })
        }
        productEditor.updateField(productUuid, "images", JsonArray(ordered.mapIndexed { index, path ->
            buildJsonObject { put("image", JsonPrimitive(path)); put("sort_order", JsonPrimitive(index)) }
        }), recordHistory = false, auditChange = false)
    }

    /** Reorder only non-main phone-local photos. The main duplicate is always server position 0. */
    suspend fun moveAdditional(photoId: String, delta: Int) {
        if (delta == 0) return
        val selected = db.photos().get(photoId) ?: return
        if (selected.isMain) return
        val extras = db.photos().forProduct(selected.productUuid)
            .filter { !it.isMain }
            .sortedBy { it.sortOrder }
        val index = extras.indexOfFirst { it.id == photoId }
        if (index < 0) return
        val targetIndex = (index + delta).coerceIn(0, extras.lastIndex)
        if (targetIndex == index) return
        val historyId = history.captureCurrent(selected.productUuid, "photo_reorder", "Изменение порядка фото")
        val other = extras[targetIndex]
        val now = System.currentTimeMillis()
        db.withTransaction {
            db.photos().put(selected.copy(sortOrder = other.sortOrder, updatedAt = now))
            db.photos().put(other.copy(sortOrder = selected.sortOrder, updatedAt = now))
        }
        refreshProductImageFields(selected.productUuid)
        auditPhoto(selected.productUuid, "photo_reorder", "Порядок дополнительных фото изменён", historyId)
    }

    suspend fun cleanupLegacyGalleryMarkers(productUuid: String) = withContext(Dispatchers.IO) {
        db.photos().forProduct(productUuid).forEach { row ->
            if (!row.galleryUri.isNullOrBlank()) {
                removeGalleryMarker(row)
                db.photos().put(row.copy(galleryUri = null, galleryState = null, galleryError = null))
            }
        }
    }

    suspend fun reconcileWorkspaceStages(productUuid: String) = withContext(Dispatchers.IO) {
        db.photos().forProduct(productUuid).forEach { row ->
            if (row.status == "ATTACHED" && row.sourceStage == STAGE_PROCESSED) {
                db.photos().put(moveWorkspaceOriginal(row, STAGE_UPLOADED))
            }
        }
    }

    suspend fun configureWorkspace(treeUri: Uri) = withContext(Dispatchers.IO) {
        val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        runCatching { context.contentResolver.takePersistableUriPermission(treeUri, flags) }
        val root = DocumentFile.fromTreeUri(context, treeUri) ?: error("Не удалось открыть выбранную папку")
        require(root.canRead() && root.canWrite()) { "Нужен доступ на чтение и запись выбранной папки" }
        ensureStageFolders(root)
        db.settings().put(SettingEntity(WORKSPACE_SETTING, treeUri.toString()))
    }

    suspend fun workspaceStatus(): WorkspaceStatus = withContext(Dispatchers.IO) {
        val root = workspaceRoot() ?: return@withContext WorkspaceStatus(configured = false)
        runCatching {
            val inbox = stageFolder(root, STAGE_INBOX, create = true)!!
            val processed = stageFolder(root, STAGE_PROCESSED, create = true)!!
            val uploaded = stageFolder(root, STAGE_UPLOADED, create = true)!!
            WorkspaceStatus(
                configured = true,
                rootName = root.name.orEmpty().ifBlank { "HandelDesk" },
                inboxCount = imageFiles(inbox).size,
                processedCount = imageFiles(processed).size,
                uploadedCount = imageFiles(uploaded).size,
            )
        }.getOrElse { WorkspaceStatus(configured = true, rootName = root.name.orEmpty(), error = it.message) }
    }

    suspend fun listInbox(): List<WorkspacePhoto> = withContext(Dispatchers.IO) {
        val root = workspaceRoot() ?: return@withContext emptyList()
        val folder = stageFolder(root, STAGE_INBOX, create = true) ?: return@withContext emptyList()
        val used = db.photos().usedSourceUris().toSet()
        imageFiles(folder).filterNot { it.uri.toString() in used }.map { file ->
            WorkspacePhoto(
                uri = file.uri.toString(),
                name = file.name.orEmpty(),
                size = file.length(),
                modifiedAt = file.lastModified(),
            )
        }.sortedWith(compareBy<WorkspacePhoto> { it.modifiedAt }.thenBy { it.name.lowercase() })
    }

    suspend fun returnOriginalsToInbox(rows: List<LocalPhotoEntity>) = withContext(Dispatchers.IO) {
        rows.forEach { row ->
            if (row.sourceStage == STAGE_PROCESSED) {
                val moved = moveWorkspaceOriginal(row, STAGE_INBOX)
                db.photos().put(moved)
            }
        }
    }

    suspend fun suggestedFolder(productUuid: String): String = suggestFolder(productUuid)

    private suspend fun suggestFolder(productUuid: String): String {
        val product = db.products().get(productUuid) ?: return "Fernbedienungen"
        val payload = JsonTools.objectOf(product.localJson)
        val categoryIds = (payload["categories"] as? JsonArray).orEmpty().mapNotNull { it.jsonPrimitive.intOrNull }.toSet()
        val categoryText = db.references().categories().filter { it.categoryId in categoryIds }.joinToString(" ") { it.name }
        val text = (product.name + " " + product.model + " " + categoryText).lowercase()
        return when {
            "kabel" in text || "cable" in text -> "Kabel"
            "fernbed" in text || "remote" in text -> "Fernbedienungen"
            "laptop" in text -> "Laptop"
            "monitor" in text -> "monitor"
            "hdd" in text || "festplatte" in text -> "HDD-Ersatzteile"
            "gps" in text || "konsole" in text -> "GPSundKonsole"
            "tablet" in text || " tab " in " $text " -> "Tab"
            "reader" in text -> "Freader"
            else -> "Fernbedienungen"
        }
    }


    suspend fun restoreHistoryRows(productUuid: String, snapshotRows: List<LocalPhotoEntity>) = withContext(Dispatchers.IO) {
        val currentProduct = db.products().get(productUuid) ?: return@withContext
        val currentRows = db.photos().forProduct(productUuid)
        val currentById = currentRows.associateBy { it.id }
        val snapshotById = snapshotRows.associateBy { it.id }
        val extras = currentRows.filter { it.id !in snapshotById }

        // File-system moves happen before the DB replacement. If Android cannot move an
        // unsynced original back to the requested stage, abort instead of leaving a half-restored
        // card with an orphan in another workspace folder.
        val restoredSources = mutableMapOf<String, Pair<String, String>>() // photoId -> (uri, stage)

        extras.filter { it.status !in setOf("ATTACHED", "UPLOADED") && it.sourceStage == STAGE_PROCESSED }.forEach { row ->
            val moved = moveWorkspaceOriginal(row, STAGE_INBOX)
            require(moved.sourceStage == STAGE_INBOX && moved.sourceError.isNullOrBlank()) {
                moved.sourceError ?: "Не удалось вернуть оригинал ${row.fileName} в $DIR_INBOX"
            }
            db.photos().put(moved)
        }

        snapshotRows.forEach { snap ->
            val existing = currentById[snap.id]
            val serverFileKnown = existing?.status in setOf("ATTACHED", "UPLOADED") ||
                snap.status in setOf("ATTACHED", "UPLOADED") ||
                existing?.sourceStage == STAGE_UPLOADED || snap.sourceStage == STAGE_UPLOADED ||
                payloadReferencesPath(JsonTools.objectOf(currentProduct.baseJson), snap.remotePath)
            val desiredStage = snap.sourceStage

            // Once a photo has really reached the server, do not move its untouched original
            // backwards from 03_Hochgeladen merely because an old local point is restored.
            if (!serverFileKnown && desiredStage in setOf(STAGE_INBOX, STAGE_PROCESSED)) {
                val probe = existing ?: snap
                val actual = locateWorkspaceSource(probe)
                if (actual != null) {
                    if (actual.first != desiredStage) {
                        val moved = moveWorkspaceOriginal(
                            probe.copy(sourceUri = actual.second.uri.toString(), sourceStage = actual.first),
                            desiredStage!!,
                        )
                        require(moved.sourceStage == desiredStage && moved.sourceError.isNullOrBlank()) {
                            moved.sourceError ?: "Не удалось вернуть оригинал ${snap.fileName} в нужную папку"
                        }
                        moved.sourceUri?.let { restoredSources[snap.id] = it to desiredStage }
                    } else {
                        restoredSources[snap.id] = actual.second.uri.toString() to actual.first
                    }
                } else if (!probe.sourceUri.isNullOrBlank()) {
                    error("Оригинал ${snap.fileName} не найден в рабочей папке HandelDesk")
                }
            }
        }

        db.withTransaction {
            // Photos added after the snapshot are detached from the active local photo set.
            // An already uploaded server file and its untouched original are never deleted here.
            // current.baseJson still records the current server reference, therefore restoring
            // an older local card creates the normal image diff and only a later explicit Sync
            // changes that reference on the website.
            extras.forEach { row ->
                val latest = db.photos().get(row.id) ?: row
                db.photos().delete(latest.id)
            }

            snapshotRows.forEach { snap ->
                val existing = currentById[snap.id]
                val referencedByCurrentServer = payloadReferencesPath(JsonTools.objectOf(currentProduct.baseJson), snap.remotePath)
                val serverFileKnown = referencedByCurrentServer ||
                    existing?.status in setOf("ATTACHED", "UPLOADED") ||
                    snap.status in setOf("ATTACHED", "UPLOADED") ||
                    existing?.sourceStage == STAGE_UPLOADED || snap.sourceStage == STAGE_UPLOADED
                val processedExists = snap.processedPath.isNotBlank() && File(snap.processedPath).isFile
                val safeStatus = when {
                    referencedByCurrentServer -> "ATTACHED"
                    serverFileKnown -> "UPLOADED"
                    processedExists -> "READY"
                    else -> "IMPORTED"
                }
                val restoredSource = restoredSources[snap.id]
                val row = snap.copy(
                    status = safeStatus,
                    error = "",
                    sourceUri = restoredSource?.first ?: existing?.sourceUri ?: snap.sourceUri,
                    sourceStage = when {
                        referencedByCurrentServer || serverFileKnown -> existing?.sourceStage ?: snap.sourceStage ?: STAGE_UPLOADED
                        restoredSource != null -> restoredSource.second
                        else -> existing?.sourceStage ?: snap.sourceStage
                    },
                    sourceError = null,
                    updatedAt = System.currentTimeMillis(),
                )
                db.photos().put(row)
            }
        }

        // Re-render old crop/rotation/resize settings from the untouched private original.
        // No binary copy is stored in product_history.
        snapshotRows.forEach { snap ->
            if (snap.processedPath.isBlank() || !File(snap.originalPath).isFile) return@forEach
            runCatching { renderProcessedOnly(snap) }
                .onSuccess { regenerated ->
                    val existing = db.photos().get(snap.id) ?: return@onSuccess
                    db.photos().put(regenerated.copy(
                        status = existing.status,
                        sourceUri = existing.sourceUri,
                        sourceStage = existing.sourceStage,
                        sourceError = existing.sourceError,
                        updatedAt = System.currentTimeMillis(),
                    ))
                }
                .onFailure { e ->
                    val existing = db.photos().get(snap.id) ?: return@onFailure
                    db.photos().put(existing.copy(
                        error = "Не удалось восстановить обработанную копию: ${e.message ?: "ошибка"}",
                        status = if (existing.status in setOf("ATTACHED", "UPLOADED")) existing.status else "ERROR",
                        updatedAt = System.currentTimeMillis(),
                    ))
                }
        }
    }

    private fun renderProcessedOnly(row: LocalPhotoEntity): LocalPhotoEntity {
        val source = decodeOriented(File(row.originalPath), 0, row.rotationDegrees)
        try {
            val left = (row.cropLeft.coerceIn(0f, 0.98f) * source.width).roundToInt().coerceIn(0, source.width - 2)
            val top = (row.cropTop.coerceIn(0f, 0.98f) * source.height).roundToInt().coerceIn(0, source.height - 2)
            val right = (row.cropRight.coerceIn(0.02f, 1f) * source.width).roundToInt().coerceIn(left + 1, source.width)
            val bottom = (row.cropBottom.coerceIn(0.02f, 1f) * source.height).roundToInt().coerceIn(top + 1, source.height)
            val cropped = Bitmap.createBitmap(source, left, top, right - left, bottom - top)
            try {
                val (outW, outH) = outputSize(cropped.width, cropped.height, row.targetWidth, row.targetHeight, row.keepAspect, row.doNotEnlarge)
                val output = if (outW == cropped.width && outH == cropped.height) cropped else Bitmap.createScaledBitmap(cropped, outW, outH, true)
                try {
                    val itemDir = File(row.originalPath).parentFile?.parentFile ?: error("Повреждён локальный путь фото")
                    val processedDir = File(itemDir, "processed").apply { mkdirs() }
                    val outFile = File(processedDir, row.fileName)
                    FileOutputStream(outFile).use { stream ->
                        when (outFile.extension.lowercase()) {
                            "png" -> output.compress(Bitmap.CompressFormat.PNG, 100, stream)
                            "webp" -> {
                                @Suppress("DEPRECATION")
                                val format = if (Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP
                                output.compress(format, 95, stream)
                            }
                            else -> output.compress(Bitmap.CompressFormat.JPEG, 95, stream)
                        }
                    }
                    return row.copy(
                        processedPath = outFile.absolutePath, processedWidth = outW, processedHeight = outH,
                        sha256 = sha256(outFile), error = "", updatedAt = System.currentTimeMillis()
                    )
                } finally { if (output !== cropped) output.recycle() }
            } finally { if (cropped !== source) cropped.recycle() }
        } finally { if (!source.isRecycled) source.recycle() }
    }

    private suspend fun auditPhoto(productUuid: String, type: String, summary: String, historyId: Long?) {
        val product = db.products().get(productUuid)
        val details = buildJsonObject { historyId?.let { put("history_id", JsonPrimitive(it)) } }
        db.audit().insert(de.handeltheke.handeldesk.data.local.AuditEventEntity(
            createdAt = System.currentTimeMillis(), sessionId = db.settings().get("active_session_id"),
            eventType = type, entityType = "product", entityUuid = productUuid, entityId = product?.productId,
            source = "android", summary = summary, detailsJson = details.toString()
        ))
    }

    private suspend fun workspaceRoot(): DocumentFile? {
        val raw = db.settings().get(WORKSPACE_SETTING)?.takeIf { it.isNotBlank() } ?: return null
        return DocumentFile.fromTreeUri(context, Uri.parse(raw))?.takeIf { it.exists() && it.isDirectory }
    }

    private fun ensureStageFolders(root: DocumentFile) {
        listOf(DIR_INBOX, DIR_PROCESSED, DIR_UPLOADED).forEach { name ->
            val existing = root.findFile(name)
            if (existing == null) root.createDirectory(name) ?: error("Не удалось создать папку $name")
            else require(existing.isDirectory) { "$name уже существует, но это не папка" }
        }
    }

    private fun stageFolder(root: DocumentFile, stage: String?, create: Boolean): DocumentFile? {
        val name = when (stage) {
            STAGE_INBOX -> DIR_INBOX
            STAGE_PROCESSED -> DIR_PROCESSED
            STAGE_UPLOADED -> DIR_UPLOADED
            else -> return null
        }
        val found = root.findFile(name)
        if (found != null) return found.takeIf { it.isDirectory }
        return if (create) root.createDirectory(name) else null
    }

    private fun imageFiles(folder: DocumentFile): List<DocumentFile> = folder.listFiles().filter {
        it.isFile && isImageName(it.name.orEmpty())
    }

    private fun isImageName(name: String): Boolean = name.substringAfterLast('.', "").lowercase() in
        setOf("jpg", "jpeg", "png", "webp", "heic", "heif")

    private suspend fun locateWorkspaceSource(row: LocalPhotoEntity): Pair<String, DocumentFile>? {
        val root = workspaceRoot() ?: return null
        val expectedUri = row.sourceUri?.takeIf { it.isNotBlank() }?.let(Uri::parse)
        val candidates = mutableListOf<Pair<String, DocumentFile>>()
        for (stage in listOf(STAGE_INBOX, STAGE_PROCESSED, STAGE_UPLOADED)) {
            val folder = stageFolder(root, stage, create = false) ?: continue
            val files = folder.listFiles().filter { it.isFile }
            if (expectedUri != null) {
                files.firstOrNull { it.uri == expectedUri }?.let { return stage to it }
            }
            files.filter { it.name == row.fileName }.forEach { candidates += stage to it }
        }
        if (candidates.size <= 1) return candidates.firstOrNull()

        // Same camera filename can theoretically exist in two status folders. Match against
        // HandelDesk's untouched private original instead of guessing by folder order.
        val privateOriginal = File(row.originalPath).takeIf { it.isFile } ?: return null
        val expectedHash = sha256(privateOriginal)
        return candidates.firstOrNull { (_, doc) ->
            runCatching { sha256(doc.uri) }.getOrNull() == expectedHash
        }
    }

    private suspend fun moveWorkspaceOriginal(row: LocalPhotoEntity, targetStage: String): LocalPhotoEntity {
        if (row.sourceStage == STAGE_EXTERNAL || row.sourceUri.isNullOrBlank() || row.sourceStage == targetStage) {
            return row.copy(sourceError = null)
        }
        return runCatching {
            val root = workspaceRoot() ?: error("Рабочая папка HandelDesk не настроена")
            ensureStageFolders(root)
            val from = stageFolder(root, row.sourceStage, create = false) ?: error("Исходная статусная папка не найдена")
            val to = stageFolder(root, targetStage, create = true) ?: error("Целевая статусная папка не найдена")
            val expectedUri = Uri.parse(row.sourceUri)
            val source = from.listFiles().firstOrNull { it.uri == expectedUri }
                ?: from.findFile(row.fileName)
                ?: error("Оригинал ${row.fileName} не найден в ${from.name}")
            val collision = to.findFile(row.fileName)
            require(collision == null) { "В ${to.name} уже есть файл ${row.fileName}" }

            val resolver = context.contentResolver
            val movedUri = runCatching {
                DocumentsContract.moveDocument(resolver, source.uri, from.uri, to.uri)
            }.getOrNull() ?: run {
                val created = to.createFile(mimeType(row.fileName), row.fileName)
                    ?: error("Не удалось создать ${row.fileName} в ${to.name}")
                try {
                    resolver.openInputStream(source.uri)?.use { input ->
                        resolver.openOutputStream(created.uri, "w")?.use { output -> input.copyTo(output) }
                            ?: error("Не удалось записать оригинал")
                    } ?: error("Не удалось прочитать оригинал")
                    val srcLen = source.length()
                    val dstLen = created.length()
                    if (srcLen > 0 && dstLen > 0) require(srcLen == dstLen) { "Размер файла после перемещения не совпал" }
                    val srcHash = sha256(source.uri)
                    val dstHash = sha256(created.uri)
                    require(srcHash == dstHash) { "Контрольная сумма оригинала после перемещения не совпала" }
                    require(source.delete()) { "Копия создана, но исходный файл не удалось удалить" }
                    created.uri
                } catch (t: Throwable) {
                    runCatching { created.delete() }
                    throw t
                }
            }
            row.copy(sourceUri = movedUri.toString(), sourceStage = targetStage, sourceError = null, updatedAt = System.currentTimeMillis())
        }.getOrElse { e ->
            row.copy(sourceError = e.message ?: "Не удалось переместить оригинал", updatedAt = System.currentTimeMillis())
        }
    }

    /** Legacy marker cleanup from v0.2.2. */
    fun removeGalleryMarker(row: LocalPhotoEntity) {
        val uri = row.galleryUri?.takeIf { it.isNotBlank() }?.let(Uri::parse) ?: return
        runCatching { context.contentResolver.delete(uri, null, null) }
    }

    fun removeGalleryMarkers(rows: List<LocalPhotoEntity>) { rows.forEach(::removeGalleryMarker) }

    private fun mimeType(fileName: String): String = when (fileName.substringAfterLast('.', "").lowercase()) {
        "png" -> "image/png"
        "webp" -> "image/webp"
        "heic", "heif" -> "image/heic"
        else -> "image/jpeg"
    }

    private fun payloadReferencesPath(payload: kotlinx.serialization.json.JsonObject, path: String): Boolean {
        val main = payload["product"]?.jsonObject?.get("image")?.jsonPrimitive?.contentOrNull.orEmpty()
        if (main == path) return true
        return (payload["images"] as? JsonArray).orEmpty().any { element ->
            (element as? kotlinx.serialization.json.JsonObject)?.get("image")?.jsonPrimitive?.contentOrNull == path
        }
    }

    private fun safeDisplayName(uri: Uri, fallbackId: String): String {
        var display: String? = null
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) display = c.getString(0)
        }
        val candidate = display?.trim().orEmpty().ifBlank { "IMG_${fallbackId.take(8)}.jpg" }
        require(!candidate.contains('/') && !candidate.contains('\\') && !candidate.contains('\u0000')) { "Недопустимое имя фото" }
        return candidate.take(180)
    }

    private fun remotePath(folder: String, fileName: String) = "catalog/product/$folder/$fileName"

    private fun orientedDimensions(file: File): Pair<Int, Int> {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, opts)
        var w = opts.outWidth.coerceAtLeast(1)
        var h = opts.outHeight.coerceAtLeast(1)
        val r = exifRotation(file)
        if (r == 90 || r == 270) { val t = w; w = h; h = t }
        return w to h
    }

    private fun decodeOriented(file: File, maxDimension: Int, userRotation: Int): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        var sample = 1
        if (maxDimension > 0) {
            while (max(bounds.outWidth, bounds.outHeight) / sample > maxDimension * 2) sample *= 2
        }
        val decoded = BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply {
            inSampleSize = sample.coerceAtLeast(1)
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }) ?: error("Не удалось прочитать изображение")
        val totalRotation = normalizedRotation(exifRotation(file) + userRotation)
        if (totalRotation == 0) return decoded
        val matrix = Matrix().apply { postRotate(totalRotation.toFloat()) }
        val rotated = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
        if (rotated !== decoded) decoded.recycle()
        return rotated
    }

    private fun exifRotation(file: File): Int = runCatching {
        when (ExifInterface(file).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
            ExifInterface.ORIENTATION_ROTATE_90, ExifInterface.ORIENTATION_TRANSPOSE -> 90
            ExifInterface.ORIENTATION_ROTATE_180, ExifInterface.ORIENTATION_FLIP_VERTICAL -> 180
            ExifInterface.ORIENTATION_ROTATE_270, ExifInterface.ORIENTATION_TRANSVERSE -> 270
            else -> 0
        }
    }.getOrDefault(0)

    private fun normalizedRotation(value: Int): Int = ((value % 360) + 360) % 360

    private fun outputSize(srcW: Int, srcH: Int, requestedW: Int, requestedH: Int, keepAspect: Boolean, doNotEnlarge: Boolean): Pair<Int, Int> {
        if (requestedW <= 0 && requestedH <= 0) return srcW to srcH
        if (!keepAspect) {
            var w = if (requestedW > 0) requestedW else srcW
            var h = if (requestedH > 0) requestedH else srcH
            if (doNotEnlarge) { w = min(w, srcW); h = min(h, srcH) }
            return w.coerceAtLeast(1) to h.coerceAtLeast(1)
        }
        val scaleByW = if (requestedW > 0) requestedW.toDouble() / srcW else Double.POSITIVE_INFINITY
        val scaleByH = if (requestedH > 0) requestedH.toDouble() / srcH else Double.POSITIVE_INFINITY
        var scale = min(scaleByW, scaleByH)
        if (!scale.isFinite()) scale = if (requestedW > 0) scaleByW else scaleByH
        if (doNotEnlarge) scale = min(1.0, scale)
        return max(1, (srcW * scale).roundToInt()) to max(1, (srcH * scale).roundToInt())
    }

    private fun sha256(file: File): String = file.inputStream().use { stream ->
        val digest = MessageDigest.getInstance("SHA-256")
        val buf = ByteArray(64 * 1024)
        while (true) {
            val n = stream.read(buf)
            if (n <= 0) break
            digest.update(buf, 0, n)
        }
        digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun sha256(uri: Uri): String = context.contentResolver.openInputStream(uri)?.use { stream ->
        val digest = MessageDigest.getInstance("SHA-256")
        val buf = ByteArray(64 * 1024)
        while (true) {
            val n = stream.read(buf)
            if (n <= 0) break
            digest.update(buf, 0, n)
        }
        digest.digest().joinToString("") { "%02x".format(it) }
    } ?: error("Не удалось прочитать оригинал для проверки")

    private fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
}
