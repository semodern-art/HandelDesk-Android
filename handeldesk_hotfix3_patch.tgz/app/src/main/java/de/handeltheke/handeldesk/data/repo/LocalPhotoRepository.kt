package de.handeltheke.handeldesk.data.repo

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.os.Build
import android.os.Environment
import android.net.Uri
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Base64
import androidx.exifinterface.media.ExifInterface
import androidx.room.withTransaction
import de.handeltheke.handeldesk.data.local.HandelDeskDatabase
import de.handeltheke.handeldesk.data.local.LocalPhotoEntity
import de.handeltheke.handeldesk.data.remote.BridgeClient
import de.handeltheke.handeldesk.domain.JsonTools
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.UUID
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class LocalPhotoRepository(
    private val context: Context,
    private val db: HandelDeskDatabase,
    private val bridge: BridgeClient,
    private val productEditor: ProductEditorRepository,
) {
    companion object {
        val TARGET_FOLDERS = listOf(
            "Fernbedienungen", "Kabel", "Freader", "Sonstiges", "GPSundKonsole",
            "Laptop", "HDD-Ersatzteile", "monitor", "Tab"
        )
        val FAST_FOLDERS = listOf("Fernbedienungen", "Kabel")
    }

    data class PreviewBitmap(val bitmap: Bitmap, val width: Int, val height: Int)

    suspend fun importUris(productUuid: String, uris: List<Uri>): List<String> = withContext(Dispatchers.IO) {
        if (uris.isEmpty()) return@withContext emptyList()
        val folder = suggestFolder(productUuid)
        val product = db.products().get(productUuid)
        val currentMain = product?.let { JsonTools.path(JsonTools.objectOf(it.localJson), "product.image")?.jsonPrimitive?.contentOrNull }.orEmpty()
        val hadMain = db.photos().forProduct(productUuid).any { it.isMain } || currentMain.isNotBlank()
        val created = mutableListOf<String>()
        uris.forEachIndexed { index, uri ->
            val id = UUID.randomUUID().toString()
            val name = safeDisplayName(uri, id)
            val itemDir = File(context.filesDir, "handeldesk_photos/$productUuid/$id")
            val originalDir = File(itemDir, "original").apply { mkdirs() }
            val original = File(originalDir, name)
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(original).use { output -> input.copyTo(output) }
            } ?: error("Не удалось открыть $name")
            val (w, h) = orientedDimensions(original)
            val now = System.currentTimeMillis()
            val sort = db.photos().nextSortOrder(productUuid)
            val row = LocalPhotoEntity(
                id = id,
                productUuid = productUuid,
                fileName = name,
                originalPath = original.absolutePath,
                remoteFolder = folder,
                remotePath = remotePath(folder, name),
                isMain = !hadMain && index == 0,
                sortOrder = sort,
                sourceWidth = w,
                sourceHeight = h,
                createdAt = now,
                updatedAt = now,
            )
            db.photos().put(updateGalleryMarker(row, original, "WORKING"))
            created += id
        }
        created
    }

    suspend fun loadPreview(photoId: String, maxDimension: Int = 1800, rotationDegrees: Int? = null): PreviewBitmap = withContext(Dispatchers.IO) {
        val row = db.photos().get(photoId) ?: error("Фото не найдено")
        val file = File(row.originalPath)
        val oriented = decodeOriented(file, maxDimension, rotationDegrees ?: row.rotationDegrees)
        PreviewBitmap(oriented, oriented.width, oriented.height)
    }

    suspend fun process(
        photoId: String,
        cropLeft: Float,
        cropTop: Float,
        cropRight: Float,
        cropBottom: Float,
        rotationDegrees: Int,
        targetWidth: Int,
        targetHeight: Int,
        keepAspect: Boolean,
        doNotEnlarge: Boolean,
    ): LocalPhotoEntity = withContext(Dispatchers.IO) {
        val row = db.photos().get(photoId) ?: error("Фото не найдено")
        val source = decodeOriented(File(row.originalPath), 0, rotationDegrees)
        try {
            val left = (cropLeft.coerceIn(0f, 0.98f) * source.width).roundToInt().coerceIn(0, source.width - 2)
            val top = (cropTop.coerceIn(0f, 0.98f) * source.height).roundToInt().coerceIn(0, source.height - 2)
            val right = (cropRight.coerceIn(0.02f, 1f) * source.width).roundToInt().coerceIn(left + 1, source.width)
            val bottom = (cropBottom.coerceIn(0.02f, 1f) * source.height).roundToInt().coerceIn(top + 1, source.height)
            val cropped = Bitmap.createBitmap(source, left, top, right - left, bottom - top)
            try {
                val (outW, outH) = outputSize(cropped.width, cropped.height, targetWidth, targetHeight, keepAspect, doNotEnlarge)
                val outputBitmap = if (outW == cropped.width && outH == cropped.height) cropped else Bitmap.createScaledBitmap(cropped, outW, outH, true)
                try {
                    val itemDir = File(row.originalPath).parentFile?.parentFile ?: error("Повреждён локальный путь фото")
                    val processedDir = File(itemDir, "processed").apply { mkdirs() }
                    val outFile = File(processedDir, row.fileName)
                    FileOutputStream(outFile).use { stream ->
                        when (outFile.extension.lowercase()) {
                            "png" -> outputBitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
                            "webp" -> {
                                @Suppress("DEPRECATION")
                                val format = if (android.os.Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP
                                outputBitmap.compress(format, 95, stream)
                            }
                            else -> outputBitmap.compress(Bitmap.CompressFormat.JPEG, 95, stream)
                        }
                    }
                    val sha = sha256(outFile)
                    val now = System.currentTimeMillis()
                    val updated = row.copy(
                        processedPath = outFile.absolutePath,
                        remotePath = remotePath(row.remoteFolder, row.fileName),
                        cropLeft = cropLeft.coerceIn(0f, 1f), cropTop = cropTop.coerceIn(0f, 1f),
                        cropRight = cropRight.coerceIn(0f, 1f), cropBottom = cropBottom.coerceIn(0f, 1f),
                        rotationDegrees = normalizedRotation(rotationDegrees),
                        targetWidth = targetWidth.coerceAtLeast(0), targetHeight = targetHeight.coerceAtLeast(0),
                        keepAspect = keepAspect, doNotEnlarge = doNotEnlarge,
                        processedWidth = outW, processedHeight = outH,
                        sha256 = sha, status = "READY", error = "", updatedAt = now,
                    )
                    val withGallery = updateGalleryMarker(updated, outFile, "PROCESSED")
                    db.photos().put(withGallery)
                    refreshProductImageFields(row.productUuid)
                    withGallery
                } finally {
                    if (outputBitmap !== cropped) outputBitmap.recycle()
                }
            } finally {
                if (cropped !== source) cropped.recycle()
            }
        } finally {
            if (!source.isRecycled) source.recycle()
        }
    }

    suspend fun setProductFolder(productUuid: String, folder: String) {
        require(folder in TARGET_FOLDERS) { "Неизвестная папка фото" }
        db.withTransaction {
            val now = System.currentTimeMillis()
            val rows = db.photos().forProduct(productUuid)
            db.photos().putAll(rows.map { row ->
                val nextStatus = when {
                    row.processedPath.isBlank() -> "IMPORTED"
                    row.status == "ATTACHED" || row.status == "UPLOADED" -> "READY"
                    else -> row.status
                }
                row.copy(remoteFolder = folder, remotePath = remotePath(folder, row.fileName), status = nextStatus, error = "", updatedAt = now)
            })
        }
        refreshProductImageFields(productUuid)
    }

    suspend fun setMain(photoId: String) {
        val productUuid = db.withTransaction {
            val selected = db.photos().get(photoId) ?: return@withTransaction null
            val now = System.currentTimeMillis()
            db.photos().putAll(db.photos().forProduct(selected.productUuid).map { it.copy(isMain = it.id == photoId, updatedAt = now) })
            selected.productUuid
        } ?: return
        refreshProductImageFields(productUuid)
    }

    suspend fun delete(photoId: String) {
        val before = db.photos().get(photoId) ?: return
        removeGalleryMarker(before)
        val productUuid = db.withTransaction {
            val row = db.photos().get(photoId) ?: return@withTransaction null
            File(row.originalPath).parentFile?.parentFile?.deleteRecursively()
            db.photos().delete(photoId)
            val remaining = db.photos().forProduct(row.productUuid)
            if (row.isMain && remaining.isNotEmpty()) {
                val product = db.products().get(row.productUuid)
                val existingMain = product?.let { JsonTools.path(JsonTools.objectOf(it.localJson), "product.image")?.jsonPrimitive?.contentOrNull }.orEmpty()
                if (product?.productId == null || existingMain.isBlank() || existingMain == row.remotePath) {
                    val first = remaining.minBy { it.sortOrder }
                    db.photos().putAll(remaining.map { it.copy(isMain = it.id == first.id, updatedAt = System.currentTimeMillis()) })
                }
            }
            row.productUuid
        } ?: return

        val product = db.products().get(productUuid) ?: return
        val remaining = db.photos().forProduct(productUuid)
        if (product.productId == null) {
            if (remaining.isEmpty()) {
                productEditor.updateField(productUuid, "product.image", JsonPrimitive(""))
                productEditor.updateField(productUuid, "images", JsonArray(emptyList()))
            } else {
                refreshProductImageFields(productUuid)
            }
            return
        }

        // Existing server product: remove only this phone-managed path and preserve all other images.
        val payload = JsonTools.objectOf(product.localJson)
        val oldMain = JsonTools.path(payload, "product.image")?.jsonPrimitive?.contentOrNull.orEmpty()
        val surviving = (payload["images"] as? JsonArray).orEmpty().mapNotNull { element ->
            (element as? kotlinx.serialization.json.JsonObject)?.get("image")?.jsonPrimitive?.contentOrNull
        }.filter { it.isNotBlank() && it != before.remotePath }.distinct().toMutableList()
        var newMain = oldMain
        if (oldMain == before.remotePath) {
            newMain = surviving.firstOrNull().orEmpty()
        }
        if (newMain.isNotBlank()) {
            surviving.remove(newMain)
            surviving.add(0, newMain)
        }
        productEditor.updateField(productUuid, "product.image", JsonPrimitive(newMain))
        productEditor.updateField(productUuid, "images", JsonArray(surviving.mapIndexed { index, path ->
            buildJsonObject { put("image", JsonPrimitive(path)); put("sort_order", JsonPrimitive(index)) }
        }))
    }

    suspend fun uploadPending(allowedProductUuids: Set<String>): Int = withContext(Dispatchers.IO) {
        if (allowedProductUuids.isEmpty()) return@withContext 0
        var uploaded = 0
        for (row0 in db.photos().pendingUploads()) {
            if (row0.productUuid !in allowedProductUuids) continue
            val row = db.photos().get(row0.id) ?: continue
            if (row.processedPath.isBlank()) continue
            val file = File(row.processedPath)
            if (!file.isFile) {
                db.photos().put(row.copy(status = "ERROR", error = "Обработанный файл отсутствует", updatedAt = System.currentTimeMillis()))
                continue
            }
            db.photos().put(row.copy(status = "UPLOADING", error = "", updatedAt = System.currentTimeMillis()))
            try {
                val bytes = file.readBytes()
                val sha = sha256(bytes)
                val productBeforeUpload = db.products().get(row.productUuid)
                val mayReplaceExisting = productBeforeUpload?.productId != null && payloadReferencesPath(JsonTools.objectOf(productBeforeUpload.baseJson), row.remotePath)
                val result = bridge.post("image_upload", buildJsonObject {
                    put("file_id", JsonPrimitive(row.id))
                    put("folder", JsonPrimitive(row.remoteFolder))
                    put("filename", JsonPrimitive(row.fileName))
                    put("sha256", JsonPrimitive(sha))
                    put("replace", JsonPrimitive(mayReplaceExisting))
                    put("data_base64", JsonPrimitive(Base64.encodeToString(bytes, Base64.NO_WRAP)))
                })
                val returnedPath = result["path"]?.jsonPrimitive?.content.orEmpty()
                val expected = remotePath(row.remoteFolder, row.fileName)
                if (returnedPath != expected) error("Bridge вернул неожиданный путь: $returnedPath")
                val product = db.products().get(row.productUuid)
                val alreadyReferencedOnServer = product?.productId != null && payloadReferencesPath(JsonTools.objectOf(product.baseJson), returnedPath)
                db.photos().put(row.copy(
                    remotePath = returnedPath, sha256 = sha,
                    status = if (alreadyReferencedOnServer) "ATTACHED" else "UPLOADED",
                    error = "", updatedAt = System.currentTimeMillis()
                ))
                uploaded++
            } catch (e: Exception) {
                db.photos().put(row.copy(status = "ERROR", error = e.message ?: "Ошибка загрузки", updatedAt = System.currentTimeMillis()))
                throw e
            }
        }
        uploaded
    }

    suspend fun markProductAttached(productUuid: String) {
        db.photos().markUploadedAttached(productUuid, System.currentTimeMillis())
    }

    suspend fun refreshProductImageFields(productUuid: String) {
        val product = db.products().get(productUuid) ?: return
        val payload = JsonTools.objectOf(product.localJson)
        val currentMain = JsonTools.path(payload, "product.image")?.jsonPrimitive?.contentOrNull.orEmpty()
        val all = db.photos().forProduct(productUuid).sortedBy { it.sortOrder }
        val processed = all.filter { it.processedPath.isNotBlank() }
        if (processed.isEmpty()) return

        val declaredLocalMain = all.firstOrNull { it.isMain && it.processedPath.isNotBlank() }
        val mainPath = when {
            declaredLocalMain != null -> declaredLocalMain.remotePath
            product.productId != null && currentMain.isNotBlank() -> currentMain
            else -> processed.first().remotePath
        }

        val localPaths = all.map { it.remotePath }.filter { it.isNotBlank() }.toSet()
        val localExtras = processed
            .filter { it.remotePath != mainPath }
            .sortedBy { it.sortOrder }
            .map { it.remotePath }

        val extraPaths = if (product.productId == null) {
            localExtras
        } else {
            val existingRows = (payload["images"] as? JsonArray).orEmpty()
            val existingExtras = existingRows.mapNotNull { element ->
                (element as? kotlinx.serialization.json.JsonObject)?.get("image")?.jsonPrimitive?.contentOrNull
            }.filter { path ->
                path.isNotBlank() && path != currentMain && path != mainPath && path !in localPaths
            }
            buildList {
                if (mainPath != currentMain && currentMain.isNotBlank()) add(currentMain)
                addAll(existingExtras)
                addAll(localExtras)
            }.distinct()
        }

        productEditor.updateField(productUuid, "product.image", JsonPrimitive(mainPath))
        // Theme contract: the main photo is duplicated at additional image sort_order=0.
        val ordered = buildList {
            if (mainPath.isNotBlank()) add(mainPath)
            addAll(extraPaths.filter { it != mainPath })
        }
        productEditor.updateField(productUuid, "images", JsonArray(ordered.mapIndexed { index, path ->
            buildJsonObject { put("image", JsonPrimitive(path)); put("sort_order", JsonPrimitive(index)) }
        }))
    }

    /** Reorder only non-main phone-local photos. The main duplicate is always server position 0. */
    suspend fun moveAdditional(photoId: String, delta: Int) {
        if (delta == 0) return
        val selected = db.photos().get(photoId) ?: return
        if (selected.isMain) return
        val extras = db.photos().forProduct(selected.productUuid)
            .filter { !it.isMain }
            .sortedBy { it.sortOrder }
        val index = extras.indexOfFirst { it.id == photoId }
        if (index < 0) return
        val targetIndex = (index + delta).coerceIn(0, extras.lastIndex)
        if (targetIndex == index) return
        val other = extras[targetIndex]
        val now = System.currentTimeMillis()
        db.withTransaction {
            db.photos().put(selected.copy(sortOrder = other.sortOrder, updatedAt = now))
            db.photos().put(other.copy(sortOrder = selected.sortOrder, updatedAt = now))
        }
        refreshProductImageFields(selected.productUuid)
    }

    suspend fun ensureGalleryMarkers(productUuid: String) = withContext(Dispatchers.IO) {
        db.photos().forProduct(productUuid).forEach { row ->
            if (!row.galleryUri.isNullOrBlank() && row.galleryState in setOf("WORKING", "PROCESSED")) return@forEach
            val processed = row.processedPath.takeIf { it.isNotBlank() }?.let(::File)?.takeIf { it.isFile }
            val original = File(row.originalPath).takeIf { it.isFile }
            val source = processed ?: original ?: return@forEach
            val state = if (processed != null) "PROCESSED" else "WORKING"
            db.photos().put(updateGalleryMarker(row, source, state))
        }
    }

    suspend fun suggestedFolder(productUuid: String): String = suggestFolder(productUuid)

    private suspend fun suggestFolder(productUuid: String): String {
        val product = db.products().get(productUuid) ?: return "Fernbedienungen"
        val payload = JsonTools.objectOf(product.localJson)
        val categoryIds = (payload["categories"] as? JsonArray).orEmpty().mapNotNull { it.jsonPrimitive.intOrNull }.toSet()
        val categoryText = db.references().categories().filter { it.categoryId in categoryIds }.joinToString(" ") { it.name }
        val text = (product.name + " " + product.model + " " + categoryText).lowercase()
        return when {
            "kabel" in text || "cable" in text -> "Kabel"
            "fernbed" in text || "remote" in text -> "Fernbedienungen"
            "laptop" in text -> "Laptop"
            "monitor" in text -> "monitor"
            "hdd" in text || "festplatte" in text -> "HDD-Ersatzteile"
            "gps" in text || "konsole" in text -> "GPSundKonsole"
            "tablet" in text || " tab " in " $text " -> "Tab"
            "reader" in text -> "Freader"
            else -> "Fernbedienungen"
        }
    }


    /**
     * Creates an app-owned gallery copy used purely as a visual workflow marker.
     * Camera originals are never moved/deleted. App-owned marker can therefore
     * be moved between albums without storage permission prompts.
     */
    private fun updateGalleryMarker(row: LocalPhotoEntity, source: File, state: String): LocalPhotoEntity {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            return row.copy(galleryState = "UNSUPPORTED", galleryError = "Альбомы статуса поддерживаются с Android 10")
        }
        return runCatching {
            val resolver = context.contentResolver
            val relative = when (state) {
                "PROCESSED" -> "${Environment.DIRECTORY_PICTURES}/HandelDesk/Обработано/"
                else -> "${Environment.DIRECTORY_PICTURES}/HandelDesk/В работе/"
            }
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, row.fileName)
                put(MediaStore.Images.Media.MIME_TYPE, mimeType(row.fileName))
                put(MediaStore.Images.Media.RELATIVE_PATH, relative)
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = row.galleryUri?.let(Uri::parse)?.takeIf { existing ->
                runCatching { resolver.update(existing, values, null, null) > 0 }.getOrDefault(false)
            } ?: resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: error("Не удалось создать маркер в галерее")
            resolver.openOutputStream(uri, "w")?.use { out -> writeGalleryPreview(source, row.fileName, out) }
                ?: error("Не удалось записать маркер в галерее")
            resolver.update(uri, ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }, null, null)
            row.copy(galleryUri = uri.toString(), galleryState = state, galleryError = null)
        }.getOrElse { e ->
            row.copy(galleryState = "ERROR", galleryError = e.message ?: "Ошибка альбома галереи")
        }
    }

    fun removeGalleryMarker(row: LocalPhotoEntity) {
        val uri = row.galleryUri?.takeIf { it.isNotBlank() }?.let(Uri::parse) ?: return
        runCatching { context.contentResolver.delete(uri, null, null) }
    }

    fun removeGalleryMarkers(rows: List<LocalPhotoEntity>) {
        rows.forEach(::removeGalleryMarker)
    }

    private fun writeGalleryPreview(source: File, fileName: String, out: java.io.OutputStream) {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        if (ext !in setOf("jpg", "jpeg", "png", "webp")) {
            source.inputStream().use { it.copyTo(out) }
            return
        }
        val bitmap = decodeOriented(source, 1400, 0)
        try {
            when (ext) {
                "png" -> bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                "webp" -> {
                    @Suppress("DEPRECATION")
                    val format = if (Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP
                    bitmap.compress(format, 88, out)
                }
                else -> bitmap.compress(Bitmap.CompressFormat.JPEG, 88, out)
            }
        } finally {
            if (!bitmap.isRecycled) bitmap.recycle()
        }
    }

    private fun mimeType(fileName: String): String = when (fileName.substringAfterLast('.', "").lowercase()) {
        "png" -> "image/png"
        "webp" -> "image/webp"
        "heic", "heif" -> "image/heic"
        else -> "image/jpeg"
    }

    private fun payloadReferencesPath(payload: kotlinx.serialization.json.JsonObject, path: String): Boolean {
        val main = payload["product"]?.jsonObject?.get("image")?.jsonPrimitive?.contentOrNull.orEmpty()
        if (main == path) return true
        return (payload["images"] as? JsonArray).orEmpty().any { element ->
            (element as? kotlinx.serialization.json.JsonObject)?.get("image")?.jsonPrimitive?.contentOrNull == path
        }
    }

    private fun safeDisplayName(uri: Uri, fallbackId: String): String {
        var display: String? = null
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) display = c.getString(0)
        }
        val candidate = display?.trim().orEmpty().ifBlank { "IMG_${fallbackId.take(8)}.jpg" }
        require(!candidate.contains('/') && !candidate.contains('\\') && !candidate.contains('\u0000')) { "Недопустимое имя фото" }
        return candidate.take(180)
    }

    private fun remotePath(folder: String, fileName: String) = "catalog/product/$folder/$fileName"

    private fun orientedDimensions(file: File): Pair<Int, Int> {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, opts)
        var w = opts.outWidth.coerceAtLeast(1)
        var h = opts.outHeight.coerceAtLeast(1)
        val r = exifRotation(file)
        if (r == 90 || r == 270) { val t = w; w = h; h = t }
        return w to h
    }

    private fun decodeOriented(file: File, maxDimension: Int, userRotation: Int): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        var sample = 1
        if (maxDimension > 0) {
            while (max(bounds.outWidth, bounds.outHeight) / sample > maxDimension * 2) sample *= 2
        }
        val decoded = BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply {
            inSampleSize = sample.coerceAtLeast(1)
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }) ?: error("Не удалось прочитать изображение")
        val totalRotation = normalizedRotation(exifRotation(file) + userRotation)
        if (totalRotation == 0) return decoded
        val matrix = Matrix().apply { postRotate(totalRotation.toFloat()) }
        val rotated = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
        if (rotated !== decoded) decoded.recycle()
        return rotated
    }

    private fun exifRotation(file: File): Int = runCatching {
        when (ExifInterface(file).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
            ExifInterface.ORIENTATION_ROTATE_90, ExifInterface.ORIENTATION_TRANSPOSE -> 90
            ExifInterface.ORIENTATION_ROTATE_180, ExifInterface.ORIENTATION_FLIP_VERTICAL -> 180
            ExifInterface.ORIENTATION_ROTATE_270, ExifInterface.ORIENTATION_TRANSVERSE -> 270
            else -> 0
        }
    }.getOrDefault(0)

    private fun normalizedRotation(value: Int): Int = ((value % 360) + 360) % 360

    private fun outputSize(srcW: Int, srcH: Int, requestedW: Int, requestedH: Int, keepAspect: Boolean, doNotEnlarge: Boolean): Pair<Int, Int> {
        if (requestedW <= 0 && requestedH <= 0) return srcW to srcH
        if (!keepAspect) {
            var w = if (requestedW > 0) requestedW else srcW
            var h = if (requestedH > 0) requestedH else srcH
            if (doNotEnlarge) { w = min(w, srcW); h = min(h, srcH) }
            return w.coerceAtLeast(1) to h.coerceAtLeast(1)
        }
        val scaleByW = if (requestedW > 0) requestedW.toDouble() / srcW else Double.POSITIVE_INFINITY
        val scaleByH = if (requestedH > 0) requestedH.toDouble() / srcH else Double.POSITIVE_INFINITY
        var scale = min(scaleByW, scaleByH)
        if (!scale.isFinite()) scale = if (requestedW > 0) scaleByW else scaleByH
        if (doNotEnlarge) scale = min(1.0, scale)
        return max(1, (srcW * scale).roundToInt()) to max(1, (srcH * scale).roundToInt())
    }

    private fun sha256(file: File): String = file.inputStream().use { stream ->
        val digest = MessageDigest.getInstance("SHA-256")
        val buf = ByteArray(64 * 1024)
        while (true) {
            val n = stream.read(buf)
            if (n <= 0) break
            digest.update(buf, 0, n)
        }
        digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
}
