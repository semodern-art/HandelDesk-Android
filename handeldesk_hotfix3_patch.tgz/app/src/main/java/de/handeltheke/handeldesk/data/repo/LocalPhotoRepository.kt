package de.handeltheke.handeldesk.data.repo

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import androidx.exifinterface.media.ExifInterface
import androidx.room.withTransaction
import de.handeltheke.handeldesk.data.local.HandelDeskDatabase
import de.handeltheke.handeldesk.data.local.LocalPhotoEntity
import de.handeltheke.handeldesk.data.remote.BridgeClient
import de.handeltheke.handeldesk.domain.JsonTools
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.UUID
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class LocalPhotoRepository(
    private val context: Context,
    private val db: HandelDeskDatabase,
    private val bridge: BridgeClient,
    private val productEditor: ProductEditorRepository,
) {
    companion object {
        val TARGET_FOLDERS = listOf(
            "Fernbedienungen", "Kabel", "Freader", "Sonstiges", "GPSundKonsole",
            "Laptop", "HDD-Ersatzteile", "monitor", "Tab"
        )
        val FAST_FOLDERS = listOf("Fernbedienungen", "Kabel")
    }

    data class PreviewBitmap(val bitmap: Bitmap, val width: Int, val height: Int)

    suspend fun importUris(productUuid: String, uris: List<Uri>): List<String> = withContext(Dispatchers.IO) {
        if (uris.isEmpty()) return@withContext emptyList()
        val folder = suggestFolder(productUuid)
        val hadPhotos = db.photos().countForProduct(productUuid) > 0
        val created = mutableListOf<String>()
        uris.forEachIndexed { index, uri ->
            val id = UUID.randomUUID().toString()
            val name = safeDisplayName(uri, id)
            val itemDir = File(context.filesDir, "handeldesk_photos/$productUuid/$id")
            val originalDir = File(itemDir, "original").apply { mkdirs() }
            val original = File(originalDir, name)
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(original).use { output -> input.copyTo(output) }
            } ?: error("Не удалось открыть $name")
            val (w, h) = orientedDimensions(original)
            val now = System.currentTimeMillis()
            val sort = db.photos().nextSortOrder(productUuid)
            db.photos().put(
                LocalPhotoEntity(
                    id = id,
                    productUuid = productUuid,
                    fileName = name,
                    originalPath = original.absolutePath,
                    remoteFolder = folder,
                    remotePath = remotePath(folder, name),
                    isMain = !hadPhotos && index == 0,
                    sortOrder = sort,
                    sourceWidth = w,
                    sourceHeight = h,
                    createdAt = now,
                    updatedAt = now,
                )
            )
            created += id
        }
        created
    }

    suspend fun loadPreview(photoId: String, maxDimension: Int = 1800, rotationDegrees: Int? = null): PreviewBitmap = withContext(Dispatchers.IO) {
        val row = db.photos().get(photoId) ?: error("Фото не найдено")
        val file = File(row.originalPath)
        val oriented = decodeOriented(file, maxDimension, rotationDegrees ?: row.rotationDegrees)
        PreviewBitmap(oriented, oriented.width, oriented.height)
    }

    suspend fun process(
        photoId: String,
        cropLeft: Float,
        cropTop: Float,
        cropRight: Float,
        cropBottom: Float,
        rotationDegrees: Int,
        targetWidth: Int,
        targetHeight: Int,
        keepAspect: Boolean,
        doNotEnlarge: Boolean,
    ): LocalPhotoEntity = withContext(Dispatchers.IO) {
        val row = db.photos().get(photoId) ?: error("Фото не найдено")
        val source = decodeOriented(File(row.originalPath), 0, rotationDegrees)
        try {
            val left = (cropLeft.coerceIn(0f, 0.98f) * source.width).roundToInt().coerceIn(0, source.width - 2)
            val top = (cropTop.coerceIn(0f, 0.98f) * source.height).roundToInt().coerceIn(0, source.height - 2)
            val right = (cropRight.coerceIn(0.02f, 1f) * source.width).roundToInt().coerceIn(left + 1, source.width)
            val bottom = (cropBottom.coerceIn(0.02f, 1f) * source.height).roundToInt().coerceIn(top + 1, source.height)
            val cropped = Bitmap.createBitmap(source, left, top, right - left, bottom - top)
            try {
                val (outW, outH) = outputSize(cropped.width, cropped.height, targetWidth, targetHeight, keepAspect, doNotEnlarge)
                val outputBitmap = if (outW == cropped.width && outH == cropped.height) cropped else Bitmap.createScaledBitmap(cropped, outW, outH, true)
                try {
                    val itemDir = File(row.originalPath).parentFile?.parentFile ?: error("Повреждён локальный путь фото")
                    val processedDir = File(itemDir, "processed").apply { mkdirs() }
                    val outFile = File(processedDir, row.fileName)
                    FileOutputStream(outFile).use { stream ->
                        when (outFile.extension.lowercase()) {
                            "png" -> outputBitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
                            "webp" -> {
                                @Suppress("DEPRECATION")
                                val format = if (android.os.Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP
                                outputBitmap.compress(format, 95, stream)
                            }
                            else -> outputBitmap.compress(Bitmap.CompressFormat.JPEG, 95, stream)
                        }
                    }
                    val sha = sha256(outFile)
                    val now = System.currentTimeMillis()
                    val updated = row.copy(
                        processedPath = outFile.absolutePath,
                        remotePath = remotePath(row.remoteFolder, row.fileName),
                        cropLeft = cropLeft.coerceIn(0f, 1f), cropTop = cropTop.coerceIn(0f, 1f),
                        cropRight = cropRight.coerceIn(0f, 1f), cropBottom = cropBottom.coerceIn(0f, 1f),
                        rotationDegrees = normalizedRotation(rotationDegrees),
                        targetWidth = targetWidth.coerceAtLeast(0), targetHeight = targetHeight.coerceAtLeast(0),
                        keepAspect = keepAspect, doNotEnlarge = doNotEnlarge,
                        processedWidth = outW, processedHeight = outH,
                        sha256 = sha, status = "READY", error = "", updatedAt = now,
                    )
                    db.photos().put(updated)
                    refreshProductImageFields(row.productUuid)
                    updated
                } finally {
                    if (outputBitmap !== cropped) outputBitmap.recycle()
                }
            } finally {
                if (cropped !== source) cropped.recycle()
            }
        } finally {
            if (!source.isRecycled) source.recycle()
        }
    }

    suspend fun setProductFolder(productUuid: String, folder: String) {
        require(folder in TARGET_FOLDERS) { "Неизвестная папка фото" }
        db.withTransaction {
            val now = System.currentTimeMillis()
            val rows = db.photos().forProduct(productUuid)
            db.photos().putAll(rows.map { row ->
                val nextStatus = when {
                    row.processedPath.isBlank() -> "IMPORTED"
                    row.status == "ATTACHED" || row.status == "UPLOADED" -> "READY"
                    else -> row.status
                }
                row.copy(remoteFolder = folder, remotePath = remotePath(folder, row.fileName), status = nextStatus, error = "", updatedAt = now)
            })
        }
        refreshProductImageFields(productUuid)
    }

    suspend fun setMain(photoId: String) {
        val productUuid = db.withTransaction {
            val selected = db.photos().get(photoId) ?: return@withTransaction null
            val now = System.currentTimeMillis()
            db.photos().putAll(db.photos().forProduct(selected.productUuid).map { it.copy(isMain = it.id == photoId, updatedAt = now) })
            selected.productUuid
        } ?: return
        refreshProductImageFields(productUuid)
    }

    suspend fun delete(photoId: String) {
        val productUuid = db.withTransaction {
            val row = db.photos().get(photoId) ?: return@withTransaction null
            File(row.originalPath).parentFile?.parentFile?.deleteRecursively()
            db.photos().delete(photoId)
            val remaining = db.photos().forProduct(row.productUuid)
            if (row.isMain && remaining.isNotEmpty()) {
                val first = remaining.minBy { it.sortOrder }
                db.photos().putAll(remaining.map { it.copy(isMain = it.id == first.id, updatedAt = System.currentTimeMillis()) })
            }
            row.productUuid
        } ?: return
        if (db.photos().forProduct(productUuid).isEmpty()) {
            productEditor.updateField(productUuid, "product.image", JsonPrimitive(""))
            productEditor.updateField(productUuid, "images", JsonArray(emptyList()))
        } else {
            refreshProductImageFields(productUuid)
        }
    }

    suspend fun uploadPending(allowedProductUuids: Set<String>): Int = withContext(Dispatchers.IO) {
        if (allowedProductUuids.isEmpty()) return@withContext 0
        var uploaded = 0
        for (row0 in db.photos().pendingUploads()) {
            if (row0.productUuid !in allowedProductUuids) continue
            val row = db.photos().get(row0.id) ?: continue
            if (row.processedPath.isBlank()) continue
            val file = File(row.processedPath)
            if (!file.isFile) {
                db.photos().put(row.copy(status = "ERROR", error = "Обработанный файл отсутствует", updatedAt = System.currentTimeMillis()))
                continue
            }
            db.photos().put(row.copy(status = "UPLOADING", error = "", updatedAt = System.currentTimeMillis()))
            try {
                val bytes = file.readBytes()
                val sha = sha256(bytes)
                val productBeforeUpload = db.products().get(row.productUuid)
                val mayReplaceExisting = productBeforeUpload?.productId != null && payloadReferencesPath(JsonTools.objectOf(productBeforeUpload.baseJson), row.remotePath)
                val result = bridge.post("image_upload", buildJsonObject {
                    put("file_id", JsonPrimitive(row.id))
                    put("folder", JsonPrimitive(row.remoteFolder))
                    put("filename", JsonPrimitive(row.fileName))
                    put("sha256", JsonPrimitive(sha))
                    put("replace", JsonPrimitive(mayReplaceExisting))
                    put("data_base64", JsonPrimitive(Base64.encodeToString(bytes, Base64.NO_WRAP)))
                })
                val returnedPath = result["path"]?.jsonPrimitive?.content.orEmpty()
                val expected = remotePath(row.remoteFolder, row.fileName)
                if (returnedPath != expected) error("Bridge вернул неожиданный путь: $returnedPath")
                val product = db.products().get(row.productUuid)
                val alreadyReferencedOnServer = product?.productId != null && payloadReferencesPath(JsonTools.objectOf(product.baseJson), returnedPath)
                db.photos().put(row.copy(
                    remotePath = returnedPath, sha256 = sha,
                    status = if (alreadyReferencedOnServer) "ATTACHED" else "UPLOADED",
                    error = "", updatedAt = System.currentTimeMillis()
                ))
                uploaded++
            } catch (e: Exception) {
                db.photos().put(row.copy(status = "ERROR", error = e.message ?: "Ошибка загрузки", updatedAt = System.currentTimeMillis()))
                throw e
            }
        }
        uploaded
    }

    suspend fun markProductAttached(productUuid: String) {
        db.photos().markUploadedAttached(productUuid, System.currentTimeMillis())
    }

    suspend fun refreshProductImageFields(productUuid: String) {
        val all = db.photos().forProduct(productUuid).sortedBy { it.sortOrder }
        val processed = all.filter { it.processedPath.isNotBlank() }
        if (processed.isEmpty()) return
        val declaredMain = all.firstOrNull { it.isMain }
        val main = declaredMain?.takeIf { it.processedPath.isNotBlank() }
            ?: if (declaredMain == null) processed.firstOrNull() else null
        val extras = processed.filter { it.id != main?.id }.sortedBy { it.sortOrder }
        if (main != null) productEditor.updateField(productUuid, "product.image", JsonPrimitive(main.remotePath))
        productEditor.updateField(productUuid, "images", JsonArray(extras.mapIndexed { index, p ->
            buildJsonObject { put("image", JsonPrimitive(p.remotePath)); put("sort_order", JsonPrimitive(index)) }
        }))
    }

    suspend fun suggestedFolder(productUuid: String): String = suggestFolder(productUuid)

    private suspend fun suggestFolder(productUuid: String): String {
        val product = db.products().get(productUuid) ?: return "Fernbedienungen"
        val payload = JsonTools.objectOf(product.localJson)
        val categoryIds = (payload["categories"] as? JsonArray).orEmpty().mapNotNull { it.jsonPrimitive.intOrNull }.toSet()
        val categoryText = db.references().categories().filter { it.categoryId in categoryIds }.joinToString(" ") { it.name }
        val text = (product.name + " " + product.model + " " + categoryText).lowercase()
        return when {
            "kabel" in text || "cable" in text -> "Kabel"
            "fernbed" in text || "remote" in text -> "Fernbedienungen"
            "laptop" in text -> "Laptop"
            "monitor" in text -> "monitor"
            "hdd" in text || "festplatte" in text -> "HDD-Ersatzteile"
            "gps" in text || "konsole" in text -> "GPSundKonsole"
            "tablet" in text || " tab " in " $text " -> "Tab"
            "reader" in text -> "Freader"
            else -> "Fernbedienungen"
        }
    }


    private fun payloadReferencesPath(payload: kotlinx.serialization.json.JsonObject, path: String): Boolean {
        val main = payload["product"]?.jsonObject?.get("image")?.jsonPrimitive?.contentOrNull.orEmpty()
        if (main == path) return true
        return (payload["images"] as? JsonArray).orEmpty().any { element ->
            (element as? kotlinx.serialization.json.JsonObject)?.get("image")?.jsonPrimitive?.contentOrNull == path
        }
    }

    private fun safeDisplayName(uri: Uri, fallbackId: String): String {
        var display: String? = null
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) display = c.getString(0)
        }
        val candidate = display?.trim().orEmpty().ifBlank { "IMG_${fallbackId.take(8)}.jpg" }
        require(!candidate.contains('/') && !candidate.contains('\\') && !candidate.contains('\u0000')) { "Недопустимое имя фото" }
        return candidate.take(180)
    }

    private fun remotePath(folder: String, fileName: String) = "catalog/product/$folder/$fileName"

    private fun orientedDimensions(file: File): Pair<Int, Int> {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, opts)
        var w = opts.outWidth.coerceAtLeast(1)
        var h = opts.outHeight.coerceAtLeast(1)
        val r = exifRotation(file)
        if (r == 90 || r == 270) { val t = w; w = h; h = t }
        return w to h
    }

    private fun decodeOriented(file: File, maxDimension: Int, userRotation: Int): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        var sample = 1
        if (maxDimension > 0) {
            while (max(bounds.outWidth, bounds.outHeight) / sample > maxDimension * 2) sample *= 2
        }
        val decoded = BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply {
            inSampleSize = sample.coerceAtLeast(1)
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }) ?: error("Не удалось прочитать изображение")
        val totalRotation = normalizedRotation(exifRotation(file) + userRotation)
        if (totalRotation == 0) return decoded
        val matrix = Matrix().apply { postRotate(totalRotation.toFloat()) }
        val rotated = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
        if (rotated !== decoded) decoded.recycle()
        return rotated
    }

    private fun exifRotation(file: File): Int = runCatching {
        when (ExifInterface(file).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
            ExifInterface.ORIENTATION_ROTATE_90, ExifInterface.ORIENTATION_TRANSPOSE -> 90
            ExifInterface.ORIENTATION_ROTATE_180, ExifInterface.ORIENTATION_FLIP_VERTICAL -> 180
            ExifInterface.ORIENTATION_ROTATE_270, ExifInterface.ORIENTATION_TRANSVERSE -> 270
            else -> 0
        }
    }.getOrDefault(0)

    private fun normalizedRotation(value: Int): Int = ((value % 360) + 360) % 360

    private fun outputSize(srcW: Int, srcH: Int, requestedW: Int, requestedH: Int, keepAspect: Boolean, doNotEnlarge: Boolean): Pair<Int, Int> {
        if (requestedW <= 0 && requestedH <= 0) return srcW to srcH
        if (!keepAspect) {
            var w = if (requestedW > 0) requestedW else srcW
            var h = if (requestedH > 0) requestedH else srcH
            if (doNotEnlarge) { w = min(w, srcW); h = min(h, srcH) }
            return w.coerceAtLeast(1) to h.coerceAtLeast(1)
        }
        val scaleByW = if (requestedW > 0) requestedW.toDouble() / srcW else Double.POSITIVE_INFINITY
        val scaleByH = if (requestedH > 0) requestedH.toDouble() / srcH else Double.POSITIVE_INFINITY
        var scale = min(scaleByW, scaleByH)
        if (!scale.isFinite()) scale = if (requestedW > 0) scaleByW else scaleByH
        if (doNotEnlarge) scale = min(1.0, scale)
        return max(1, (srcW * scale).roundToInt()) to max(1, (srcH * scale).roundToInt())
    }

    private fun sha256(file: File): String = file.inputStream().use { stream ->
        val digest = MessageDigest.getInstance("SHA-256")
        val buf = ByteArray(64 * 1024)
        while (true) {
            val n = stream.read(buf)
            if (n <= 0) break
            digest.update(buf, 0, n)
        }
        digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
}
