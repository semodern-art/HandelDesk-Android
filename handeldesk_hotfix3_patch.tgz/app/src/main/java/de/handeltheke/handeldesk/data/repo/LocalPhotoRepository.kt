package de.handeltheke.handeldesk.data.repo

import android.content.ContentValues
import android.content.Intent
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.os.Build
import android.os.Environment
import android.net.Uri
import android.provider.MediaStore
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.util.Base64
import androidx.exifinterface.media.ExifInterface
import androidx.documentfile.provider.DocumentFile
import androidx.room.withTransaction
import de.handeltheke.handeldesk.data.local.HandelDeskDatabase
import de.handeltheke.handeldesk.data.local.LocalPhotoEntity
import de.handeltheke.handeldesk.data.local.SettingEntity
import de.handeltheke.handeldesk.data.remote.BridgeClient
import de.handeltheke.handeldesk.domain.JsonTools
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.UUID
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class LocalPhotoRepository(
    private val context: Context,
    private val db: HandelDeskDatabase,
    private val bridge: BridgeClient,
    private val productEditor: ProductEditorRepository,
) {
    companion object {
        val TARGET_FOLDERS = listOf(
            "Fernbedienungen", "Kabel", "Freader", "Sonstiges", "GPSundKonsole",
            "Laptop", "HDD-Ersatzteile", "monitor", "Tab"
        )
        val FAST_FOLDERS = listOf("Fernbedienungen", "Kabel")
        const val WORKSPACE_SETTING = "photo_workspace_tree_uri"
        const val STAGE_INBOX = "INBOX"
        const val STAGE_PROCESSED = "PROCESSED"
        const val STAGE_UPLOADED = "UPLOADED"
        const val STAGE_EXTERNAL = "EXTERNAL"
        const val DIR_INBOX = "01_Eingang"
        const val DIR_PROCESSED = "02_Bearbeitet"
        const val DIR_UPLOADED = "03_Hochgeladen"
    }

    data class PreviewBitmap(val bitmap: Bitmap, val width: Int, val height: Int)
    data class WorkspacePhoto(val uri: String, val name: String, val size: Long, val modifiedAt: Long)
    data class WorkspaceStatus(
        val configured: Boolean,
        val rootName: String = "",
        val inboxCount: Int = 0,
        val processedCount: Int = 0,
        val uploadedCount: Int = 0,
        val error: String? = null,
    )

    suspend fun importUris(productUuid: String, uris: List<Uri>): List<String> =
        importInternal(productUuid, uris, STAGE_EXTERNAL)

    suspend fun importWorkspaceUris(productUuid: String, uris: List<Uri>): List<String> =
        importInternal(productUuid, uris, STAGE_INBOX)

    private suspend fun importInternal(productUuid: String, uris: List<Uri>, sourceStage: String): List<String> = withContext(Dispatchers.IO) {
        if (uris.isEmpty()) return@withContext emptyList()
        val usedSourceUris = if (sourceStage == STAGE_INBOX) db.photos().usedSourceUris().toSet() else emptySet()
        val uniqueUris = uris.distinctBy { it.toString() }.filterNot { it.toString() in usedSourceUris }
        if (uniqueUris.isEmpty()) return@withContext emptyList()
        val folder = suggestFolder(productUuid)
        val product = db.products().get(productUuid)
        val currentMain = product?.let { JsonTools.path(JsonTools.objectOf(it.localJson), "product.image")?.jsonPrimitive?.contentOrNull }.orEmpty()
        val hadMain = db.photos().forProduct(productUuid).any { it.isMain } || currentMain.isNotBlank()
        val created = mutableListOf<String>()
        uniqueUris.forEachIndexed { index, uri ->
            val id = UUID.randomUUID().toString()
            val name = safeDisplayName(uri, id)
            val itemDir = File(context.filesDir, "handeldesk_photos/$productUuid/$id")
            val originalDir = File(itemDir, "original").apply { mkdirs() }
            val original = File(originalDir, name)
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(original).use { output -> input.copyTo(output) }
            } ?: error("Не удалось открыть $name")
            val (w, h) = orientedDimensions(original)
            val now = System.currentTimeMillis()
            val sort = db.photos().nextSortOrder(productUuid)
            val row = LocalPhotoEntity(
                id = id,
                productUuid = productUuid,
                fileName = name,
                originalPath = original.absolutePath,
                remoteFolder = folder,
                remotePath = remotePath(folder, name),
                isMain = !hadMain && index == 0,
                sortOrder = sort,
                sourceWidth = w,
                sourceHeight = h,
                sourceUri = if (sourceStage == STAGE_INBOX) uri.toString() else null,
                sourceStage = sourceStage,
                sourceError = null,
                createdAt = now,
                updatedAt = now,
            )
            db.photos().put(row)
            created += id
        }
        created
    }

    suspend fun loadPreview(photoId: String, maxDimension: Int = 1800, rotationDegrees: Int? = null): PreviewBitmap = withContext(Dispatchers.IO) {
        val row = db.photos().get(photoId) ?: error("Фото не найдено")
        val file = File(row.originalPath)
        val oriented = decodeOriented(file, maxDimension, rotationDegrees ?: row.rotationDegrees)
        PreviewBitmap(oriented, oriented.width, oriented.height)
    }

    suspend fun process(
        photoId: String,
        cropLeft: Float,
        cropTop: Float,
        cropRight: Float,
        cropBottom: Float,
        rotationDegrees: Int,
        targetWidth: Int,
        targetHeight: Int,
        keepAspect: Boolean,
        doNotEnlarge: Boolean,
    ): LocalPhotoEntity = withContext(Dispatchers.IO) {
        val row = db.photos().get(photoId) ?: error("Фото не найдено")
        val source = decodeOriented(File(row.originalPath), 0, rotationDegrees)
        try {
            val left = (cropLeft.coerceIn(0f, 0.98f) * source.width).roundToInt().coerceIn(0, source.width - 2)
            val top = (cropTop.coerceIn(0f, 0.98f) * source.height).roundToInt().coerceIn(0, source.height - 2)
            val right = (cropRight.coerceIn(0.02f, 1f) * source.width).roundToInt().coerceIn(left + 1, source.width)
            val bottom = (cropBottom.coerceIn(0.02f, 1f) * source.height).roundToInt().coerceIn(top + 1, source.height)
            val cropped = Bitmap.createBitmap(source, left, top, right - left, bottom - top)
            try {
                val (outW, outH) = outputSize(cropped.width, cropped.height, targetWidth, targetHeight, keepAspect, doNotEnlarge)
                val outputBitmap = if (outW == cropped.width && outH == cropped.height) cropped else Bitmap.createScaledBitmap(cropped, outW, outH, true)
                try {
                    val itemDir = File(row.originalPath).parentFile?.parentFile ?: error("Повреждён локальный путь фото")
                    val processedDir = File(itemDir, "processed").apply { mkdirs() }
                    val outFile = File(processedDir, row.fileName)
                    FileOutputStream(outFile).use { stream ->
                        when (outFile.extension.lowercase()) {
                            "png" -> outputBitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
                            "webp" -> {
                                @Suppress("DEPRECATION")
                                val format = if (android.os.Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP
                                outputBitmap.compress(format, 95, stream)
                            }
                            else -> outputBitmap.compress(Bitmap.CompressFormat.JPEG, 95, stream)
                        }
                    }
                    val sha = sha256(outFile)
                    val now = System.currentTimeMillis()
                    val updated = row.copy(
                        processedPath = outFile.absolutePath,
                        remotePath = remotePath(row.remoteFolder, row.fileName),
                        cropLeft = cropLeft.coerceIn(0f, 1f), cropTop = cropTop.coerceIn(0f, 1f),
                        cropRight = cropRight.coerceIn(0f, 1f), cropBottom = cropBottom.coerceIn(0f, 1f),
                        rotationDegrees = normalizedRotation(rotationDegrees),
                        targetWidth = targetWidth.coerceAtLeast(0), targetHeight = targetHeight.coerceAtLeast(0),
                        keepAspect = keepAspect, doNotEnlarge = doNotEnlarge,
                        processedWidth = outW, processedHeight = outH,
                        sha256 = sha, status = "READY", error = "", updatedAt = now,
                    )
                    val moved = if (updated.sourceStage == STAGE_INBOX) {
                        moveWorkspaceOriginal(updated, STAGE_PROCESSED)
                    } else updated
                    db.photos().put(moved)
                    refreshProductImageFields(row.productUuid)
                    moved
                } finally {
                    if (outputBitmap !== cropped) outputBitmap.recycle()
                }
            } finally {
                if (cropped !== source) cropped.recycle()
            }
        } finally {
            if (!source.isRecycled) source.recycle()
        }
    }

    suspend fun setProductFolder(productUuid: String, folder: String) {
        require(folder in TARGET_FOLDERS) { "Неизвестная папка фото" }
        db.withTransaction {
            val now = System.currentTimeMillis()
            val rows = db.photos().forProduct(productUuid)
            db.photos().putAll(rows.map { row ->
                val nextStatus = when {
                    row.processedPath.isBlank() -> "IMPORTED"
                    row.status == "ATTACHED" || row.status == "UPLOADED" -> "READY"
                    else -> row.status
                }
                row.copy(remoteFolder = folder, remotePath = remotePath(folder, row.fileName), status = nextStatus, error = "", updatedAt = now)
            })
        }
        refreshProductImageFields(productUuid)
    }

    suspend fun setMain(photoId: String) {
        val productUuid = db.withTransaction {
            val selected = db.photos().get(photoId) ?: return@withTransaction null
            val now = System.currentTimeMillis()
            db.photos().putAll(db.photos().forProduct(selected.productUuid).map { it.copy(isMain = it.id == photoId, updatedAt = now) })
            selected.productUuid
        } ?: return
        refreshProductImageFields(productUuid)
    }

    suspend fun delete(photoId: String) {
        var before = db.photos().get(photoId) ?: return
        removeGalleryMarker(before) // legacy 0.2.2 marker only
        if (before.status !in setOf("ATTACHED", "UPLOADED") && before.sourceStage == STAGE_PROCESSED) {
            before = moveWorkspaceOriginal(before, STAGE_INBOX)
            db.photos().put(before)
        }
        val productUuid = db.withTransaction {
            val row = db.photos().get(photoId) ?: return@withTransaction null
            File(row.originalPath).parentFile?.parentFile?.deleteRecursively()
            db.photos().delete(photoId)
            val remaining = db.photos().forProduct(row.productUuid)
            if (row.isMain && remaining.isNotEmpty()) {
                val product = db.products().get(row.productUuid)
                val existingMain = product?.let { JsonTools.path(JsonTools.objectOf(it.localJson), "product.image")?.jsonPrimitive?.contentOrNull }.orEmpty()
                if (product?.productId == null || existingMain.isBlank() || existingMain == row.remotePath) {
                    val first = remaining.minBy { it.sortOrder }
                    db.photos().putAll(remaining.map { it.copy(isMain = it.id == first.id, updatedAt = System.currentTimeMillis()) })
                }
            }
            row.productUuid
        } ?: return

        val product = db.products().get(productUuid) ?: return
        val remaining = db.photos().forProduct(productUuid)
        if (product.productId == null) {
            if (remaining.isEmpty()) {
                productEditor.updateField(productUuid, "product.image", JsonPrimitive(""))
                productEditor.updateField(productUuid, "images", JsonArray(emptyList()))
            } else {
                refreshProductImageFields(productUuid)
            }
            return
        }

        // Existing server product: remove only this phone-managed path and preserve all other images.
        val payload = JsonTools.objectOf(product.localJson)
        val oldMain = JsonTools.path(payload, "product.image")?.jsonPrimitive?.contentOrNull.orEmpty()
        val surviving = (payload["images"] as? JsonArray).orEmpty().mapNotNull { element ->
            (element as? kotlinx.serialization.json.JsonObject)?.get("image")?.jsonPrimitive?.contentOrNull
        }.filter { it.isNotBlank() && it != before.remotePath }.distinct().toMutableList()
        var newMain = oldMain
        if (oldMain == before.remotePath) {
            newMain = surviving.firstOrNull().orEmpty()
        }
        if (newMain.isNotBlank()) {
            surviving.remove(newMain)
            surviving.add(0, newMain)
        }
        productEditor.updateField(productUuid, "product.image", JsonPrimitive(newMain))
        productEditor.updateField(productUuid, "images", JsonArray(surviving.mapIndexed { index, path ->
            buildJsonObject { put("image", JsonPrimitive(path)); put("sort_order", JsonPrimitive(index)) }
        }))
    }

    suspend fun uploadPending(allowedProductUuids: Set<String>): Int = withContext(Dispatchers.IO) {
        if (allowedProductUuids.isEmpty()) return@withContext 0
        var uploaded = 0
        for (row0 in db.photos().pendingUploads()) {
            if (row0.productUuid !in allowedProductUuids) continue
            val row = db.photos().get(row0.id) ?: continue
            if (row.processedPath.isBlank()) continue
            if (!row.sourceUri.isNullOrBlank() && row.sourceStage == STAGE_INBOX) {
                db.photos().put(row.copy(
                    status = "ERROR",
                    error = row.sourceError ?: "Оригинал ещё находится в 01_Eingang; сначала завершите обработку/перемещение",
                    updatedAt = System.currentTimeMillis(),
                ))
                continue
            }
            val file = File(row.processedPath)
            if (!file.isFile) {
                db.photos().put(row.copy(status = "ERROR", error = "Обработанный файл отсутствует", updatedAt = System.currentTimeMillis()))
                continue
            }
            db.photos().put(row.copy(status = "UPLOADING", error = "", updatedAt = System.currentTimeMillis()))
            try {
                val bytes = file.readBytes()
                val sha = sha256(bytes)
                val productBeforeUpload = db.products().get(row.productUuid)
                val mayReplaceExisting = productBeforeUpload?.productId != null && payloadReferencesPath(JsonTools.objectOf(productBeforeUpload.baseJson), row.remotePath)
                val result = bridge.post("image_upload", buildJsonObject {
                    put("file_id", JsonPrimitive(row.id))
                    put("folder", JsonPrimitive(row.remoteFolder))
                    put("filename", JsonPrimitive(row.fileName))
                    put("sha256", JsonPrimitive(sha))
                    put("replace", JsonPrimitive(mayReplaceExisting))
                    put("data_base64", JsonPrimitive(Base64.encodeToString(bytes, Base64.NO_WRAP)))
                })
                val returnedPath = result["path"]?.jsonPrimitive?.content.orEmpty()
                val expected = remotePath(row.remoteFolder, row.fileName)
                if (returnedPath != expected) error("Bridge вернул неожиданный путь: $returnedPath")
                val product = db.products().get(row.productUuid)
                val alreadyReferencedOnServer = product?.productId != null && payloadReferencesPath(JsonTools.objectOf(product.baseJson), returnedPath)
                db.photos().put(row.copy(
                    remotePath = returnedPath, sha256 = sha,
                    status = if (alreadyReferencedOnServer) "ATTACHED" else "UPLOADED",
                    error = "", updatedAt = System.currentTimeMillis()
                ))
                uploaded++
            } catch (e: Exception) {
                db.photos().put(row.copy(status = "ERROR", error = e.message ?: "Ошибка загрузки", updatedAt = System.currentTimeMillis()))
                throw e
            }
        }
        uploaded
    }

    suspend fun markProductAttached(productUuid: String) = withContext(Dispatchers.IO) {
        db.photos().markUploadedAttached(productUuid, System.currentTimeMillis())
        db.photos().forProduct(productUuid).forEach { row ->
            if (row.status == "ATTACHED" && row.sourceStage == STAGE_PROCESSED) {
                val moved = moveWorkspaceOriginal(row, STAGE_UPLOADED)
                db.photos().put(moved)
            }
        }
    }

    suspend fun refreshProductImageFields(productUuid: String) {
        val product = db.products().get(productUuid) ?: return
        val payload = JsonTools.objectOf(product.localJson)
        val currentMain = JsonTools.path(payload, "product.image")?.jsonPrimitive?.contentOrNull.orEmpty()
        val all = db.photos().forProduct(productUuid).sortedBy { it.sortOrder }
        val processed = all.filter { it.processedPath.isNotBlank() }
        if (processed.isEmpty()) return

        val declaredLocalMain = all.firstOrNull { it.isMain && it.processedPath.isNotBlank() }
        val mainPath = when {
            declaredLocalMain != null -> declaredLocalMain.remotePath
            product.productId != null && currentMain.isNotBlank() -> currentMain
            else -> processed.first().remotePath
        }

        val localPaths = all.map { it.remotePath }.filter { it.isNotBlank() }.toSet()
        val localExtras = processed
            .filter { it.remotePath != mainPath }
            .sortedBy { it.sortOrder }
            .map { it.remotePath }

        val extraPaths = if (product.productId == null) {
            localExtras
        } else {
            val existingRows = (payload["images"] as? JsonArray).orEmpty()
            val existingExtras = existingRows.mapNotNull { element ->
                (element as? kotlinx.serialization.json.JsonObject)?.get("image")?.jsonPrimitive?.contentOrNull
            }.filter { path ->
                path.isNotBlank() && path != currentMain && path != mainPath && path !in localPaths
            }
            buildList {
                if (mainPath != currentMain && currentMain.isNotBlank()) add(currentMain)
                addAll(existingExtras)
                addAll(localExtras)
            }.distinct()
        }

        productEditor.updateField(productUuid, "product.image", JsonPrimitive(mainPath))
        // Theme contract: the main photo is duplicated at additional image sort_order=0.
        val ordered = buildList {
            if (mainPath.isNotBlank()) add(mainPath)
            addAll(extraPaths.filter { it != mainPath })
        }
        productEditor.updateField(productUuid, "images", JsonArray(ordered.mapIndexed { index, path ->
            buildJsonObject { put("image", JsonPrimitive(path)); put("sort_order", JsonPrimitive(index)) }
        }))
    }

    /** Reorder only non-main phone-local photos. The main duplicate is always server position 0. */
    suspend fun moveAdditional(photoId: String, delta: Int) {
        if (delta == 0) return
        val selected = db.photos().get(photoId) ?: return
        if (selected.isMain) return
        val extras = db.photos().forProduct(selected.productUuid)
            .filter { !it.isMain }
            .sortedBy { it.sortOrder }
        val index = extras.indexOfFirst { it.id == photoId }
        if (index < 0) return
        val targetIndex = (index + delta).coerceIn(0, extras.lastIndex)
        if (targetIndex == index) return
        val other = extras[targetIndex]
        val now = System.currentTimeMillis()
        db.withTransaction {
            db.photos().put(selected.copy(sortOrder = other.sortOrder, updatedAt = now))
            db.photos().put(other.copy(sortOrder = selected.sortOrder, updatedAt = now))
        }
        refreshProductImageFields(selected.productUuid)
    }

    suspend fun cleanupLegacyGalleryMarkers(productUuid: String) = withContext(Dispatchers.IO) {
        db.photos().forProduct(productUuid).forEach { row ->
            if (!row.galleryUri.isNullOrBlank()) {
                removeGalleryMarker(row)
                db.photos().put(row.copy(galleryUri = null, galleryState = null, galleryError = null))
            }
        }
    }

    suspend fun reconcileWorkspaceStages(productUuid: String) = withContext(Dispatchers.IO) {
        db.photos().forProduct(productUuid).forEach { row ->
            if (row.status == "ATTACHED" && row.sourceStage == STAGE_PROCESSED) {
                db.photos().put(moveWorkspaceOriginal(row, STAGE_UPLOADED))
            }
        }
    }

    suspend fun configureWorkspace(treeUri: Uri) = withContext(Dispatchers.IO) {
        val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        runCatching { context.contentResolver.takePersistableUriPermission(treeUri, flags) }
        val root = DocumentFile.fromTreeUri(context, treeUri) ?: error("Не удалось открыть выбранную папку")
        require(root.canRead() && root.canWrite()) { "Нужен доступ на чтение и запись выбранной папки" }
        ensureStageFolders(root)
        db.settings().put(SettingEntity(WORKSPACE_SETTING, treeUri.toString()))
    }

    suspend fun workspaceStatus(): WorkspaceStatus = withContext(Dispatchers.IO) {
        val root = workspaceRoot() ?: return@withContext WorkspaceStatus(configured = false)
        runCatching {
            val inbox = stageFolder(root, STAGE_INBOX, create = true)!!
            val processed = stageFolder(root, STAGE_PROCESSED, create = true)!!
            val uploaded = stageFolder(root, STAGE_UPLOADED, create = true)!!
            WorkspaceStatus(
                configured = true,
                rootName = root.name.orEmpty().ifBlank { "HandelDesk" },
                inboxCount = imageFiles(inbox).size,
                processedCount = imageFiles(processed).size,
                uploadedCount = imageFiles(uploaded).size,
            )
        }.getOrElse { WorkspaceStatus(configured = true, rootName = root.name.orEmpty(), error = it.message) }
    }

    suspend fun listInbox(): List<WorkspacePhoto> = withContext(Dispatchers.IO) {
        val root = workspaceRoot() ?: return@withContext emptyList()
        val folder = stageFolder(root, STAGE_INBOX, create = true) ?: return@withContext emptyList()
        val used = db.photos().usedSourceUris().toSet()
        imageFiles(folder).filterNot { it.uri.toString() in used }.map { file ->
            WorkspacePhoto(
                uri = file.uri.toString(),
                name = file.name.orEmpty(),
                size = file.length(),
                modifiedAt = file.lastModified(),
            )
        }.sortedWith(compareByDescending<WorkspacePhoto> { it.modifiedAt }.thenBy { it.name.lowercase() })
    }

    suspend fun returnOriginalsToInbox(rows: List<LocalPhotoEntity>) = withContext(Dispatchers.IO) {
        rows.forEach { row ->
            if (row.sourceStage == STAGE_PROCESSED) {
                val moved = moveWorkspaceOriginal(row, STAGE_INBOX)
                db.photos().put(moved)
            }
        }
    }

    suspend fun suggestedFolder(productUuid: String): String = suggestFolder(productUuid)

    private suspend fun suggestFolder(productUuid: String): String {
        val product = db.products().get(productUuid) ?: return "Fernbedienungen"
        val payload = JsonTools.objectOf(product.localJson)
        val categoryIds = (payload["categories"] as? JsonArray).orEmpty().mapNotNull { it.jsonPrimitive.intOrNull }.toSet()
        val categoryText = db.references().categories().filter { it.categoryId in categoryIds }.joinToString(" ") { it.name }
        val text = (product.name + " " + product.model + " " + categoryText).lowercase()
        return when {
            "kabel" in text || "cable" in text -> "Kabel"
            "fernbed" in text || "remote" in text -> "Fernbedienungen"
            "laptop" in text -> "Laptop"
            "monitor" in text -> "monitor"
            "hdd" in text || "festplatte" in text -> "HDD-Ersatzteile"
            "gps" in text || "konsole" in text -> "GPSundKonsole"
            "tablet" in text || " tab " in " $text " -> "Tab"
            "reader" in text -> "Freader"
            else -> "Fernbedienungen"
        }
    }


    private suspend fun workspaceRoot(): DocumentFile? {
        val raw = db.settings().get(WORKSPACE_SETTING)?.takeIf { it.isNotBlank() } ?: return null
        return DocumentFile.fromTreeUri(context, Uri.parse(raw))?.takeIf { it.exists() && it.isDirectory }
    }

    private fun ensureStageFolders(root: DocumentFile) {
        listOf(DIR_INBOX, DIR_PROCESSED, DIR_UPLOADED).forEach { name ->
            val existing = root.findFile(name)
            if (existing == null) root.createDirectory(name) ?: error("Не удалось создать папку $name")
            else require(existing.isDirectory) { "$name уже существует, но это не папка" }
        }
    }

    private fun stageFolder(root: DocumentFile, stage: String?, create: Boolean): DocumentFile? {
        val name = when (stage) {
            STAGE_INBOX -> DIR_INBOX
            STAGE_PROCESSED -> DIR_PROCESSED
            STAGE_UPLOADED -> DIR_UPLOADED
            else -> return null
        }
        val found = root.findFile(name)
        if (found != null) return found.takeIf { it.isDirectory }
        return if (create) root.createDirectory(name) else null
    }

    private fun imageFiles(folder: DocumentFile): List<DocumentFile> = folder.listFiles().filter {
        it.isFile && isImageName(it.name.orEmpty())
    }

    private fun isImageName(name: String): Boolean = name.substringAfterLast('.', "").lowercase() in
        setOf("jpg", "jpeg", "png", "webp", "heic", "heif")

    private suspend fun moveWorkspaceOriginal(row: LocalPhotoEntity, targetStage: String): LocalPhotoEntity {
        if (row.sourceStage == STAGE_EXTERNAL || row.sourceUri.isNullOrBlank() || row.sourceStage == targetStage) {
            return row.copy(sourceError = null)
        }
        return runCatching {
            val root = workspaceRoot() ?: error("Рабочая папка HandelDesk не настроена")
            ensureStageFolders(root)
            val from = stageFolder(root, row.sourceStage, create = false) ?: error("Исходная статусная папка не найдена")
            val to = stageFolder(root, targetStage, create = true) ?: error("Целевая статусная папка не найдена")
            val expectedUri = Uri.parse(row.sourceUri)
            val source = from.listFiles().firstOrNull { it.uri == expectedUri }
                ?: from.findFile(row.fileName)
                ?: error("Оригинал ${row.fileName} не найден в ${from.name}")
            val collision = to.findFile(row.fileName)
            require(collision == null) { "В ${to.name} уже есть файл ${row.fileName}" }

            val resolver = context.contentResolver
            val movedUri = runCatching {
                DocumentsContract.moveDocument(resolver, source.uri, from.uri, to.uri)
            }.getOrNull() ?: run {
                val created = to.createFile(mimeType(row.fileName), row.fileName)
                    ?: error("Не удалось создать ${row.fileName} в ${to.name}")
                try {
                    resolver.openInputStream(source.uri)?.use { input ->
                        resolver.openOutputStream(created.uri, "w")?.use { output -> input.copyTo(output) }
                            ?: error("Не удалось записать оригинал")
                    } ?: error("Не удалось прочитать оригинал")
                    val srcLen = source.length()
                    val dstLen = created.length()
                    if (srcLen > 0 && dstLen > 0) require(srcLen == dstLen) { "Размер файла после перемещения не совпал" }
                    require(source.delete()) { "Копия создана, но исходный файл не удалось удалить" }
                    created.uri
                } catch (t: Throwable) {
                    runCatching { created.delete() }
                    throw t
                }
            }
            row.copy(sourceUri = movedUri.toString(), sourceStage = targetStage, sourceError = null, updatedAt = System.currentTimeMillis())
        }.getOrElse { e ->
            row.copy(sourceError = e.message ?: "Не удалось переместить оригинал", updatedAt = System.currentTimeMillis())
        }
    }

    /** Legacy marker cleanup from v0.2.2. */
    fun removeGalleryMarker(row: LocalPhotoEntity) {
        val uri = row.galleryUri?.takeIf { it.isNotBlank() }?.let(Uri::parse) ?: return
        runCatching { context.contentResolver.delete(uri, null, null) }
    }

    fun removeGalleryMarkers(rows: List<LocalPhotoEntity>) { rows.forEach(::removeGalleryMarker) }

    private fun mimeType(fileName: String): String = when (fileName.substringAfterLast('.', "").lowercase()) {
        "png" -> "image/png"
        "webp" -> "image/webp"
        "heic", "heif" -> "image/heic"
        else -> "image/jpeg"
    }

    private fun payloadReferencesPath(payload: kotlinx.serialization.json.JsonObject, path: String): Boolean {
        val main = payload["product"]?.jsonObject?.get("image")?.jsonPrimitive?.contentOrNull.orEmpty()
        if (main == path) return true
        return (payload["images"] as? JsonArray).orEmpty().any { element ->
            (element as? kotlinx.serialization.json.JsonObject)?.get("image")?.jsonPrimitive?.contentOrNull == path
        }
    }

    private fun safeDisplayName(uri: Uri, fallbackId: String): String {
        var display: String? = null
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) display = c.getString(0)
        }
        val candidate = display?.trim().orEmpty().ifBlank { "IMG_${fallbackId.take(8)}.jpg" }
        require(!candidate.contains('/') && !candidate.contains('\\') && !candidate.contains('\u0000')) { "Недопустимое имя фото" }
        return candidate.take(180)
    }

    private fun remotePath(folder: String, fileName: String) = "catalog/product/$folder/$fileName"

    private fun orientedDimensions(file: File): Pair<Int, Int> {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, opts)
        var w = opts.outWidth.coerceAtLeast(1)
        var h = opts.outHeight.coerceAtLeast(1)
        val r = exifRotation(file)
        if (r == 90 || r == 270) { val t = w; w = h; h = t }
        return w to h
    }

    private fun decodeOriented(file: File, maxDimension: Int, userRotation: Int): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        var sample = 1
        if (maxDimension > 0) {
            while (max(bounds.outWidth, bounds.outHeight) / sample > maxDimension * 2) sample *= 2
        }
        val decoded = BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply {
            inSampleSize = sample.coerceAtLeast(1)
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }) ?: error("Не удалось прочитать изображение")
        val totalRotation = normalizedRotation(exifRotation(file) + userRotation)
        if (totalRotation == 0) return decoded
        val matrix = Matrix().apply { postRotate(totalRotation.toFloat()) }
        val rotated = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
        if (rotated !== decoded) decoded.recycle()
        return rotated
    }

    private fun exifRotation(file: File): Int = runCatching {
        when (ExifInterface(file).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
            ExifInterface.ORIENTATION_ROTATE_90, ExifInterface.ORIENTATION_TRANSPOSE -> 90
            ExifInterface.ORIENTATION_ROTATE_180, ExifInterface.ORIENTATION_FLIP_VERTICAL -> 180
            ExifInterface.ORIENTATION_ROTATE_270, ExifInterface.ORIENTATION_TRANSVERSE -> 270
            else -> 0
        }
    }.getOrDefault(0)

    private fun normalizedRotation(value: Int): Int = ((value % 360) + 360) % 360

    private fun outputSize(srcW: Int, srcH: Int, requestedW: Int, requestedH: Int, keepAspect: Boolean, doNotEnlarge: Boolean): Pair<Int, Int> {
        if (requestedW <= 0 && requestedH <= 0) return srcW to srcH
        if (!keepAspect) {
            var w = if (requestedW > 0) requestedW else srcW
            var h = if (requestedH > 0) requestedH else srcH
            if (doNotEnlarge) { w = min(w, srcW); h = min(h, srcH) }
            return w.coerceAtLeast(1) to h.coerceAtLeast(1)
        }
        val scaleByW = if (requestedW > 0) requestedW.toDouble() / srcW else Double.POSITIVE_INFINITY
        val scaleByH = if (requestedH > 0) requestedH.toDouble() / srcH else Double.POSITIVE_INFINITY
        var scale = min(scaleByW, scaleByH)
        if (!scale.isFinite()) scale = if (requestedW > 0) scaleByW else scaleByH
        if (doNotEnlarge) scale = min(1.0, scale)
        return max(1, (srcW * scale).roundToInt()) to max(1, (srcH * scale).roundToInt())
    }

    private fun sha256(file: File): String = file.inputStream().use { stream ->
        val digest = MessageDigest.getInstance("SHA-256")
        val buf = ByteArray(64 * 1024)
        while (true) {
            val n = stream.read(buf)
            if (n <= 0) break
            digest.update(buf, 0, n)
        }
        digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
}
