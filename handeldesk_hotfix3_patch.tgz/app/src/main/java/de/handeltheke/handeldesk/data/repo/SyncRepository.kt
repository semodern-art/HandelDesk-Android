package de.handeltheke.handeldesk.data.repo

import androidx.room.withTransaction
import de.handeltheke.handeldesk.data.local.*
import de.handeltheke.handeldesk.data.remote.BridgeClient
import de.handeltheke.handeldesk.domain.JsonTools
import de.handeltheke.handeldesk.domain.ProductJson
import de.handeltheke.handeldesk.domain.Severity
import de.handeltheke.handeldesk.domain.ValidationEngine
import kotlinx.coroutines.flow.first
import kotlinx.serialization.json.*
import java.math.BigDecimal

class SyncRepository(
    private val db: HandelDeskDatabase,
    private val bridge: BridgeClient,
    private val localPhotos: LocalPhotoRepository,
    private val history: ProductHistoryRepository,
) {
    suspend fun buildPayload(): JsonObject = buildPayload(db.changes().includedPending())

    private suspend fun buildPayload(changes: List<ChangeEntity>): JsonObject {
        val productGroups = changes.filter { it.entityType == "product" }.groupBy { it.entityUuid }
        val products = productGroups.mapNotNull { (uuid, rows) ->
            val entity = db.products().get(uuid) ?: return@mapNotNull null
            buildSyncEntity(
                uuid = uuid,
                entityIdName = "product_id",
                entityId = entity.productId,
                sourceProductId = entity.sourceProductId,
                baseRevision = entity.baseRevision,
                baseJson = entity.baseJson,
                localJson = entity.localJson,
                rows = rows
            )
        }
        val manufacturerGroups = changes.filter { it.entityType == "manufacturer" }.groupBy { it.entityUuid }
        val manufacturers = manufacturerGroups.mapNotNull { (uuid, rows) ->
            val entity = db.references().manufacturerByUuid(uuid) ?: return@mapNotNull null
            buildReferenceSyncEntity(uuid, entity.manufacturerId, entity.baseRevision, entity.baseJson, entity.localJson, rows)
        }
        val categoryGroups = changes.filter { it.entityType == "category" }.groupBy { it.entityUuid }
        val categories = categoryGroups.mapNotNull { (uuid, rows) ->
            val entity = db.references().categoryByUuid(uuid) ?: return@mapNotNull null
            buildReferenceSyncEntity(uuid, entity.categoryId, entity.baseRevision, entity.baseJson, entity.localJson, rows)
        }
        return buildJsonObject {
            put("products", JsonArray(products))
            put("manufacturers", JsonArray(manufacturers))
            put("categories", JsonArray(categories))
        }
    }

    private fun buildSyncEntity(
        uuid: String,
        entityIdName: String,
        entityId: Int?,
        sourceProductId: Int?,
        baseRevision: String,
        baseJson: String,
        localJson: String,
        rows: List<ChangeEntity>
    ): JsonObject = buildJsonObject {
        put("entity_uuid", uuid)
        if (entityId != null) put(entityIdName, entityId) else put(entityIdName, JsonNull)
        if (sourceProductId != null) put("source_product_id", sourceProductId) else put("source_product_id", JsonNull)
        put("base_revision", baseRevision)
        put("base", JsonTools.objectOf(baseJson))
        put("local", JsonTools.objectOf(localJson))
        put("changes", changesJson(rows))
    }

    private fun buildReferenceSyncEntity(
        uuid: String,
        entityId: Int,
        baseRevision: String,
        baseJson: String,
        localJson: String,
        rows: List<ChangeEntity>
    ): JsonObject = buildJsonObject {
        put("entity_uuid", uuid)
        put("entity_id", entityId)
        if (entityId < 0) put("temp_id", entityId)
        put("base_revision", baseRevision)
        put("base", JsonTools.objectOf(baseJson))
        put("local", JsonTools.objectOf(localJson))
        put("changes", changesJson(rows))
    }

    private fun changesJson(rows: List<ChangeEntity>): JsonArray = buildJsonArray {
        rows.forEach { ch ->
            add(buildJsonObject {
                put("id", ch.id)
                put("field_path", ch.fieldPath)
                put("operation_type", ch.operationType)
                put("before", parseNullable(ch.beforeJson))
                put("after", parseNullable(ch.afterJson))
            })
        }
    }

    suspend fun localValidationErrors(productUuids: Set<String>? = null): List<Pair<ProductEntity, List<String>>> {
        val changed = db.products().observeChanged().first()
            .filter { productUuids == null || it.uuid in productUuids }
        val language = db.settings().get("primary_language_id")
        return changed.mapNotNull { entity ->
            val errors = ValidationEngine.validate(entity, language).filter { it.severity == Severity.ERROR }.map { it.message }
            if (errors.isEmpty()) null else entity to errors
        }
    }

    suspend fun preview(): JsonObject {
        repairLocalStates()
        val submitted = db.changes().includedPending()
        val productUuids = submitted.filter { it.entityType == "product" }.map { it.entityUuid }.toSet()
        val errors = localValidationErrors(productUuids)
        if (errors.isNotEmpty()) error("Validation блокирует Sync: ${errors.first().first.name}: ${errors.first().second.first()}")
        return bridge.post("sync_preview", buildPayload(submitted))
    }

    /**
     * Apply is intentionally ordered as:
     * 1) upload READY phone photos idempotently,
     * 2) rebuild payload (image paths may have changed),
     * 3) fresh server Preview,
     * 4) Apply,
     * 5) atomically close exactly the submitted local change rows.
     */
    suspend fun apply(): JsonObject {
        repairLocalStates()
        var submitted = db.changes().includedPending()
        if (submitted.isEmpty()) {
            return buildJsonObject { put("success_count", 0); put("error_count", 0); put("results", buildJsonArray {}); put("reference_results", buildJsonArray {}) }
        }

        val productUuids = submitted.filter { it.entityType == "product" }.map { it.entityUuid }.toSet()
        val errors = localValidationErrors(productUuids)
        if (errors.isNotEmpty()) error("Validation блокирует Sync: ${errors.first().first.name}: ${errors.first().second.first()}")

        // Upload only photos that are part of the selected sync payload. A price-only sync must not
        // silently upload a photo whose image change is unchecked or was discarded.
        val photoProductUuids = submitted.filter { change ->
            change.entityType == "product" && (change.fieldPath == "__create__" || change.fieldPath == "product.image" || change.fieldPath == "images")
        }.map { it.entityUuid }.toSet()
        localPhotos.uploadPending(photoProductUuids)

        // Re-read after upload so the exact rows being submitted are captured for acknowledgement.
        submitted = db.changes().includedPending()
        val payload = buildPayload(submitted)
        val preview = bridge.post("sync_preview", payload)
        if (preview["apply_allowed"]?.jsonPrimitive?.booleanOrNull != true) error("Bridge не разрешил Apply")

        // One checkpoint per product just before the server-changing call. If the call fails,
        // captureCurrent de-duplicates identical state on the next attempt.
        productUuids.forEach { uuid ->
            history.captureCurrent(uuid, "sync_checkpoint", "Состояние перед синхронизацией")
        }
        val result = bridge.post("sync_apply", payload)
        val submittedIds = submitted.groupBy { it.entityType to it.entityUuid }.mapValues { (_, rows) -> rows.map { it.id } }

        db.withTransaction {
            applyIdMap(result["id_map"] as? JsonObject)
            (result["results"] as? JsonArray).orEmpty().forEach { itemElement ->
                val item = itemElement as? JsonObject ?: return@forEach
                if (item["ok"]?.jsonPrimitive?.booleanOrNull != true) return@forEach
                val uuid = item["entity_uuid"]?.jsonPrimitive?.contentOrNull ?: return@forEach
                val current = db.products().get(uuid) ?: return@forEach
                val ids = submittedIds["product" to uuid].orEmpty()
                if (ids.isNotEmpty()) db.changes().markIdsSynced(ids)

                val serverWithRevision = item["product"] as? JsonObject
                val revision = serverWithRevision?.get("revision")?.jsonPrimitive?.contentOrNull.orEmpty()
                val serverPayload = serverWithRevision?.let { JsonObject(it.toMutableMap().apply { remove("revision") }) }
                val productId = item["product_id"]?.jsonPrimitive?.intOrNull
                    ?: serverPayload?.get("product")?.jsonObject?.get("product_id")?.jsonPrimitive?.intOrNull
                    ?: current.productId
                    ?: return@forEach
                val recoveredCreate = item["recovered_create"]?.jsonPrimitive?.booleanOrNull == true && current.productId == null

                if (recoveredCreate && serverPayload != null) {
                    recoverCreateLocally(current, productId, revision, serverPayload)
                } else {
                    val accepted = serverPayload ?: JsonTools.setPath(JsonTools.objectOf(current.localJson), "product.product_id", JsonPrimitive(productId))
                    val index = runCatching { ProductJson.index(accepted, db.settings().get("primary_language_id")) }
                        .getOrElse { ProductJson.index(JsonTools.objectOf(current.localJson), db.settings().get("primary_language_id")) }
                    db.products().put(current.copy(
                        productId = productId,
                        baseRevision = revision.ifBlank { current.baseRevision },
                        baseJson = accepted.toString(), localJson = accepted.toString(),
                        state = "SYNCED", isDraft = false, workflowState = "READY",
                        name = index.name, model = index.model, sku = index.sku, jan = index.jan,
                        price = index.price, quantity = index.quantity, manufacturerId = index.manufacturerId,
                        status = index.status, searchNorm = index.searchNorm, updatedAt = System.currentTimeMillis()
                    ))
                    localPhotos.markProductAttached(uuid)
                }
            }

            (result["reference_results"] as? JsonArray).orEmpty().forEach { refElement ->
                val ref = refElement as? JsonObject ?: return@forEach
                if (ref["ok"]?.jsonPrimitive?.booleanOrNull != true) return@forEach
                val type = ref["entity_type"]?.jsonPrimitive?.contentOrNull ?: return@forEach
                val uuid = ref["entity_uuid"]?.jsonPrimitive?.contentOrNull ?: return@forEach
                val ids = submittedIds[type to uuid].orEmpty()
                if (ids.isNotEmpty()) db.changes().markIdsSynced(ids)
                val serverWithRevision = ref["entity"] as? JsonObject ?: return@forEach
                val revision = serverWithRevision["revision"]?.jsonPrimitive?.contentOrNull.orEmpty()
                val serverPayload = JsonObject(serverWithRevision.toMutableMap().apply { remove("revision") })
                when (type) {
                    "manufacturer" -> {
                        val current = db.references().manufacturerByUuid(uuid) ?: return@forEach
                        val id = ref["entity_id"]?.jsonPrimitive?.intOrNull ?: current.manufacturerId
                        val name = serverPayload["name"]?.jsonPrimitive?.contentOrNull.orEmpty()
                        db.references().putManufacturers(listOf(current.copy(manufacturerId = id, baseRevision = revision, baseJson = serverPayload.toString(), localJson = serverPayload.toString(), state = "SYNCED", name = name, updatedAt = System.currentTimeMillis())))
                    }
                    "category" -> {
                        val current = db.references().categoryByUuid(uuid) ?: return@forEach
                        val id = ref["entity_id"]?.jsonPrimitive?.intOrNull ?: current.categoryId
                        val name = serverPayload["name"]?.jsonPrimitive?.contentOrNull.orEmpty()
                        val parent = serverPayload["parent_id"]?.jsonPrimitive?.intOrNull ?: 0
                        db.references().putCategories(listOf(current.copy(categoryId = id, baseRevision = revision, baseJson = serverPayload.toString(), localJson = serverPayload.toString(), state = "SYNCED", name = name, parentId = parent, updatedAt = System.currentTimeMillis())))
                    }
                }
            }
            db.audit().insert(AuditEventEntity(
                createdAt = System.currentTimeMillis(), eventType = "sync_result", source = "android",
                summary = "Sync завершён: успешно ${result["success_count"]?.jsonPrimitive?.intOrNull ?: 0}, ошибок ${result["error_count"]?.jsonPrimitive?.intOrNull ?: 0}",
                detailsJson = result.toString()
            ))
        }
        repairLocalStates()
        return result
    }

    /** If Bridge already created this UUID but Android missed the acknowledgement, recover safely. */
    private suspend fun recoverCreateLocally(current: ProductEntity, productId: Int, revision: String, serverPayload: JsonObject) {
        var desired = JsonTools.objectOf(current.localJson)
        desired = JsonTools.setPath(desired, "product.product_id", JsonPrimitive(productId))
        val diffs = recoveryDiff(serverPayload, desired)
        val indexPayload = if (diffs.isEmpty()) serverPayload else desired
        val index = ProductJson.index(indexPayload, db.settings().get("primary_language_id"))
        db.products().put(current.copy(
            productId = productId, baseRevision = revision, baseJson = serverPayload.toString(), localJson = indexPayload.toString(),
            state = if (diffs.isEmpty()) "SYNCED" else "MODIFIED", isDraft = false, workflowState = "READY",
            name = index.name, model = index.model, sku = index.sku, jan = index.jan, price = index.price,
            quantity = index.quantity, manufacturerId = index.manufacturerId, status = index.status,
            searchNorm = index.searchNorm, updatedAt = System.currentTimeMillis()
        ))
        if (diffs.isEmpty()) {
            localPhotos.markProductAttached(current.uuid)
            return
        }
        val session = db.settings().get("active_session_id")
        val now = System.currentTimeMillis()
        diffs.forEach { diff ->
            db.changes().insert(ChangeEntity(
                sessionId = session, entityType = "product", entityUuid = current.uuid,
                fieldPath = diff.path, beforeJson = diff.before.toString(), afterJson = diff.after.toString(),
                operationType = "set", synced = false, included = true, createdAt = now
            ))
        }
        db.audit().insert(AuditEventEntity(
            createdAt = now, sessionId = session, eventType = "recovered_create", entityType = "product",
            entityUuid = current.uuid, entityId = productId, source = "android",
            summary = "Восстановлен уже созданный товар #$productId; локальных изменений после создания: ${diffs.size}",
            detailsJson = buildJsonObject { put("product_id", productId); put("recreated_changes", diffs.size) }.toString()
        ))
    }

    private data class RecoveryDiff(val path: String, val before: JsonElement, val after: JsonElement)

    private fun recoveryDiff(server: JsonObject, desired: JsonObject): List<RecoveryDiff> {
        val out = mutableListOf<RecoveryDiff>()
        val productFields = listOf(
            "model","sku","upc","ean","jan","isbn","mpn","location","quantity","stock_status_id","image","manufacturer_id",
            "shipping","price","points","tax_class_id","date_available","weight","weight_class_id","length","width","height",
            "length_class_id","subtract","minimum","sort_order","status"
        )
        productFields.forEach { field -> addRecoveryDiff(out, "product.$field", server, desired) }
        val desc = desired["descriptions"] as? JsonObject
        desc?.forEach { (lang, element) ->
            val row = element as? JsonObject ?: return@forEach
            listOf("name","description","tag","meta_title","meta_description","meta_keyword").forEach { field ->
                if (field in row) addRecoveryDiff(out, "descriptions.$lang.$field", server, desired)
            }
        }
        listOf("categories","stores","related","images","attributes","options","discounts","specials","seo_urls").forEach { path ->
            if (path in desired) addRecoveryDiff(out, path, server, desired)
        }
        return out
    }

    private fun addRecoveryDiff(out: MutableList<RecoveryDiff>, path: String, server: JsonObject, desired: JsonObject) {
        val before = JsonTools.path(server, path) ?: JsonNull
        val after = JsonTools.path(desired, path) ?: JsonNull
        if (!jsonEquivalent(before, after)) out += RecoveryDiff(path, before, after)
    }

    private fun jsonEquivalent(a: JsonElement, b: JsonElement): Boolean {
        if (a is JsonNull && b is JsonNull) return true
        if (a is JsonPrimitive && b is JsonPrimitive) {
            if (a.isString || b.isString) {
                val an = a.content.toBigDecimalOrNull(); val bn = b.content.toBigDecimalOrNull()
                if (an != null && bn != null) return an.compareTo(bn) == 0
                return a.content == b.content
            }
            val an = a.content.toBigDecimalOrNull(); val bn = b.content.toBigDecimalOrNull()
            if (an != null && bn != null) return an.compareTo(bn) == 0
            return a.content == b.content
        }
        if (a is JsonArray && b is JsonArray) return a.size == b.size && a.indices.all { jsonEquivalent(a[it], b[it]) }
        if (a is JsonObject && b is JsonObject) {
            val keys = a.keys + b.keys
            return keys.all { jsonEquivalent(a[it] ?: JsonNull, b[it] ?: JsonNull) }
        }
        return a == b
    }

    private suspend fun repairLocalStates() {
        db.products().observeChanged().first().forEach { p ->
            if (p.productId == null) {
                val pending = db.changes().pendingForEntity("product", p.uuid)
                if (pending.any { it.fieldPath == "__create__" }) {
                    db.changes().deleteRedundantNewProductChanges(p.uuid)
                }
            } else if (db.changes().pendingCount("product", p.uuid) == 0 && p.state != "SYNCED") {
                db.products().put(p.copy(state = "SYNCED", isDraft = false, updatedAt = System.currentTimeMillis()))
            }
        }
    }

    private suspend fun applyIdMap(idMap: JsonObject?) {
        if (idMap == null) return
        val manufacturers = (idMap["manufacturers"] as? JsonObject).orEmpty().mapNotNull { (k, v) ->
            val old = k.toIntOrNull(); val new = v.jsonPrimitive.intOrNull
            if (old != null && new != null) old to new else null
        }.toMap()
        val categories = (idMap["categories"] as? JsonObject).orEmpty().mapNotNull { (k, v) ->
            val old = k.toIntOrNull(); val new = v.jsonPrimitive.intOrNull
            if (old != null && new != null) old to new else null
        }.toMap()
        if (manufacturers.isEmpty() && categories.isEmpty()) return
        val now = System.currentTimeMillis()

        manufacturers.forEach { (old, new) ->
            val row = db.references().manufacturerById(old) ?: return@forEach
            val local = JsonTools.objectOf(row.localJson).toMutableMap().apply { put("manufacturer_id", JsonPrimitive(new)) }
            db.references().putManufacturers(listOf(row.copy(manufacturerId = new, localJson = JsonObject(local).toString(), updatedAt = now)))
        }
        categories.forEach { (old, new) ->
            val row = db.references().categoryById(old) ?: return@forEach
            val local = JsonTools.objectOf(row.localJson)
            val oldParent = local["parent_id"]?.jsonPrimitive?.intOrNull ?: row.parentId
            val mappedParent = categories[oldParent] ?: oldParent
            val mapped = local.toMutableMap().apply { put("category_id", JsonPrimitive(new)); put("parent_id", JsonPrimitive(mappedParent)) }
            db.references().putCategories(listOf(row.copy(categoryId = new, parentId = mappedParent, localJson = JsonObject(mapped).toString(), updatedAt = now)))
        }
        db.references().categories().forEach { row ->
            val local = JsonTools.objectOf(row.localJson)
            val parent = local["parent_id"]?.jsonPrimitive?.intOrNull ?: row.parentId
            val mapped = categories[parent] ?: return@forEach
            val updated = JsonObject(local.toMutableMap().apply { put("parent_id", JsonPrimitive(mapped)) })
            db.references().putCategories(listOf(row.copy(parentId = mapped, localJson = updated.toString(), updatedAt = now)))
        }
        var afterProductUuid = ""
        while (true) {
            val batch = db.products().jsonScanBatch(afterProductUuid, 50)
            if (batch.isEmpty()) break
            for (scanRow in batch) {
                var local = JsonTools.objectOf(scanRow.localJson)
                var changed = false
                val mid = JsonTools.path(local, "product.manufacturer_id")?.jsonPrimitive?.intOrNull ?: 0
                manufacturers[mid]?.let { mapped -> local = JsonTools.setPath(local, "product.manufacturer_id", JsonPrimitive(mapped)); changed = true }
                val cats = (local["categories"] as? JsonArray).orEmpty().mapNotNull { it.jsonPrimitive.intOrNull }
                val mappedCats = cats.map { categories[it] ?: it }
                if (mappedCats != cats) {
                    local = JsonObject(local.toMutableMap().apply { put("categories", JsonArray(mappedCats.map(::JsonPrimitive))) })
                    changed = true
                }
                if (changed) {
                    val row = db.products().get(scanRow.uuid) ?: continue
                    val idx = ProductJson.index(local, db.settings().get("primary_language_id"))
                    db.products().put(row.copy(localJson = local.toString(), manufacturerId = idx.manufacturerId, searchNorm = idx.searchNorm, updatedAt = now))
                }
            }
            val next = batch.last().uuid
            if (next <= afterProductUuid) error("Локальный product remap checkpoint не продвигается")
            afterProductUuid = next
        }
        db.changes().pending().forEach { change ->
            fun remapValue(text: String?, path: String): String? {
                if (text == null) return null
                val value = parseNullable(text)
                val next: JsonElement = when (path) {
                    "product.manufacturer_id" -> value.jsonPrimitive.intOrNull?.let { JsonPrimitive(manufacturers[it] ?: it) } ?: value
                    "parent_id" -> value.jsonPrimitive.intOrNull?.let { JsonPrimitive(categories[it] ?: it) } ?: value
                    "categories" -> if (value is JsonArray) JsonArray(value.map { e -> e.jsonPrimitive.intOrNull?.let { JsonPrimitive(categories[it] ?: it) } ?: e }) else value
                    else -> value
                }
                return next.toString()
            }
            if (change.fieldPath in setOf("product.manufacturer_id", "parent_id", "categories")) {
                val before = remapValue(change.beforeJson, change.fieldPath)
                val after = remapValue(change.afterJson, change.fieldPath)
                if (before != change.beforeJson || after != change.afterJson) db.changes().update(change.copy(beforeJson = before, afterJson = after))
            }
        }
    }

    private fun parseNullable(text: String?): JsonElement {
        if (text == null) return JsonNull
        return runCatching { JsonTools.json.parseToJsonElement(text) }.getOrElse { JsonPrimitive(text) }
    }
}
