package de.handeltheke.handeldesk.ui.components

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/**
 * Persists editor drafts beyond the lifetime of a composable / navigation screen.
 * Latest edit wins for a given stable product-field key. Different fields can save
 * independently; Room transactions serialize modifications to the same product.
 */
object AutoSaveCoordinator {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val lock = Any()

    private class Slot {
        val writeMutex = Mutex()
        var generation = 0L
        var job: Job? = null
        var error: Throwable? = null
        var lastValue: String? = null
    }

    private val slots = mutableMapOf<String, Slot>()

    fun submit(
        key: String,
        text: String,
        immediate: Boolean = false,
        save: suspend (String) -> Unit,
        completed: (String, Throwable?) -> Unit = { _, _ -> },
    ) {
        require(key.isNotBlank()) { "Auto-save requires a stable field key" }
        synchronized(lock) {
            val slot = slots.getOrPut(key) { Slot() }
            // Avoid restarting an already-running write for the same value.
            if (!immediate && slot.lastValue == text && slot.job?.isActive == true) return
            slot.generation += 1
            val myGeneration = slot.generation
            slot.error = null
            slot.lastValue = text
            slot.job?.cancel()
            val newJob = scope.launch(start = CoroutineStart.LAZY) {
                try {
                    if (!immediate) delay(450L)
                    slot.writeMutex.withLock {
                        val current = synchronized(lock) { slot.generation == myGeneration }
                        if (!current) return@withLock
                        save(text)
                    }
                    withContext(Dispatchers.Main.immediate) { completed(text, null) }
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (e: Throwable) {
                    synchronized(lock) {
                        if (slot.generation == myGeneration) slot.error = e
                    }
                    withContext(Dispatchers.Main.immediate) { completed(text, e) }
                }
            }
            slot.job = newJob
            newJob.start()
        }
    }

    /** Waits until the latest local edits have reached Room, or raises a save error. */
    suspend fun awaitPending(keyPrefix: String? = null) {
        while (true) {
            val current = synchronized(lock) { slots.filterKeys { keyPrefix == null || it.startsWith(keyPrefix) }.values.mapNotNull { it.job } }
            current.joinAll()
            val (changed, errors) = synchronized(lock) {
                val relevant = slots.filterKeys { keyPrefix == null || it.startsWith(keyPrefix) }.values
                val newer = relevant.mapNotNull { it.job }
                (newer.any { it !in current && it.isActive }) to relevant.mapNotNull { it.error }
            }
            if (changed) continue
            if (errors.isNotEmpty()) {
                throw IllegalStateException("Не удалось сохранить изменения: ${errors.first().message ?: "ошибка базы данных"}", errors.first())
            }
            return
        }
    }
}
