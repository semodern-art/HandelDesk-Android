package de.handeltheke.handeldesk.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import de.handeltheke.handeldesk.HandelDeskApp
import de.handeltheke.handeldesk.data.repo.TravelSafetyRepository
import de.handeltheke.handeldesk.ui.ScreenHeader
import de.handeltheke.handeldesk.ui.components.SectionCard
import de.handeltheke.handeldesk.ui.components.StatusBadge
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TravelReadyScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val app = context.applicationContext as HandelDeskApp
    val repo = app.container.travelSafety
    val scope = rememberCoroutineScope()
    var report by remember { mutableStateOf<TravelSafetyRepository.ReadinessReport?>(null) }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var includeCache by remember { mutableStateOf(false) }
    var pendingRestore by remember { mutableStateOf<Uri?>(null) }
    var diagnosticText by remember { mutableStateOf<String?>(null) }

    fun refresh() {
        scope.launch {
            report = runCatching { repo.readiness() }
                .onFailure { message = "Проверка не выполнена: ${it.message}" }
                .getOrNull()
        }
    }

    val backupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) scope.launch {
            busy = true; message = null
            runCatching { repo.createBackup(uri, includeCache) { progress = it } }
                .onSuccess {
                    message = "✓ Backup создан: ${formatBytesTravel(it.bytes)} · ${it.files} файлов"
                    refresh()
                }
                .onFailure { message = "Ошибка backup: ${it.message}" }
            progress = null; busy = false
        }
    }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) pendingRestore = uri
    }
    val diagnosticsLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) scope.launch {
            busy = true; message = null
            runCatching { repo.writeDiagnostics(uri) }
                .onSuccess { message = "✓ Диагностика сохранена: ${formatBytesTravel(it)}" }
                .onFailure { message = "Ошибка экспорта диагностики: ${it.message}" }
            busy = false
        }
    }

    LaunchedEffect(Unit) { refresh() }

    if (pendingRestore != null) {
        AlertDialog(
            onDismissRequest = { if (!busy) pendingRestore = null },
            title = { Text("Восстановить резервную копию?") },
            text = {
                Text(
                    "Текущая локальная база, черновики, ChangeSet, History/Undo и рабочие копии фото будут заменены содержимым выбранного backup. " +
                        "Архив сначала пройдёт SHA-256, SQLite integrity_check и проверку версии схемы. Если проверка или импорт не пройдут, текущая база останется без изменений."
                )
            },
            confirmButton = {
                Button(enabled = !busy, onClick = {
                    val uri = pendingRestore ?: return@Button
                    scope.launch {
                        busy = true; message = null
                        runCatching { repo.restoreBackup(uri) { progress = it } }
                            .onSuccess {
                                message = "✓ Backup восстановлен. Device Token не импортировался и остался в Android Keystore."
                                refresh()
                            }
                            .onFailure { message = "Восстановление отменено/не выполнено: ${it.message}" }
                        progress = null; busy = false; pendingRestore = null
                    }
                }) { Text(if (busy) "…" else "Восстановить") }
            },
            dismissButton = { TextButton(enabled = !busy, onClick = { pendingRestore = null }) { Text("Отмена") } },
        )
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Готовность к поездке", "Backup, offline-проверка и диагностика", onBack)
        Column(
            Modifier.weight(1f).fillMaxWidth().padding(12.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            val current = report
            SectionCard(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Проверка", style = MaterialTheme.typography.titleMedium)
                    current?.let {
                        StatusBadge(
                            if (it.errors > 0) "Есть ошибки" else if (it.warnings > 0) "Есть замечания" else "Готово",
                            if (it.errors > 0) "error" else if (it.warnings > 0) "warn" else "ok",
                        )
                    }
                }
                if (current == null) LinearProgressIndicator(Modifier.fillMaxWidth())
                current?.items?.forEach { item ->
                    HorizontalDivider()
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatusBadge(
                            when (item.state) {
                                TravelSafetyRepository.CheckState.OK -> "✓"
                                TravelSafetyRepository.CheckState.WARN -> "!"
                                TravelSafetyRepository.CheckState.ERROR -> "✕"
                            },
                            when (item.state) {
                                TravelSafetyRepository.CheckState.OK -> "ok"
                                TravelSafetyRepository.CheckState.WARN -> "warn"
                                TravelSafetyRepository.CheckState.ERROR -> "error"
                            },
                        )
                        Column(Modifier.weight(1f)) {
                            Text(item.title, style = MaterialTheme.typography.titleSmall)
                            Text(item.detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                OutlinedButton(onClick = { refresh() }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("Проверить ещё раз") }
                OutlinedButton(onClick = {
                    scope.launch {
                        busy = true
                        message = runCatching { repo.testBridge() }.getOrElse { "Bridge: ${it.message}" }
                        busy = false
                    }
                }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("Проверить Bridge сейчас") }
            }

            SectionCard(Modifier.fillMaxWidth()) {
                Text("Резервная копия", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Backup содержит всю локальную БД, черновики, ChangeSet, History/Undo и внутренние оригиналы/обработанные фото HandelDesk. Device Token не записывается в ZIP.",
                    style = MaterialTheme.typography.bodySmall,
                )
                Row(Modifier.fillMaxWidth()) {
                    Checkbox(checked = includeCache, onCheckedChange = { if (!busy) includeCache = it })
                    Column(Modifier.padding(top = 9.dp)) {
                        Text("Добавить offline-кэш изображений")
                        Text(
                            report?.let { "Сейчас кэш: ${formatBytesTravel(it.cacheBytes)}" } ?: "Архив может стать значительно больше",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                Button(
                    onClick = { backupLauncher.launch("HandelDesk-backup-${fileStamp()}.zip") },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("СОЗДАТЬ BACKUP") }
                OutlinedButton(
                    onClick = { restoreLauncher.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Восстановить из backup") }
            }

            SectionCard(Modifier.fillMaxWidth()) {
                Text("Диагностика", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Отчёт не содержит Device Token. В него входят версия приложения, состояние БД, offline/фото/Bridge, последние события и последний crash-log, если он был.",
                    style = MaterialTheme.typography.bodySmall,
                )
                Button(onClick = {
                    diagnosticsLauncher.launch("HandelDesk-diagnostics-${fileStamp()}.txt")
                }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("ЭКСПОРТИРОВАТЬ ДИАГНОСТИКУ") }
                OutlinedButton(onClick = {
                    scope.launch {
                        busy = true
                        runCatching { repo.diagnosticText() }
                            .onSuccess { text ->
                                diagnosticText = text
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("HandelDesk diagnostics", text))
                                message = "✓ Диагностика скопирована в буфер"
                            }
                            .onFailure { message = "Ошибка диагностики: ${it.message}" }
                        busy = false
                    }
                }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("Скопировать диагностику") }
            }

            progress?.let {
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Text(it, style = MaterialTheme.typography.bodySmall)
            }
            message?.let {
                Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = MaterialTheme.shapes.medium) {
                    Text(it, Modifier.padding(12.dp))
                }
            }
            if (!diagnosticText.isNullOrBlank()) {
                Text("Последний диагностический отчёт подготовлен и доступен в буфере обмена.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

private fun fileStamp(): String = SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())
private fun formatBytesTravel(value: Long): String = when {
    value >= 1024L * 1024 * 1024 -> "%.1f GB".format(value / (1024.0 * 1024 * 1024))
    value >= 1024L * 1024 -> "%.1f MB".format(value / (1024.0 * 1024))
    value >= 1024L -> "%.1f KB".format(value / 1024.0)
    else -> "$value B"
}
