package de.handeltheke.handeldesk.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import de.handeltheke.handeldesk.HandelDeskApp
import de.handeltheke.handeldesk.core.HandelthekeSeoPolicy
import de.handeltheke.handeldesk.data.local.ProductEntity
import de.handeltheke.handeldesk.domain.*
import de.handeltheke.handeldesk.ui.ScreenHeader
import de.handeltheke.handeldesk.ui.components.AutoSaveField
import de.handeltheke.handeldesk.ui.components.AutoSaveCoordinator
import de.handeltheke.handeldesk.ui.components.CachedProductImage
import de.handeltheke.handeldesk.ui.components.LocalFileImage
import de.handeltheke.handeldesk.ui.components.ProductThumbnail
import de.handeltheke.handeldesk.ui.components.ProductPhotoZoomDialog
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.serialization.json.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductScreen(uuid: String, onBack: () -> Unit, onDone: () -> Unit, onReplace: (String) -> Unit, onPhotos: (String) -> Unit, onHistory: (String) -> Unit) {
    val app = LocalContext.current.applicationContext as HandelDeskApp
    val focusManager = LocalFocusManager.current
    val product by app.container.db.products().observe(uuid).collectAsState(initial = null)
    val categories by app.container.db.references().observeCategories().collectAsState(initial = emptyList())
    val manufacturers by app.container.db.references().observeManufacturers().collectAsState(initial = emptyList())
    val localPhotos by app.container.db.photos().observeForProduct(uuid).collectAsState(initial = emptyList())
    val historyPoints by app.container.db.history().observeForProduct(uuid, 20).collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var primaryLanguageId by remember { mutableStateOf("1") }
    var schemaLabels by remember { mutableStateOf(BridgeSchemaLabels()) }
    var showAll by rememberSaveable { mutableStateOf(false) }
    var showCategories by remember { mutableStateOf(false) }
    var manufacturerMenu by remember { mutableStateOf(false) }
    var manufacturerQuery by rememberSaveable(uuid) { mutableStateOf("") }
    var showNewManufacturer by remember { mutableStateOf(false) }
    var showNewCategory by remember { mutableStateOf(false) }
    var newManufacturerName by rememberSaveable { mutableStateOf("") }
    var newCategoryName by rememberSaveable { mutableStateOf("") }
    var uiMessage by remember { mutableStateOf<String?>(null) }
    var donor by remember { mutableStateOf<ProductEntity?>(null) }
    var selectedLanguageId by rememberSaveable { mutableStateOf("") }
    var showMainImage by remember { mutableStateOf(false) }
    var previewPhotoPath by remember { mutableStateOf<String?>(null) }
    var confirmCopyNameToDescription by remember { mutableStateOf(false) }
    var liveDescriptionName by rememberSaveable { mutableStateOf("") }
    var showDonorOverride by remember { mutableStateOf(false) }
    var showDeleteLocalProduct by remember { mutableStateOf(false) }
    var deleteBusy by remember { mutableStateOf(false) }
    var showUndoConfirm by remember { mutableStateOf(false) }
    var undoBusy by remember { mutableStateOf(false) }

    fun navigateAfterSaving(action: () -> Unit) {
        scope.launch {
            focusManager.clearFocus(force = true)
            runCatching { AutoSaveCoordinator.awaitPending("$uuid:") }
                .onSuccess { action() }
                .onFailure { uiMessage = it.message ?: "Ошибка сохранения полей" }
        }
    }

    LaunchedEffect(Unit) {
        primaryLanguageId = app.container.db.settings().get("primary_language_id") ?: "1"
        schemaLabels = BridgeSchemaLabels.fromSchemaJson(app.container.db.settings().get("bridge_schema"))
    }
    LaunchedEffect(product?.sourceProductId, product?.sourceProductUuid) {
        val current = product
        donor = current?.sourceProductUuid?.let { app.container.db.products().get(it) }
            ?: current?.sourceProductId?.let { app.container.db.products().getByProductId(it) }
    }

    val p = product
    if (p == null) {
        Column { ScreenHeader("Товар", onBack = { navigateAfterSaving(onBack) }); LinearProgressIndicator(Modifier.fillMaxWidth()) }
        return
    }
    val payload = remember(p.localJson) { JsonTools.objectOf(p.localJson) }
    val core = payload["product"]?.jsonObject ?: buildJsonObject {}
    val descriptions = payload["descriptions"]?.jsonObject ?: buildJsonObject {}
    LaunchedEffect(primaryLanguageId, descriptions.keys.joinToString("|")) {
        val fallback = if (primaryLanguageId in descriptions.keys) primaryLanguageId else descriptions.keys.firstOrNull().orEmpty()
        if (selectedLanguageId.isBlank() || selectedLanguageId !in descriptions.keys) selectedLanguageId = fallback
    }
    val activeLanguageId = selectedLanguageId.ifBlank { primaryLanguageId }
    val desc = descriptions[activeLanguageId]?.jsonObject ?: descriptions.values.firstOrNull()?.jsonObject ?: buildJsonObject {}
    LaunchedEffect(activeLanguageId, desc["name"]?.jsonPrimitive?.contentOrNull) {
        liveDescriptionName = desc["name"]?.jsonPrimitive?.contentOrNull.orEmpty()
    }
    val mainImage = core["image"]?.jsonPrimitive?.contentOrNull.orEmpty()
    val localMainPhoto = localPhotos.firstOrNull {
        it.remotePath == mainImage && (it.processedPath.isNotBlank() || it.originalPath.isNotBlank())
    } ?: if (mainImage.isBlank()) localPhotos.firstOrNull { it.isMain } else null
    val selectedCategories = (payload["categories"] as? JsonArray).orEmpty().mapNotNull { it.jsonPrimitive.intOrNull }.toSet()
    val manufacturerName = manufacturers.firstOrNull { it.manufacturerId == p.manufacturerId }?.name ?: "—"
    LaunchedEffect(p.manufacturerId, manufacturerName) {
        manufacturerQuery = if (p.manufacturerId == 0) "" else manufacturerName
    }
    val filteredManufacturers = remember(manufacturerQuery, manufacturers) {
        val q = manufacturerQuery.trim()
        if (q.isBlank()) manufacturers.take(20)
        else manufacturers.filter { it.name.contains(q, ignoreCase = true) }.take(20)
    }
    val validation = remember(p.localJson, primaryLanguageId) { ValidationEngine.validate(p, primaryLanguageId) }
    val checklist = remember(p.localJson, donor?.localJson) { donor?.let { ValidationEngine.donorChecklist(p, it) } }
    val undoPoint = historyPoints.firstOrNull { it.actionType != "sync_checkpoint" }
    val undoIsRestoreSafety = undoPoint?.actionType == "history_restore"

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(p.name.ifBlank { "Новый товар" }, "${p.productId?.let { "#$it" } ?: "LOCAL"} · ${p.state} · ${p.workflowState}", onBack = { navigateAfterSaving(onBack) })
        Surface(color = MaterialTheme.colorScheme.surfaceVariant) {
            Text(
                "Последнее сохранение в базе: ${SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(p.updatedAt))} · автосохранение при вводе и выходе из поля",
                modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 7.dp),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (undoPoint != null) item {
                val latest = undoPoint
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("История и откат", style = MaterialTheme.typography.titleMedium)
                        Text(
                            if (undoIsRestoreSafety) "Последним действием был откат. Можно вернуть состояние, которое было непосредственно перед ним."
                            else "Можно вернуть состояние до: ${latest.summary}",
                            style = MaterialTheme.typography.bodySmall,
                        )
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilledTonalButton(
                                enabled = !undoBusy,
                                onClick = { showUndoConfirm = true },
                                modifier = Modifier.weight(1f),
                            ) { Text(if (undoIsRestoreSafety) "↪ Отменить откат" else "↩ Отменить последнее") }
                            OutlinedButton(onClick = { navigateAfterSaving { onHistory(uuid) } }, modifier = Modifier.weight(1f)) { Text("История") }
                        }
                    }
                }
            }
            item {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (localMainPhoto != null || mainImage.isNotBlank()) {
                            ProductThumbnail(
                                mainImage,
                                localPhotos,
                                modifier = Modifier.fillMaxWidth().clickable { previewPhotoPath = mainImage; showMainImage = true },
                                size = 160.dp,
                                contentScale = ContentScale.Fit,
                            )
                            Text(if (localMainPhoto != null) "Локальное фото · нажмите, чтобы открыть" else "Нажмите на фото, чтобы открыть", style = MaterialTheme.typography.bodySmall)
                        }
                        AutoSaveField(
                            value = core["model"]?.jsonPrimitive?.contentOrNull.orEmpty(), label = "Model",
                            onSave = { app.container.productEditor.updateField(uuid, "product.model", JsonPrimitive(it)) }, modifier = Modifier.fillMaxWidth(), saveKey = "$uuid:product.model"
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            AutoSaveField(
                                value = core["price"]?.jsonPrimitive?.contentOrNull.orEmpty(), label = "Цена",
                                onSave = { app.container.productEditor.updateField(uuid, "product.price", JsonPrimitive(it.replace(',', '.'))) }, modifier = Modifier.weight(1f), saveKey = "$uuid:product.price"
                            )
                            Column(Modifier.weight(1f)) {
                                Text("Остаток", style = MaterialTheme.typography.labelMedium)
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    OutlinedButton(onClick = { scope.launch { app.container.productEditor.adjustQuantity(uuid, -1) } }) { Text("−1") }
                                    Text(p.quantity.toString(), modifier = Modifier.padding(top = 12.dp))
                                    OutlinedButton(onClick = { scope.launch { app.container.productEditor.adjustQuantity(uuid, +1) } }) { Text("+1") }
                                    OutlinedButton(onClick = { scope.launch { app.container.productEditor.adjustQuantity(uuid, +2) } }) { Text("+2") }
                                }
                            }
                        }
                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Text("Статус", modifier = Modifier.weight(1f))
                            Switch(checked = p.status == 1, onCheckedChange = { checked -> scope.launch { app.container.productEditor.updateField(uuid, "product.status", JsonPrimitive(if (checked) 1 else 0)) } })
                        }
                        ExposedDropdownMenuBox(expanded = manufacturerMenu, onExpandedChange = { manufacturerMenu = it }) {
                            OutlinedTextField(
                                value = manufacturerQuery,
                                onValueChange = { value ->
                                    manufacturerQuery = value
                                    manufacturerMenu = true
                                },
                                label = { Text("Производитель") },
                                placeholder = { Text("Начните вводить название") },
                                singleLine = true,
                                modifier = Modifier.menuAnchor().fillMaxWidth(),
                            )
                            ExposedDropdownMenu(expanded = manufacturerMenu, onDismissRequest = { manufacturerMenu = false }) {
                                DropdownMenuItem(text = { Text("— Без производителя") }, onClick = {
                                    manufacturerMenu = false
                                    manufacturerQuery = ""
                                    scope.launch { app.container.productEditor.updateField(uuid, "product.manufacturer_id", JsonPrimitive(0)) }
                                })
                                val exactMatch = manufacturers.any { it.name.equals(manufacturerQuery.trim(), ignoreCase = true) }
                                if (manufacturerQuery.isNotBlank() && !exactMatch) {
                                    DropdownMenuItem(text = { Text("＋ Создать «${manufacturerQuery.trim()}»") }, onClick = {
                                        newManufacturerName = manufacturerQuery.trim()
                                        manufacturerMenu = false
                                        showNewManufacturer = true
                                    })
                                }
                                if (filteredManufacturers.isNotEmpty()) HorizontalDivider()
                                filteredManufacturers.forEach { m ->
                                    DropdownMenuItem(text = { Text(m.name) }, onClick = {
                                        manufacturerMenu = false
                                        manufacturerQuery = m.name
                                        scope.launch { app.container.productEditor.updateField(uuid, "product.manufacturer_id", JsonPrimitive(m.manufacturerId)) }
                                    })
                                }
                            }
                        }
                        OutlinedButton(onClick = { showCategories = true }, modifier = Modifier.fillMaxWidth()) {
                            Text("Категории: ${selectedCategories.size} · ${categories.filter { it.categoryId in selectedCategories }.take(3).joinToString { it.name }}")
                        }
                        if (p.sourceProductId != null || p.sourceProductUuid != null) Button(onClick = { navigateAfterSaving { onReplace(uuid) } }, modifier = Modifier.fillMaxWidth()) { Text("⚡ Быстрая замена по донору") }
                    }
                }
            }

            if (checklist?.applicable == true) item {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("Donor Checklist", style = MaterialTheme.typography.titleMedium)
                        checklist.items.forEach { item -> Text("${when(item.status){"ok"->"✓";"error"->"✕";else->"⚠"}} ${item.label}${if(item.message.isNotBlank()) " — ${item.message}" else ""}") }
                        if (!checklist.ready) {
                            OutlinedButton(onClick = { showDonorOverride = true }, modifier = Modifier.fillMaxWidth()) {
                                Text("Пропустить ошибки Donor Checklist")
                            }
                        }
                    }
                }
            }

            if (validation.isNotEmpty()) item {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("Проверка", style = MaterialTheme.typography.titleMedium)
                        validation.forEach { issue -> Text("${if(issue.severity==Severity.ERROR) "✕" else "⚠"} ${issue.message}") }
                    }
                }
            }

            item {
                TextButton(onClick = { showAll = !showAll }, modifier = Modifier.fillMaxWidth()) { Text(if (showAll) "Скрыть полную карточку" else "ПОЛНАЯ КАРТОЧКА") }
            }

            if (showAll) {
                item { ProductSection("General · Контент") {
                    if (descriptions.isNotEmpty()) {
                        Text("Языки", style = MaterialTheme.typography.labelLarge)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            descriptions.keys.sortedBy { it.toIntOrNull() ?: Int.MAX_VALUE }.forEach { lang ->
                                FilterChip(
                                    selected = activeLanguageId == lang,
                                    onClick = { selectedLanguageId = lang },
                                    label = { Text(schemaLabels.language(lang)) }
                                )
                            }
                        }
                    }
                    val activeName = desc["name"]?.jsonPrimitive?.contentOrNull.orEmpty()
                    val activeDescription = desc["description"]?.jsonPrimitive?.contentOrNull.orEmpty()
                    AutoSaveField(activeName, "Название", { app.container.productEditor.updateField(uuid, "descriptions.$activeLanguageId.name", JsonPrimitive(it)) }, Modifier.fillMaxWidth(), onLocalChange = { liveDescriptionName = it }, saveKey = "$uuid:descriptions.$activeLanguageId.name")
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Text("Description (HTML)", style = MaterialTheme.typography.titleSmall)
                        TextButton(enabled = liveDescriptionName.isNotBlank(), onClick = {
                            if (activeDescription.isNotBlank()) confirmCopyNameToDescription = true
                            else scope.launch {
                                app.container.productEditor.updateField(uuid, "descriptions.$activeLanguageId.description", JsonPrimitive(liveDescriptionName))
                            }
                        }) { Text("↓ Из названия") }
                    }
                    AutoSaveField(activeDescription, "Description (HTML)", { app.container.productEditor.updateField(uuid, "descriptions.$activeLanguageId.description", JsonPrimitive(it)) }, Modifier.fillMaxWidth(), singleLine = false, minLines = 5, saveKey = "$uuid:descriptions.$activeLanguageId.description")
                    AutoSaveField(desc["meta_title"]?.jsonPrimitive?.contentOrNull.orEmpty(), "Meta Title", { app.container.productEditor.updateField(uuid, "descriptions.$activeLanguageId.meta_title", JsonPrimitive(it)) }, Modifier.fillMaxWidth(), saveKey = "$uuid:descriptions.$activeLanguageId.meta_title")
                    AutoSaveField(desc["meta_description"]?.jsonPrimitive?.contentOrNull.orEmpty(), "Meta Description", { app.container.productEditor.updateField(uuid, "descriptions.$activeLanguageId.meta_description", JsonPrimitive(it)) }, Modifier.fillMaxWidth(), singleLine = false, minLines = 2, saveKey = "$uuid:descriptions.$activeLanguageId.meta_description")
                    AutoSaveField(desc["meta_keyword"]?.jsonPrimitive?.contentOrNull.orEmpty(), "Meta Keywords", { app.container.productEditor.updateField(uuid, "descriptions.$activeLanguageId.meta_keyword", JsonPrimitive(it)) }, Modifier.fillMaxWidth(), saveKey = "$uuid:descriptions.$activeLanguageId.meta_keyword")
                    AutoSaveField(desc["tag"]?.jsonPrimitive?.contentOrNull.orEmpty(), "Tags", { app.container.productEditor.updateField(uuid, "descriptions.$activeLanguageId.tag", JsonPrimitive(it)) }, Modifier.fillMaxWidth(), saveKey = "$uuid:descriptions.$activeLanguageId.tag")
                } }
                item { ProductSection("Data · Данные") {
                    Text("Производитель: $manufacturerName", style = MaterialTheme.typography.bodyMedium)
                    listOf("sku" to "SKU", "upc" to "UPC", "ean" to "EAN", "jan" to "JAN", "isbn" to "ISBN", "mpn" to "MPN", "location" to "Location").forEach { (field,label) ->
                        AutoSaveField(core[field]?.jsonPrimitive?.contentOrNull.orEmpty(), label, { app.container.productEditor.updateField(uuid, "product.$field", JsonPrimitive(it)) }, Modifier.fillMaxWidth(), saveKey = "$uuid:product.$field")
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AutoSaveField(
                            core["weight"]?.jsonPrimitive?.contentOrNull.orEmpty(),
                            "Вес",
                            { app.container.productEditor.updateField(uuid, "product.weight", JsonPrimitive(it.replace(',', '.'))) },
                            Modifier.weight(1f), saveKey = "$uuid:product.weight"
                        )
                        AutoSaveField(
                            core["weight_class_id"]?.jsonPrimitive?.contentOrNull.orEmpty(),
                            "ID ед. веса",
                            { app.container.productEditor.updateField(uuid, "product.weight_class_id", JsonPrimitive(it.toIntOrNull() ?: 0)) },
                            Modifier.weight(1f), saveKey = "$uuid:product.weight_class_id"
                        )
                    }
                } }
                item { ProductSection("Options · Опции") { OptionsEditor(uuid, payload, app, scope, schemaLabels) } }
                item { ProductSection("SEO URL") { SeoEditor(uuid, payload, app, schemaLabels) } }
                item { ProductSection("Изображения") {
                    Button(onClick = { navigateAfterSaving { onPhotos(uuid) } }, modifier = Modifier.fillMaxWidth()) {
                        Text("📷 ФОТО НА ТЕЛЕФОНЕ · ${localPhotos.size}")
                    }
                    if (localPhotos.isNotEmpty()) {
                        val pendingPhotos = localPhotos.count { it.status != "ATTACHED" }
                        Text("Локально: ${localPhotos.size} · ожидают синхронизации: $pendingPhotos", style = MaterialTheme.typography.bodySmall)
                    }
                    Text("Главное: ${core["image"]?.jsonPrimitive?.contentOrNull.orEmpty().ifBlank { "—" }}")
                    val images = (payload["images"] as? JsonArray).orEmpty()
                    Text("Дополнительных: ${images.size} · №0 должен дублировать главное")
                    images.sortedBy { (it as? JsonObject)?.get("sort_order")?.jsonPrimitive?.intOrNull ?: Int.MAX_VALUE }.forEachIndexed { i, img ->
                        val path = img.jsonObject["image"]?.jsonPrimitive?.contentOrNull.orEmpty()
                        if (path.isNotBlank()) {
                            Row(Modifier.fillMaxWidth().clickable { previewPhotoPath = path; showMainImage = true }.padding(vertical = 4.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                ProductThumbnail(path, localPhotos, size = 60.dp, contentScale = ContentScale.Fit)
                                Text("№$i · $path", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                                Text("🔍")
                            }
                        }
                    }
                } }
                item { ProductSection("Локальная заметка") {
                    AutoSaveField(p.localNote, "Не синхронизируется", { app.container.productEditor.setLocalNote(uuid, it) }, Modifier.fillMaxWidth(), singleLine = false, minLines = 2, saveKey = "$uuid:localNote")
                } }
            }
        }
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { scope.launch { app.container.productEditor.addToQueue(uuid) } }, modifier = Modifier.weight(1f)) { Text("В очередь") }
                Button(onClick = {
                    scope.launch {
                        if (p.workflowState == "READY") {
                            focusManager.clearFocus(force = true)
                            runCatching { AutoSaveCoordinator.awaitPending("$uuid:") }
                                .onSuccess { onDone() }
                                .onFailure { uiMessage = it.message ?: "Не все поля сохранились" }
                        } else {
                            focusManager.clearFocus(force = true)
                            runCatching {
                                AutoSaveCoordinator.awaitPending("$uuid:")
                                app.container.productEditor.setWorkflowState(uuid, "READY")
                            }
                                .onFailure {
                                    val text = it.message ?: "Не удалось отметить товар готовым"
                                    if (text.contains("Donor Checklist", ignoreCase = true)) showDonorOverride = true else uiMessage = text
                                }
                        }
                    }
                }, modifier = Modifier.weight(1f)) { Text(if (p.workflowState == "READY") "✓ Готово" else "Отметить товар готовым") }
            }
            if (p.productId == null) {
                OutlinedButton(
                    onClick = { showDeleteLocalProduct = true },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Удалить локальный товар") }
            }
        }
    }

    if (showCategories) {
        AlertDialog(
            onDismissRequest = { showCategories = false },
            title = { Text("Категории") },
            text = {
                LazyColumn(Modifier.heightIn(max = 480.dp)) {
                    item {
                        TextButton(onClick = { showCategories = false; showNewCategory = true }) { Text("＋ Новая категория") }
                        HorizontalDivider()
                    }
                    itemsIndexed(categories) { _, c ->
                        val checked = c.categoryId in selectedCategories
                        Row(Modifier.fillMaxWidth().clickable {
                            val next = selectedCategories.toMutableSet().apply { if (checked) remove(c.categoryId) else add(c.categoryId) }.sorted()
                            scope.launch { app.container.productEditor.updateField(uuid, "categories", JsonArray(next.map(::JsonPrimitive))) }
                        }.padding(vertical = 6.dp)) {
                            Checkbox(checked = checked, onCheckedChange = null)
                            Text(c.name, modifier = Modifier.padding(top = 12.dp))
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showCategories = false }) { Text("Готово") } }
        )
    }

    if (showNewManufacturer) {
        AlertDialog(
            onDismissRequest = { showNewManufacturer = false },
            title = { Text("Новый производитель") },
            text = { OutlinedTextField(newManufacturerName, { newManufacturerName = it }, label = { Text("Название") }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        runCatching { app.container.references.createManufacturer(newManufacturerName) }
                            .onSuccess { created ->
                                app.container.productEditor.updateField(uuid, "product.manufacturer_id", JsonPrimitive(created.manufacturerId))
                                newManufacturerName = ""; showNewManufacturer = false
                            }.onFailure { uiMessage = it.message }
                    }
                }) { Text("Создать и выбрать") }
            },
            dismissButton = { TextButton(onClick = { showNewManufacturer = false }) { Text("Отмена") } }
        )
    }

    if (showNewCategory) {
        AlertDialog(
            onDismissRequest = { showNewCategory = false },
            title = { Text("Новая категория") },
            text = { OutlinedTextField(newCategoryName, { newCategoryName = it }, label = { Text("Название") }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        runCatching { app.container.references.createCategory(newCategoryName, primaryLanguageId = primaryLanguageId) }
                            .onSuccess { created ->
                                val next = (selectedCategories + created.categoryId).sorted()
                                app.container.productEditor.updateField(uuid, "categories", JsonArray(next.map(::JsonPrimitive)))
                                newCategoryName = ""; showNewCategory = false
                            }.onFailure { uiMessage = it.message }
                    }
                }) { Text("Создать и выбрать") }
            },
            dismissButton = { TextButton(onClick = { showNewCategory = false }) { Text("Отмена") } }
        )
    }

    if (showMainImage && (localMainPhoto != null || mainImage.isNotBlank() || !previewPhotoPath.isNullOrBlank())) {
        ProductPhotoZoomDialog(
            remotePath = previewPhotoPath ?: mainImage,
            localPhotos = localPhotos,
            onDismiss = { showMainImage = false; previewPhotoPath = null },
            onEdit = { showMainImage = false; previewPhotoPath = null; onPhotos(uuid) },
        )
    }
    if (confirmCopyNameToDescription) {
        AlertDialog(
            onDismissRequest = { confirmCopyNameToDescription = false },
            title = { Text("Заменить описание?") },
            text = { Text("Текущее HTML-описание будет заменено текстом из названия товара на выбранном языке.") },
            confirmButton = { TextButton(onClick = {
                confirmCopyNameToDescription = false
                scope.launch { app.container.productEditor.updateField(uuid, "descriptions.$activeLanguageId.description", JsonPrimitive(liveDescriptionName)) }
            }) { Text("Заменить") } },
            dismissButton = { TextButton(onClick = { confirmCopyNameToDescription = false }) { Text("Отмена") } },
        )
    }

    if (showDonorOverride) {
        AlertDialog(
            onDismissRequest = { showDonorOverride = false },
            title = { Text("Пропустить Donor Checklist?") },
            text = { Text("Товар можно отметить готовым несмотря на ошибки сравнения с донором. Обычные ошибки карточки всё равно останутся обязательными.") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        runCatching { app.container.productEditor.setWorkflowState(uuid, "READY", ignoreDonorChecklistErrors = true) }
                            .onSuccess { showDonorOverride = false }
                            .onFailure { uiMessage = it.message ?: "Не удалось отметить товар готовым"; showDonorOverride = false }
                    }
                }) { Text("Пропустить и отметить готовым") }
            },
            dismissButton = { TextButton(onClick = { showDonorOverride = false }) { Text("Отмена") } }
        )
    }

    if (showUndoConfirm && undoPoint != null) {
        val latest = undoPoint
        AlertDialog(
            onDismissRequest = { if (!undoBusy) showUndoConfirm = false },
            title = { Text(if (undoIsRestoreSafety) "Отменить выполненный откат?" else "Отменить последнее действие?") },
            text = {
                Text(
                    if (undoIsRestoreSafety) {
                        "Будет возвращено состояние товара, которое было непосредственно перед последним откатом. " +
                            "Сайт не меняется автоматически: при необходимости изменения отправятся только через обычный Sync."
                    } else {
                        "Товар вернётся к состоянию ДО действия «${latest.summary}». " +
                            "Если это состояние было до уже выполненного Sync, сайт сейчас не изменится — откат станет обычным локальным изменением для следующего Sync."
                    }
                )
            },
            confirmButton = {
                Button(enabled = !undoBusy, onClick = {
                    undoBusy = true
                    scope.launch {
                        runCatching { app.container.undo.restore(latest.id) }
                            .onSuccess { result ->
                                uiMessage = if (result.restoredAfterSync)
                                    "Состояние восстановлено локально. Сайт не изменён; выполните Sync, если хотите применить откат на сайте."
                                else if (undoIsRestoreSafety) "Откат отменён; предыдущее состояние возвращено."
                                else "Последнее действие отменено."
                            }
                            .onFailure { uiMessage = it.message ?: "Не удалось выполнить откат" }
                        undoBusy = false
                        showUndoConfirm = false
                    }
                }) { Text(if (undoBusy) "…" else if (undoIsRestoreSafety) "Отменить откат" else "Отменить действие") }
            },
            dismissButton = { TextButton(enabled = !undoBusy, onClick = { showUndoConfirm = false }) { Text("Не отменять") } },
        )
    }

    if (showDeleteLocalProduct) {
        AlertDialog(
            onDismissRequest = { if (!deleteBusy) showDeleteLocalProduct = false },
            title = { Text("Удалить локальный товар?") },
            text = { Text("Товар, его локальная очередь, история отката и служебные копии HandelDesk будут удалены без возможности восстановления. Оригиналы из рабочей папки возвращаются в 01_Eingang. На сайте это действие ничего не удаляет.") },
            confirmButton = {
                TextButton(
                    enabled = !deleteBusy,
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
                    onClick = {
                        scope.launch {
                            deleteBusy = true
                            runCatching { app.container.maintenance.deleteLocalProduct(uuid) }
                                .onSuccess { showDeleteLocalProduct = false; onBack() }
                                .onFailure { uiMessage = it.message ?: "Не удалось удалить локальный товар" }
                            deleteBusy = false
                        }
                    }
                ) { Text(if (deleteBusy) "…" else "Удалить локально") }
            },
            dismissButton = { TextButton(enabled = !deleteBusy, onClick = { showDeleteLocalProduct = false }) { Text("Отмена") } },
        )
    }

    if (uiMessage != null) {
        AlertDialog(
            onDismissRequest = { uiMessage = null },
            title = { Text("HandelDesk") },
            text = { Text(uiMessage.orEmpty()) },
            confirmButton = { TextButton(onClick = { uiMessage = null }) { Text("OK") } }
        )
    }
}

@Composable
private fun ProductSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    var open by rememberSaveable(title) { mutableStateOf(title.startsWith("General")) }
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(Modifier.fillMaxWidth().clickable { open = !open }, horizontalArrangement = Arrangement.SpaceBetween) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(if (open) "⌃" else "⌄")
            }
            if (open) { Spacer(Modifier.height(8.dp)); Column(verticalArrangement = Arrangement.spacedBy(8.dp), content = content) }
        }
    }
}

@Composable
private fun OptionsEditor(
    uuid: String,
    payload: JsonObject,
    app: HandelDeskApp,
    scope: kotlinx.coroutines.CoroutineScope,
    labels: BridgeSchemaLabels,
) {
    val options = (payload["options"] as? JsonArray).orEmpty()
    var showAddOption by remember { mutableStateOf(false) }
    var addValueForOptionIndex by remember { mutableStateOf<Int?>(null) }

    fun save(next: List<JsonElement>) {
        scope.launch { app.container.productEditor.updateField(uuid, "options", JsonArray(next)) }
    }

    val usedOptionIds = options.mapNotNull { it.jsonObject["option_id"]?.jsonPrimitive?.contentOrNull }.toSet()
    val availableOptions = labels.optionDefinitions.filter { it.id !in usedOptionIds }

    if (labels.optionDefinitions.isEmpty()) {
        Text(
            "Справочник опций ещё не загружен. Выполни синхронизацию/обновление Offline API, чтобы выбирать опции OpenCart по названию.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }

    if (options.isEmpty()) {
        Text("Опций нет", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }

    options.forEachIndexed { oi, optElement ->
        val option = optElement.jsonObject
        val optionId = option["option_id"]?.jsonPrimitive?.contentOrNull.orEmpty()
        val definition = labels.optionDefinition(optionId)
        val values = (option["values"] as? JsonArray).orEmpty()
        val required = option["required"]?.jsonPrimitive?.intOrNull == 1

        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text(labels.option(optionId), style = MaterialTheme.typography.titleSmall)
                        if (!definition?.type.isNullOrBlank()) {
                            Text(definition?.type.orEmpty(), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    TextButton(onClick = {
                        val next = options.toMutableList().also { it.removeAt(oi) }
                        save(next)
                    }) { Text("Удалить", color = MaterialTheme.colorScheme.error) }
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Обязательная", modifier = Modifier.padding(top = 10.dp))
                    Switch(
                        checked = required,
                        onCheckedChange = { checked ->
                            val updated = JsonObject(option.toMutableMap().apply { put("required", JsonPrimitive(if (checked) 1 else 0)) })
                            val next = options.toMutableList(); next[oi] = updated
                            save(next)
                        },
                    )
                }

                val hasPredefinedValues = definition?.values?.isNotEmpty() == true || values.isNotEmpty()
                if (hasPredefinedValues) {
                    values.forEachIndexed { vi, valueElement ->
                        val value = valueElement.jsonObject
                        val valueId = value["option_value_id"]?.jsonPrimitive?.contentOrNull.orEmpty()
                        val q = value["quantity"]?.jsonPrimitive?.intOrNull ?: 0
                        val price = value["price"]?.jsonPrimitive?.contentOrNull.orEmpty().ifBlank { "0.0000" }
                        val pricePrefix = value["price_prefix"]?.jsonPrimitive?.contentOrNull.orEmpty().ifBlank { "+" }

                        Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = MaterialTheme.shapes.medium) {
                            Column(Modifier.padding(9.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(labels.optionValue(valueId), style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                                    TextButton(onClick = {
                                        val newValues = values.toMutableList().also { it.removeAt(vi) }
                                        val updated = JsonObject(option.toMutableMap().apply { put("values", JsonArray(newValues)) })
                                        val next = options.toMutableList(); next[oi] = updated
                                        save(next)
                                    }) { Text("×", color = MaterialTheme.colorScheme.error) }
                                }
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    OutlinedButton(onClick = {
                                        val newValues = values.toMutableList()
                                        newValues[vi] = JsonObject(value.toMutableMap().apply { put("quantity", JsonPrimitive((q - 1).coerceAtLeast(0))) })
                                        val updated = JsonObject(option.toMutableMap().apply { put("values", JsonArray(newValues)) })
                                        val next = options.toMutableList(); next[oi] = updated
                                        save(next)
                                    }) { Text("−") }
                                    Text("$q шт.", modifier = Modifier.padding(top = 12.dp))
                                    OutlinedButton(onClick = {
                                        val newValues = values.toMutableList()
                                        newValues[vi] = JsonObject(value.toMutableMap().apply { put("quantity", JsonPrimitive(q + 1)) })
                                        val updated = JsonObject(option.toMutableMap().apply { put("values", JsonArray(newValues)) })
                                        val next = options.toMutableList(); next[oi] = updated
                                        save(next)
                                    }) { Text("+") }
                                }
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    OutlinedButton(onClick = {
                                        val nextPrefix = if (pricePrefix == "-") "+" else "-"
                                        val newValues = values.toMutableList()
                                        newValues[vi] = JsonObject(value.toMutableMap().apply { put("price_prefix", JsonPrimitive(nextPrefix)) })
                                        val updated = JsonObject(option.toMutableMap().apply { put("values", JsonArray(newValues)) })
                                        val next = options.toMutableList(); next[oi] = updated
                                        save(next)
                                    }) { Text(pricePrefix) }
                                    AutoSaveField(
                                        value = price,
                                        label = "Наценка / скидка",
                                        onSave = { raw ->
                                            val clean = raw.trim().replace(',', '.').ifBlank { "0" }
                                            app.container.productEditor.updateOptionCell(uuid, optionId, valueId, "price", clean)
                                        },
                                        modifier = Modifier.weight(1f),
                                        saveKey = "$uuid:options.$optionId.$valueId.price",
                                    )
                                }
                            }
                        }
                    }

                    val selectedValueIds = values.mapNotNull { it.jsonObject["option_value_id"]?.jsonPrimitive?.contentOrNull }.toSet()
                    val canAddValue = definition?.values.orEmpty().any { it.id !in selectedValueIds }
                    OutlinedButton(
                        onClick = { addValueForOptionIndex = oi },
                        enabled = canAddValue,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text(if (canAddValue) "＋ Добавить значение" else "Все значения уже добавлены") }
                } else {
                    AutoSaveField(
                        value = option["value"]?.jsonPrimitive?.contentOrNull.orEmpty(),
                        label = "Значение",
                        onSave = { raw ->
                            app.container.productEditor.updateOptionCell(uuid, optionId, null, "value", raw)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = definition?.type != "textarea",
                        minLines = if (definition?.type == "textarea") 3 else 1,
                        saveKey = "$uuid:options.$optionId.value",
                    )
                }
            }
        }
    }

    Button(
        onClick = { showAddOption = true },
        enabled = availableOptions.isNotEmpty(),
        modifier = Modifier.fillMaxWidth(),
    ) { Text(if (availableOptions.isNotEmpty()) "＋ Добавить опцию" else "Нет доступных опций") }

    if (showAddOption) {
        AlertDialog(
            onDismissRequest = { showAddOption = false },
            title = { Text("Добавить опцию") },
            text = {
                if (availableOptions.isEmpty()) {
                    Text("Все доступные опции уже добавлены.")
                } else {
                    LazyColumn(Modifier.heightIn(max = 460.dp)) {
                        items(availableOptions, key = { it.id }) { definition ->
                            Row(
                                Modifier.fillMaxWidth().clickable {
                                    val newOption = buildJsonObject {
                                        put("option_id", optionIdJson(definition.id))
                                        put("value", "")
                                        put("required", 0)
                                        put("values", buildJsonArray {})
                                    }
                                    save(options.toMutableList().apply { add(newOption) })
                                    showAddOption = false
                                }.padding(vertical = 10.dp),
                            ) {
                                Column {
                                    Text(definition.name, style = MaterialTheme.typography.bodyLarge)
                                    Text(definition.type, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            HorizontalDivider()
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showAddOption = false }) { Text("Закрыть") } },
        )
    }

    addValueForOptionIndex?.let { optionIndex ->
        val option = options.getOrNull(optionIndex)?.jsonObject
        val definition = option?.get("option_id")?.jsonPrimitive?.contentOrNull?.let(labels::optionDefinition)
        val currentValues = (option?.get("values") as? JsonArray).orEmpty()
        val selectedIds = currentValues.mapNotNull { it.jsonObject["option_value_id"]?.jsonPrimitive?.contentOrNull }.toSet()
        val availableValues = definition?.values.orEmpty().filter { it.id !in selectedIds }
        AlertDialog(
            onDismissRequest = { addValueForOptionIndex = null },
            title = { Text("Добавить значение") },
            text = {
                if (availableValues.isEmpty()) {
                    Text("Свободных значений нет.")
                } else {
                    LazyColumn(Modifier.heightIn(max = 460.dp)) {
                        items(availableValues, key = { it.id }) { valueDefinition ->
                            Row(
                                Modifier.fillMaxWidth().clickable {
                                    if (option != null) {
                                        val newValue = buildJsonObject {
                                            put("option_value_id", optionIdJson(valueDefinition.id))
                                            put("quantity", 0)
                                            put("subtract", 1)
                                            put("price", "0.0000")
                                            put("price_prefix", "+")
                                            put("points", 0)
                                            put("points_prefix", "+")
                                            put("weight", "0.00000000")
                                            put("weight_prefix", "+")
                                        }
                                        val newValues = currentValues.toMutableList().apply { add(newValue) }
                                        val updated = JsonObject(option.toMutableMap().apply { put("values", JsonArray(newValues)) })
                                        val next = options.toMutableList(); next[optionIndex] = updated
                                        save(next)
                                    }
                                    addValueForOptionIndex = null
                                }.padding(vertical = 10.dp),
                            ) { Text(valueDefinition.name) }
                            HorizontalDivider()
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { addValueForOptionIndex = null }) { Text("Закрыть") } },
        )
    }
}

private fun optionIdJson(id: String): JsonPrimitive = id.toIntOrNull()?.let(::JsonPrimitive) ?: JsonPrimitive(id)

@Composable
private fun SeoEditor(uuid: String, payload: JsonObject, app: HandelDeskApp, labels: BridgeSchemaLabels) {
    val rows = (payload["seo_urls"] as? JsonArray).orEmpty()
    if (rows.isEmpty()) { Text("SEO URL отсутствует"); return }
    rows.forEachIndexed { index, rowElement ->
        val row = rowElement.jsonObject
        AutoSaveField(
            value = row["keyword"]?.jsonPrimitive?.contentOrNull.orEmpty(),
            label = "SEO · ${labels.language(row["language_id"]?.jsonPrimitive?.contentOrNull)}",
            onSave = { raw -> app.container.productEditor.updateField(uuid, "seo_urls.$index.keyword", JsonPrimitive(HandelthekeSeoPolicy.slug(raw))) },
            modifier = Modifier.fillMaxWidth(),
            saveKey = "$uuid:seo_urls.$index.keyword"
        )
    }
}
