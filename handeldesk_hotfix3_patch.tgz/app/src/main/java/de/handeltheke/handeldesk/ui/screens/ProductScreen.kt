package de.handeltheke.handeldesk.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import de.handeltheke.handeldesk.HandelDeskApp
import de.handeltheke.handeldesk.core.HandelthekeSeoPolicy
import de.handeltheke.handeldesk.data.local.ProductEntity
import de.handeltheke.handeldesk.domain.*
import de.handeltheke.handeldesk.ui.ScreenHeader
import de.handeltheke.handeldesk.ui.components.AutoSaveField
import de.handeltheke.handeldesk.ui.components.CachedProductImage
import de.handeltheke.handeldesk.ui.components.LocalFileImage
import de.handeltheke.handeldesk.ui.components.ProductThumbnail
import kotlinx.coroutines.launch
import kotlinx.serialization.json.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductScreen(uuid: String, onBack: () -> Unit, onReplace: (String) -> Unit, onPhotos: (String) -> Unit, onHistory: (String) -> Unit) {
    val app = LocalContext.current.applicationContext as HandelDeskApp
    val product by app.container.db.products().observe(uuid).collectAsState(initial = null)
    val categories by app.container.db.references().observeCategories().collectAsState(initial = emptyList())
    val manufacturers by app.container.db.references().observeManufacturers().collectAsState(initial = emptyList())
    val localPhotos by app.container.db.photos().observeForProduct(uuid).collectAsState(initial = emptyList())
    val historyPoints by app.container.db.history().observeForProduct(uuid, 20).collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var primaryLanguageId by remember { mutableStateOf("1") }
    var schemaLabels by remember { mutableStateOf(BridgeSchemaLabels()) }
    var showAll by rememberSaveable { mutableStateOf(false) }
    var showCategories by remember { mutableStateOf(false) }
    var manufacturerMenu by remember { mutableStateOf(false) }
    var showNewManufacturer by remember { mutableStateOf(false) }
    var showNewCategory by remember { mutableStateOf(false) }
    var newManufacturerName by rememberSaveable { mutableStateOf("") }
    var newCategoryName by rememberSaveable { mutableStateOf("") }
    var uiMessage by remember { mutableStateOf<String?>(null) }
    var donor by remember { mutableStateOf<ProductEntity?>(null) }
    var selectedLanguageId by rememberSaveable { mutableStateOf("") }
    var showMainImage by remember { mutableStateOf(false) }
    var showDonorOverride by remember { mutableStateOf(false) }
    var showDeleteLocalProduct by remember { mutableStateOf(false) }
    var deleteBusy by remember { mutableStateOf(false) }
    var showUndoConfirm by remember { mutableStateOf(false) }
    var undoBusy by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        primaryLanguageId = app.container.db.settings().get("primary_language_id") ?: "1"
        schemaLabels = BridgeSchemaLabels.fromSchemaJson(app.container.db.settings().get("bridge_schema"))
    }
    LaunchedEffect(product?.sourceProductId) {
        donor = product?.sourceProductId?.let { app.container.db.products().getByProductId(it) }
    }

    val p = product
    if (p == null) {
        Column { ScreenHeader("Товар", onBack = onBack); LinearProgressIndicator(Modifier.fillMaxWidth()) }
        return
    }
    val payload = remember(p.localJson) { JsonTools.objectOf(p.localJson) }
    val core = payload["product"]?.jsonObject ?: buildJsonObject {}
    val descriptions = payload["descriptions"]?.jsonObject ?: buildJsonObject {}
    LaunchedEffect(primaryLanguageId, descriptions.keys.joinToString("|")) {
        val fallback = if (primaryLanguageId in descriptions.keys) primaryLanguageId else descriptions.keys.firstOrNull().orEmpty()
        if (selectedLanguageId.isBlank() || selectedLanguageId !in descriptions.keys) selectedLanguageId = fallback
    }
    val activeLanguageId = selectedLanguageId.ifBlank { primaryLanguageId }
    val desc = descriptions[activeLanguageId]?.jsonObject ?: descriptions.values.firstOrNull()?.jsonObject ?: buildJsonObject {}
    val mainImage = core["image"]?.jsonPrimitive?.contentOrNull.orEmpty()
    val localMainPhoto = localPhotos.firstOrNull {
        it.remotePath == mainImage && (it.processedPath.isNotBlank() || it.originalPath.isNotBlank())
    } ?: if (mainImage.isBlank()) localPhotos.firstOrNull { it.isMain } else null
    val selectedCategories = (payload["categories"] as? JsonArray).orEmpty().mapNotNull { it.jsonPrimitive.intOrNull }.toSet()
    val manufacturerName = manufacturers.firstOrNull { it.manufacturerId == p.manufacturerId }?.name ?: "—"
    val validation = remember(p.localJson, primaryLanguageId) { ValidationEngine.validate(p, primaryLanguageId) }
    val checklist = remember(p.localJson, donor?.localJson) { donor?.let { ValidationEngine.donorChecklist(p, it) } }
    val undoPoint = historyPoints.firstOrNull { it.actionType != "sync_checkpoint" }
    val undoIsRestoreSafety = undoPoint?.actionType == "history_restore"

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(p.name.ifBlank { "Новый товар" }, "${p.productId?.let { "#$it" } ?: "LOCAL"} · ${p.state} · ${p.workflowState}", onBack)
        Surface(color = MaterialTheme.colorScheme.surfaceVariant) {
            Text(
                "✓ Сохранено локально ${SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(p.updatedAt))} · автосохранение 0,5 с",
                modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 7.dp),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (undoPoint != null) item {
                val latest = undoPoint
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("История и откат", style = MaterialTheme.typography.titleMedium)
                        Text(
                            if (undoIsRestoreSafety) "Последним действием был откат. Можно вернуть состояние, которое было непосредственно перед ним."
                            else "Можно вернуть состояние до: ${latest.summary}",
                            style = MaterialTheme.typography.bodySmall,
                        )
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilledTonalButton(
                                enabled = !undoBusy,
                                onClick = { showUndoConfirm = true },
                                modifier = Modifier.weight(1f),
                            ) { Text(if (undoIsRestoreSafety) "↪ Отменить откат" else "↩ Отменить последнее") }
                            OutlinedButton(onClick = { onHistory(uuid) }, modifier = Modifier.weight(1f)) { Text("История") }
                        }
                    }
                }
            }
            item {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (localMainPhoto != null || mainImage.isNotBlank()) {
                            ProductThumbnail(
                                mainImage,
                                localPhotos,
                                modifier = Modifier.fillMaxWidth().clickable { showMainImage = true },
                                size = 160.dp,
                                contentScale = ContentScale.Fit,
                            )
                            Text(if (localMainPhoto != null) "Локальное фото · нажмите, чтобы открыть" else "Нажмите на фото, чтобы открыть", style = MaterialTheme.typography.bodySmall)
                        }
                        AutoSaveField(
                            value = core["model"]?.jsonPrimitive?.contentOrNull.orEmpty(), label = "Model",
                            onSave = { app.container.productEditor.updateField(uuid, "product.model", JsonPrimitive(it)) }, modifier = Modifier.fillMaxWidth()
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            AutoSaveField(
                                value = core["price"]?.jsonPrimitive?.contentOrNull.orEmpty(), label = "Цена",
                                onSave = { app.container.productEditor.updateField(uuid, "product.price", JsonPrimitive(it.replace(',', '.'))) }, modifier = Modifier.weight(1f)
                            )
                            Column(Modifier.weight(1f)) {
                                Text("Остаток", style = MaterialTheme.typography.labelMedium)
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    OutlinedButton(onClick = { scope.launch { app.container.productEditor.adjustQuantity(uuid, -1) } }) { Text("−1") }
                                    Text(p.quantity.toString(), modifier = Modifier.padding(top = 12.dp))
                                    OutlinedButton(onClick = { scope.launch { app.container.productEditor.adjustQuantity(uuid, +1) } }) { Text("+1") }
                                    OutlinedButton(onClick = { scope.launch { app.container.productEditor.adjustQuantity(uuid, +2) } }) { Text("+2") }
                                }
                            }
                        }
                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Text("Статус", modifier = Modifier.weight(1f))
                            Switch(checked = p.status == 1, onCheckedChange = { checked -> scope.launch { app.container.productEditor.updateField(uuid, "product.status", JsonPrimitive(if (checked) 1 else 0)) } })
                        }
                        ExposedDropdownMenuBox(expanded = manufacturerMenu, onExpandedChange = { manufacturerMenu = it }) {
                            OutlinedTextField(value = manufacturerName, onValueChange = {}, readOnly = true, label = { Text("Производитель") }, modifier = Modifier.menuAnchor().fillMaxWidth())
                            ExposedDropdownMenu(expanded = manufacturerMenu, onDismissRequest = { manufacturerMenu = false }) {
                                DropdownMenuItem(text = { Text("＋ Новый производитель") }, onClick = { manufacturerMenu = false; showNewManufacturer = true })
                                HorizontalDivider()
                                DropdownMenuItem(text = { Text("—") }, onClick = { manufacturerMenu = false; scope.launch { app.container.productEditor.updateField(uuid, "product.manufacturer_id", JsonPrimitive(0)) } })
                                manufacturers.forEach { m ->
                                    DropdownMenuItem(text = { Text(m.name) }, onClick = { manufacturerMenu = false; scope.launch { app.container.productEditor.updateField(uuid, "product.manufacturer_id", JsonPrimitive(m.manufacturerId)) } })
                                }
                            }
                        }
                        OutlinedButton(onClick = { showCategories = true }, modifier = Modifier.fillMaxWidth()) {
                            Text("Категории: ${selectedCategories.size} · ${categories.filter { it.categoryId in selectedCategories }.take(3).joinToString { it.name }}")
                        }
                        if (p.sourceProductId != null) Button(onClick = { onReplace(uuid) }, modifier = Modifier.fillMaxWidth()) { Text("⚡ Быстрая замена по донору") }
                    }
                }
            }

            if (checklist?.applicable == true) item {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("Donor Checklist", style = MaterialTheme.typography.titleMedium)
                        checklist.items.forEach { item -> Text("${when(item.status){"ok"->"✓";"error"->"✕";else->"⚠"}} ${item.label}${if(item.message.isNotBlank()) " — ${item.message}" else ""}") }
                        if (!checklist.ready) {
                            OutlinedButton(onClick = { showDonorOverride = true }, modifier = Modifier.fillMaxWidth()) {
                                Text("Пропустить ошибки Donor Checklist")
                            }
                        }
                    }
                }
            }

            if (validation.isNotEmpty()) item {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("Проверка", style = MaterialTheme.typography.titleMedium)
                        validation.forEach { issue -> Text("${if(issue.severity==Severity.ERROR) "✕" else "⚠"} ${issue.message}") }
                    }
                }
            }

            item {
                TextButton(onClick = { showAll = !showAll }, modifier = Modifier.fillMaxWidth()) { Text(if (showAll) "Скрыть полную карточку" else "ПОЛНАЯ КАРТОЧКА") }
            }

            if (showAll) {
                item { ProductSection("General · Контент") {
                    if (descriptions.isNotEmpty()) {
                        Text("Языки", style = MaterialTheme.typography.labelLarge)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            descriptions.keys.sortedBy { it.toIntOrNull() ?: Int.MAX_VALUE }.forEach { lang ->
                                FilterChip(
                                    selected = activeLanguageId == lang,
                                    onClick = { selectedLanguageId = lang },
                                    label = { Text(schemaLabels.language(lang)) }
                                )
                            }
                        }
                    }
                    AutoSaveField(desc["name"]?.jsonPrimitive?.contentOrNull.orEmpty(), "Название", { app.container.productEditor.updateField(uuid, "descriptions.$activeLanguageId.name", JsonPrimitive(it)) }, Modifier.fillMaxWidth())
                    AutoSaveField(desc["description"]?.jsonPrimitive?.contentOrNull.orEmpty(), "Description (HTML)", { app.container.productEditor.updateField(uuid, "descriptions.$activeLanguageId.description", JsonPrimitive(it)) }, Modifier.fillMaxWidth(), singleLine = false, minLines = 5)
                    AutoSaveField(desc["meta_title"]?.jsonPrimitive?.contentOrNull.orEmpty(), "Meta Title", { app.container.productEditor.updateField(uuid, "descriptions.$activeLanguageId.meta_title", JsonPrimitive(it)) }, Modifier.fillMaxWidth())
                    AutoSaveField(desc["meta_description"]?.jsonPrimitive?.contentOrNull.orEmpty(), "Meta Description", { app.container.productEditor.updateField(uuid, "descriptions.$activeLanguageId.meta_description", JsonPrimitive(it)) }, Modifier.fillMaxWidth(), singleLine = false, minLines = 2)
                    AutoSaveField(desc["meta_keyword"]?.jsonPrimitive?.contentOrNull.orEmpty(), "Meta Keywords", { app.container.productEditor.updateField(uuid, "descriptions.$activeLanguageId.meta_keyword", JsonPrimitive(it)) }, Modifier.fillMaxWidth())
                    AutoSaveField(desc["tag"]?.jsonPrimitive?.contentOrNull.orEmpty(), "Tags", { app.container.productEditor.updateField(uuid, "descriptions.$activeLanguageId.tag", JsonPrimitive(it)) }, Modifier.fillMaxWidth())
                } }
                item { ProductSection("Data · Данные") {
                    Text("Производитель: $manufacturerName", style = MaterialTheme.typography.bodyMedium)
                    listOf("sku" to "SKU", "upc" to "UPC", "ean" to "EAN", "jan" to "JAN", "isbn" to "ISBN", "mpn" to "MPN", "location" to "Location").forEach { (field,label) ->
                        AutoSaveField(core[field]?.jsonPrimitive?.contentOrNull.orEmpty(), label, { app.container.productEditor.updateField(uuid, "product.$field", JsonPrimitive(it)) }, Modifier.fillMaxWidth())
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AutoSaveField(
                            core["weight"]?.jsonPrimitive?.contentOrNull.orEmpty(),
                            "Вес",
                            { app.container.productEditor.updateField(uuid, "product.weight", JsonPrimitive(it.replace(',', '.'))) },
                            Modifier.weight(1f)
                        )
                        AutoSaveField(
                            core["weight_class_id"]?.jsonPrimitive?.contentOrNull.orEmpty(),
                            "ID ед. веса",
                            { app.container.productEditor.updateField(uuid, "product.weight_class_id", JsonPrimitive(it.toIntOrNull() ?: 0)) },
                            Modifier.weight(1f)
                        )
                    }
                } }
                item { ProductSection("Options · Опции") { OptionsEditor(uuid, payload, app, scope, schemaLabels) } }
                item { ProductSection("SEO URL") { SeoEditor(uuid, payload, app, schemaLabels) } }
                item { ProductSection("Изображения") {
                    Button(onClick = { onPhotos(uuid) }, modifier = Modifier.fillMaxWidth()) {
                        Text("📷 ФОТО НА ТЕЛЕФОНЕ · ${localPhotos.size}")
                    }
                    if (localPhotos.isNotEmpty()) {
                        val pendingPhotos = localPhotos.count { it.status != "ATTACHED" }
                        Text("Локально: ${localPhotos.size} · ожидают синхронизации: $pendingPhotos", style = MaterialTheme.typography.bodySmall)
                    }
                    Text("Главное: ${core["image"]?.jsonPrimitive?.contentOrNull.orEmpty().ifBlank { "—" }}")
                    val images = (payload["images"] as? JsonArray).orEmpty()
                    Text("Дополнительных: ${images.size} · №0 должен дублировать главное")
                    images.forEachIndexed { i, img ->
                        val path = img.jsonObject["image"]?.jsonPrimitive?.contentOrNull.orEmpty()
                        Text("№$i. $path${if (i == 0 && path == mainImage && mainImage.isNotBlank()) " · дубль главного" else ""}")
                    }
                } }
                item { ProductSection("Локальная заметка") {
                    AutoSaveField(p.localNote, "Не синхронизируется", { app.container.productEditor.setLocalNote(uuid, it) }, Modifier.fillMaxWidth(), singleLine = false, minLines = 2)
                } }
            }
        }
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { scope.launch { app.container.productEditor.addToQueue(uuid) } }, modifier = Modifier.weight(1f)) { Text("В очередь") }
                Button(onClick = {
                    scope.launch {
                        runCatching { app.container.productEditor.setWorkflowState(uuid, "READY") }
                            .onFailure {
                                val text = it.message ?: "Не удалось отметить товар готовым"
                                if (text.contains("Donor Checklist", ignoreCase = true)) showDonorOverride = true else uiMessage = text
                            }
                    }
                }, modifier = Modifier.weight(1f)) { Text(if (p.workflowState == "READY") "✓ Готов" else "Отметить готовым") }
            }
            if (p.productId == null) {
                OutlinedButton(
                    onClick = { showDeleteLocalProduct = true },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Удалить локальный товар") }
            }
        }
    }

    if (showCategories) {
        AlertDialog(
            onDismissRequest = { showCategories = false },
            title = { Text("Категории") },
            text = {
                LazyColumn(Modifier.heightIn(max = 480.dp)) {
                    item {
                        TextButton(onClick = { showCategories = false; showNewCategory = true }) { Text("＋ Новая категория") }
                        HorizontalDivider()
                    }
                    itemsIndexed(categories) { _, c ->
                        val checked = c.categoryId in selectedCategories
                        Row(Modifier.fillMaxWidth().clickable {
                            val next = selectedCategories.toMutableSet().apply { if (checked) remove(c.categoryId) else add(c.categoryId) }.sorted()
                            scope.launch { app.container.productEditor.updateField(uuid, "categories", JsonArray(next.map(::JsonPrimitive))) }
                        }.padding(vertical = 6.dp)) {
                            Checkbox(checked = checked, onCheckedChange = null)
                            Text(c.name, modifier = Modifier.padding(top = 12.dp))
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showCategories = false }) { Text("Готово") } }
        )
    }

    if (showNewManufacturer) {
        AlertDialog(
            onDismissRequest = { showNewManufacturer = false },
            title = { Text("Новый производитель") },
            text = { OutlinedTextField(newManufacturerName, { newManufacturerName = it }, label = { Text("Название") }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        runCatching { app.container.references.createManufacturer(newManufacturerName) }
                            .onSuccess { created ->
                                app.container.productEditor.updateField(uuid, "product.manufacturer_id", JsonPrimitive(created.manufacturerId))
                                newManufacturerName = ""; showNewManufacturer = false
                            }.onFailure { uiMessage = it.message }
                    }
                }) { Text("Создать и выбрать") }
            },
            dismissButton = { TextButton(onClick = { showNewManufacturer = false }) { Text("Отмена") } }
        )
    }

    if (showNewCategory) {
        AlertDialog(
            onDismissRequest = { showNewCategory = false },
            title = { Text("Новая категория") },
            text = { OutlinedTextField(newCategoryName, { newCategoryName = it }, label = { Text("Название") }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        runCatching { app.container.references.createCategory(newCategoryName, primaryLanguageId = primaryLanguageId) }
                            .onSuccess { created ->
                                val next = (selectedCategories + created.categoryId).sorted()
                                app.container.productEditor.updateField(uuid, "categories", JsonArray(next.map(::JsonPrimitive)))
                                newCategoryName = ""; showNewCategory = false
                            }.onFailure { uiMessage = it.message }
                    }
                }) { Text("Создать и выбрать") }
            },
            dismissButton = { TextButton(onClick = { showNewCategory = false }) { Text("Отмена") } }
        )
    }

    if (showMainImage && (localMainPhoto != null || mainImage.isNotBlank())) {
        AlertDialog(
            onDismissRequest = { showMainImage = false },
            title = { Text("Главное изображение") },
            text = {
                if (localMainPhoto != null) LocalFileImage(localMainPhoto.processedPath.ifBlank { localMainPhoto.originalPath }, modifier = Modifier.fillMaxWidth(), size = 320.dp, contentScale = ContentScale.Fit)
                else CachedProductImage(mainImage, modifier = Modifier.fillMaxWidth(), size = 320.dp, contentScale = ContentScale.Fit)
            },
            confirmButton = { TextButton(onClick = { showMainImage = false }) { Text("Закрыть") } }
        )
    }

    if (showDonorOverride) {
        AlertDialog(
            onDismissRequest = { showDonorOverride = false },
            title = { Text("Пропустить Donor Checklist?") },
            text = { Text("Товар можно отметить готовым несмотря на ошибки сравнения с донором. Обычные ошибки карточки всё равно останутся обязательными.") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        runCatching { app.container.productEditor.setWorkflowState(uuid, "READY", ignoreDonorChecklistErrors = true) }
                            .onSuccess { showDonorOverride = false }
                            .onFailure { uiMessage = it.message ?: "Не удалось отметить товар готовым"; showDonorOverride = false }
                    }
                }) { Text("Пропустить и отметить готовым") }
            },
            dismissButton = { TextButton(onClick = { showDonorOverride = false }) { Text("Отмена") } }
        )
    }

    if (showUndoConfirm && undoPoint != null) {
        val latest = undoPoint
        AlertDialog(
            onDismissRequest = { if (!undoBusy) showUndoConfirm = false },
            title = { Text(if (undoIsRestoreSafety) "Отменить выполненный откат?" else "Отменить последнее действие?") },
            text = {
                Text(
                    if (undoIsRestoreSafety) {
                        "Будет возвращено состояние товара, которое было непосредственно перед последним откатом. " +
                            "Сайт не меняется автоматически: при необходимости изменения отправятся только через обычный Sync."
                    } else {
                        "Товар вернётся к состоянию ДО действия «${latest.summary}». " +
                            "Если это состояние было до уже выполненного Sync, сайт сейчас не изменится — откат станет обычным локальным изменением для следующего Sync."
                    }
                )
            },
            confirmButton = {
                Button(enabled = !undoBusy, onClick = {
                    undoBusy = true
                    scope.launch {
                        runCatching { app.container.undo.restore(latest.id) }
                            .onSuccess { result ->
                                uiMessage = if (result.restoredAfterSync)
                                    "Состояние восстановлено локально. Сайт не изменён; выполните Sync, если хотите применить откат на сайте."
                                else if (undoIsRestoreSafety) "Откат отменён; предыдущее состояние возвращено."
                                else "Последнее действие отменено."
                            }
                            .onFailure { uiMessage = it.message ?: "Не удалось выполнить откат" }
                        undoBusy = false
                        showUndoConfirm = false
                    }
                }) { Text(if (undoBusy) "…" else if (undoIsRestoreSafety) "Отменить откат" else "Отменить действие") }
            },
            dismissButton = { TextButton(enabled = !undoBusy, onClick = { showUndoConfirm = false }) { Text("Не отменять") } },
        )
    }

    if (showDeleteLocalProduct) {
        AlertDialog(
            onDismissRequest = { if (!deleteBusy) showDeleteLocalProduct = false },
            title = { Text("Удалить локальный товар?") },
            text = { Text("Товар, его локальная очередь, история отката и служебные копии HandelDesk будут удалены без возможности восстановления. Оригиналы из рабочей папки возвращаются в 01_Eingang. На сайте это действие ничего не удаляет.") },
            confirmButton = {
                TextButton(
                    enabled = !deleteBusy,
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
                    onClick = {
                        scope.launch {
                            deleteBusy = true
                            runCatching { app.container.maintenance.deleteLocalProduct(uuid) }
                                .onSuccess { showDeleteLocalProduct = false; onBack() }
                                .onFailure { uiMessage = it.message ?: "Не удалось удалить локальный товар" }
                            deleteBusy = false
                        }
                    }
                ) { Text(if (deleteBusy) "…" else "Удалить локально") }
            },
            dismissButton = { TextButton(enabled = !deleteBusy, onClick = { showDeleteLocalProduct = false }) { Text("Отмена") } },
        )
    }

    if (uiMessage != null) {
        AlertDialog(
            onDismissRequest = { uiMessage = null },
            title = { Text("HandelDesk") },
            text = { Text(uiMessage.orEmpty()) },
            confirmButton = { TextButton(onClick = { uiMessage = null }) { Text("OK") } }
        )
    }
}

@Composable
private fun ProductSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    var open by rememberSaveable(title) { mutableStateOf(title.startsWith("General")) }
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(Modifier.fillMaxWidth().clickable { open = !open }, horizontalArrangement = Arrangement.SpaceBetween) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(if (open) "⌃" else "⌄")
            }
            if (open) { Spacer(Modifier.height(8.dp)); Column(verticalArrangement = Arrangement.spacedBy(8.dp), content = content) }
        }
    }
}

@Composable
private fun OptionsEditor(uuid: String, payload: JsonObject, app: HandelDeskApp, scope: kotlinx.coroutines.CoroutineScope, labels: BridgeSchemaLabels) {
    val options = (payload["options"] as? JsonArray).orEmpty()
    if (options.isEmpty()) { Text("Опций нет"); return }
    options.forEachIndexed { oi, optElement ->
        val option = optElement.jsonObject
        Text(labels.option(option["option_id"]?.jsonPrimitive?.contentOrNull), style = MaterialTheme.typography.titleSmall)
        val values = (option["values"] as? JsonArray).orEmpty()
        values.forEachIndexed { vi, valueElement ->
            val value = valueElement.jsonObject
            val q = value["quantity"]?.jsonPrimitive?.intOrNull ?: 0
            val price = value["price"]?.jsonPrimitive?.contentOrNull.orEmpty()
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(labels.optionValue(value["option_value_id"]?.jsonPrimitive?.contentOrNull), modifier = Modifier.weight(1f))
                OutlinedButton(onClick = {
                    val newValues = values.toMutableList(); newValues[vi] = JsonObject(value.toMutableMap().apply { put("quantity", JsonPrimitive(q - 1)) })
                    val newOption = JsonObject(option.toMutableMap().apply { put("values", JsonArray(newValues)) })
                    val newOptions = options.toMutableList(); newOptions[oi] = newOption
                    scope.launch { app.container.productEditor.updateField(uuid, "options", JsonArray(newOptions)) }
                }) { Text("−") }
                Text(q.toString(), modifier = Modifier.padding(top = 12.dp))
                OutlinedButton(onClick = {
                    val newValues = values.toMutableList(); newValues[vi] = JsonObject(value.toMutableMap().apply { put("quantity", JsonPrimitive(q + 1)) })
                    val newOption = JsonObject(option.toMutableMap().apply { put("values", JsonArray(newValues)) })
                    val newOptions = options.toMutableList(); newOptions[oi] = newOption
                    scope.launch { app.container.productEditor.updateField(uuid, "options", JsonArray(newOptions)) }
                }) { Text("+") }
                Text("€ $price", modifier = Modifier.padding(top = 12.dp))
            }
        }
        HorizontalDivider()
    }
}

@Composable
private fun SeoEditor(uuid: String, payload: JsonObject, app: HandelDeskApp, labels: BridgeSchemaLabels) {
    val rows = (payload["seo_urls"] as? JsonArray).orEmpty()
    if (rows.isEmpty()) { Text("SEO URL отсутствует"); return }
    rows.forEachIndexed { index, rowElement ->
        val row = rowElement.jsonObject
        AutoSaveField(
            value = row["keyword"]?.jsonPrimitive?.contentOrNull.orEmpty(),
            label = "SEO · ${labels.language(row["language_id"]?.jsonPrimitive?.contentOrNull)}",
            onSave = { raw -> app.container.productEditor.updateField(uuid, "seo_urls.$index.keyword", JsonPrimitive(HandelthekeSeoPolicy.slug(raw))) },
            modifier = Modifier.fillMaxWidth()
        )
    }
}
