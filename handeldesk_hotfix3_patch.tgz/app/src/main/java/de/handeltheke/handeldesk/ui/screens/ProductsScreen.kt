package de.handeltheke.handeldesk.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import de.handeltheke.handeldesk.HandelDeskApp
import de.handeltheke.handeldesk.data.repo.ProductPage
import de.handeltheke.handeldesk.domain.JsonTools
import de.handeltheke.handeldesk.domain.ProductJson
import de.handeltheke.handeldesk.ui.ScreenHeader
import de.handeltheke.handeldesk.ui.components.EmptyState
import de.handeltheke.handeldesk.ui.components.ProductThumbnail
import de.handeltheke.handeldesk.ui.components.StatusBadge
import kotlinx.coroutines.delay
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

@Composable
fun ProductsScreen(onOpen: (String) -> Unit, onNew: () -> Unit) {
    val app = LocalContext.current.applicationContext as HandelDeskApp
    var query by rememberSaveable { mutableStateOf("") }
    var page by rememberSaveable { mutableIntStateOf(1) }
    var result by remember { mutableStateOf(ProductPage(emptyList(), 0, 1, 20, emptyList())) }
    var loading by remember { mutableStateOf(false) }
    var showHelp by rememberSaveable { mutableStateOf(false) }
    var primaryLanguageId by remember { mutableStateOf<String?>(null) }
    val localPhotos by app.container.db.photos().observeAll().collectAsState(initial = emptyList())
    val photoMap = remember(localPhotos) { localPhotos.groupBy { it.productUuid } }

    LaunchedEffect(Unit) { primaryLanguageId = app.container.db.settings().get("primary_language_id") }

    LaunchedEffect(query, page) {
        loading = true
        delay(120)
        result = app.container.productSearch.search(query, page = page, pageSize = 20)
        loading = false
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Товары", "${result.total} товаров · offline-first")
        Column(Modifier.padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it; page = 1 },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = MaterialTheme.shapes.large,
                label = { Text("Поиск") },
                placeholder = { Text("Название, Model, SKU, JAN…") },
                trailingIcon = { if (query.isNotBlank()) TextButton(onClick = { query = "" }) { Text("×") } },
            )
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { showHelp = !showHelp }) { Text(if (showHelp) "Скрыть операторы" else "Операторы поиска") }
                Spacer(Modifier.weight(1f))
                Button(onClick = onNew) { Text("＋ Новый") }
            }
            if (showHelp) {
                Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = MaterialTheme.shapes.medium) {
                    Text(
                        "\"точная фраза\" · -слово · Samsung OR LG · model: · sku: · jan: · ean: · mpn: · id:",
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(10.dp),
                    )
                }
            }
            if (result.errors.isNotEmpty()) Text(result.errors.joinToString(" · "), color = MaterialTheme.colorScheme.error)
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())

        if (!loading && result.items.isEmpty()) {
            EmptyState("Ничего не найдено", if (query.isBlank()) "Локальный каталог пока пуст." else "Попробуй изменить запрос.", Modifier.weight(1f))
        } else {
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                items(result.items, key = { it.uuid }) { item ->
                    ElevatedCard(Modifier.fillMaxWidth().clickable { onOpen(item.uuid) }) {
                        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            val imagePath = remember(item.localJson) {
                                JsonTools.objectOf(item.localJson)["product"]?.jsonObject?.get("image")?.jsonPrimitive?.contentOrNull.orEmpty()
                            }
                            ProductThumbnail(imagePath, photoMap[item.uuid].orEmpty(), size = 72.dp)
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                val fullName = remember(item.localJson, primaryLanguageId) {
                                    ProductJson.displayName(JsonTools.objectOf(item.localJson), primaryLanguageId)
                                        .ifBlank { item.name }
                                        .ifBlank { "Без названия" }
                                }
                                Text(fullName, style = MaterialTheme.typography.titleMedium)
                                Text(item.model.ifBlank { "Model —" }, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("${"%.2f".format(item.price)} €  ·  Bestand ${item.quantity}", style = MaterialTheme.typography.bodyMedium)
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    if (item.state != "SYNCED") StatusBadge(item.state, "warn")
                                    if (item.isDraft) StatusBadge("DRAFT", "primary")
                                }
                            }
                            Text("›", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }

        Surface(tonalElevation = 2.dp) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                val pages = if (result.total == 0L) 1 else ((result.total + result.pageSize - 1) / result.pageSize).toInt()
                OutlinedButton(onClick = { if (page > 1) page-- }, enabled = page > 1, contentPadding = PaddingValues(horizontal = 14.dp)) { Text("←") }
                Text("${result.page} / $pages", style = MaterialTheme.typography.labelLarge)
                OutlinedButton(onClick = { if (page < pages) page++ }, enabled = page < pages, contentPadding = PaddingValues(horizontal = 14.dp)) { Text("→") }
            }
        }
    }
}
