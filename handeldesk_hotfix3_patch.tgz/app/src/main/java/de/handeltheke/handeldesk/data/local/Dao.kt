package de.handeltheke.handeldesk.data.local

import androidx.room.*
import androidx.sqlite.db.SupportSQLiteQuery
import kotlinx.coroutines.flow.Flow


data class ProductJsonScanRow(
    val uuid: String,
    val localJson: String,
)

@Dao
interface ProductDao {
    @RawQuery(observedEntities = [ProductEntity::class])
    suspend fun rawList(query: SupportSQLiteQuery): List<ProductEntity>

    @RawQuery(observedEntities = [ProductEntity::class])
    suspend fun rawCount(query: SupportSQLiteQuery): Long

    @Query("SELECT * FROM products WHERE uuid=:uuid LIMIT 1")
    suspend fun get(uuid: String): ProductEntity?

    @Query("SELECT * FROM products WHERE uuid=:uuid LIMIT 1")
    fun observe(uuid: String): Flow<ProductEntity?>

    @Query("SELECT * FROM products WHERE productId=:id LIMIT 1")
    suspend fun getByProductId(id: Int): ProductEntity?

    @Query("SELECT * FROM products WHERE state!='SYNCED' ORDER BY updatedAt DESC")
    fun observeChanged(): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE productId IS NULL")
    suspend fun localNewProducts(): List<ProductEntity>

    @Query("SELECT COUNT(*) FROM products")
    fun observeTotalCount(): Flow<Long>

    @Query("SELECT COUNT(*) FROM products WHERE productId IS NOT NULL")
    suspend fun serverCount(): Int

    @Query("SELECT MAX(productId) FROM products WHERE productId IS NOT NULL")
    suspend fun maxServerProductId(): Int?

    @Query("SELECT productId FROM products WHERE productId IS NOT NULL")
    suspend fun serverProductIds(): List<Int>

    @Query("SELECT COUNT(*) FROM products WHERE state!='SYNCED'")
    fun observeChangedCount(): Flow<Long>

    @Query("SELECT COUNT(*) FROM products WHERE isDraft=1")
    fun observeDraftCount(): Flow<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(entity: ProductEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putAll(items: List<ProductEntity>)

    @Query("SELECT * FROM products")
    suspend fun all(): List<ProductEntity>

    @Query("SELECT uuid, localJson FROM products WHERE uuid > :afterUuid ORDER BY uuid LIMIT :limit")
    suspend fun jsonScanBatch(afterUuid: String, limit: Int): List<ProductJsonScanRow>

    @Query("SELECT COUNT(*) FROM products")
    suspend fun totalCount(): Int

    @Query("DELETE FROM products WHERE uuid=:uuid AND productId IS NULL")
    suspend fun deleteLocalDraft(uuid: String): Int

    @Query("DELETE FROM products WHERE productId=:id AND state='SYNCED'")
    suspend fun deleteServerSyncedById(id: Int): Int

    @Query("DELETE FROM products WHERE productId IS NOT NULL AND state='SYNCED'")
    suspend fun deleteAllServerSynced(): Int

    @Query("DELETE FROM products")
    suspend fun deleteAll(): Int
}

@Dao
interface ReferenceDao {
    @Query("SELECT * FROM categories ORDER BY name COLLATE NOCASE")
    fun observeCategories(): Flow<List<CategoryEntity>>

    @Query("SELECT * FROM categories ORDER BY name COLLATE NOCASE")
    suspend fun categories(): List<CategoryEntity>

    @Query("SELECT * FROM manufacturers ORDER BY name COLLATE NOCASE")
    fun observeManufacturers(): Flow<List<ManufacturerEntity>>

    @Query("SELECT * FROM manufacturers ORDER BY name COLLATE NOCASE")
    suspend fun manufacturers(): List<ManufacturerEntity>

    @Query("SELECT * FROM categories WHERE categoryId=:id LIMIT 1")
    suspend fun categoryById(id: Int): CategoryEntity?

    @Query("SELECT * FROM categories WHERE uuid=:uuid LIMIT 1")
    suspend fun categoryByUuid(uuid: String): CategoryEntity?

    @Query("SELECT * FROM manufacturers WHERE manufacturerId=:id LIMIT 1")
    suspend fun manufacturerById(id: Int): ManufacturerEntity?

    @Query("SELECT * FROM manufacturers WHERE uuid=:uuid LIMIT 1")
    suspend fun manufacturerByUuid(uuid: String): ManufacturerEntity?

    @Query("SELECT COALESCE(MIN(categoryId),0) FROM categories")
    suspend fun minCategoryId(): Int

    @Query("SELECT COALESCE(MIN(manufacturerId),0) FROM manufacturers")
    suspend fun minManufacturerId(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putCategories(items: List<CategoryEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putManufacturers(items: List<ManufacturerEntity>)
}

@Dao
interface ChangeDao {
    @Query("SELECT * FROM changes WHERE synced=0 ORDER BY id DESC")
    fun observePending(): Flow<List<ChangeEntity>>

    @Query("SELECT * FROM changes WHERE synced=0 AND included=1 ORDER BY id")
    suspend fun includedPending(): List<ChangeEntity>

    @Query("SELECT * FROM changes WHERE synced=0 AND entityType=:type AND entityUuid=:uuid AND fieldPath=:path AND operationType='set' LIMIT 1")
    suspend fun findSet(type: String, uuid: String, path: String): ChangeEntity?

    @Insert
    suspend fun insert(change: ChangeEntity): Long

    @Update
    suspend fun update(change: ChangeEntity)

    @Query("SELECT * FROM changes WHERE id=:id LIMIT 1")
    suspend fun get(id: Long): ChangeEntity?

    @Query("SELECT * FROM changes WHERE synced=0 AND entityType=:type AND entityUuid=:uuid ORDER BY createdAt,id")
    suspend fun pendingForEntity(type: String, uuid: String): List<ChangeEntity>

    @Query("DELETE FROM changes WHERE id=:id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM changes WHERE synced=0 AND entityType=:type AND entityUuid=:uuid")
    suspend fun deletePendingForEntity(type: String, uuid: String)

    @Query("DELETE FROM changes WHERE synced=0 AND entityType='product' AND entityUuid=:uuid AND fieldPath!='__create__'")
    suspend fun deleteRedundantNewProductChanges(uuid: String): Int

    @Query("UPDATE changes SET included=:included WHERE id=:id AND synced=0")
    suspend fun setIncluded(id: Long, included: Boolean)

    @Query("UPDATE changes SET synced=1 WHERE entityType=:type AND entityUuid=:uuid")
    suspend fun markEntitySynced(type: String, uuid: String)

    @Query("UPDATE changes SET synced=1 WHERE id IN (:ids)")
    suspend fun markIdsSynced(ids: List<Long>)

    @Query("SELECT COUNT(*) FROM changes WHERE synced=0")
    fun observeCount(): Flow<Long>

    @Query("SELECT COUNT(*) FROM changes WHERE synced=0 AND entityType=:type AND entityUuid=:uuid")
    suspend fun pendingCount(type: String, uuid: String): Int

    @Query("SELECT * FROM changes WHERE synced=0 ORDER BY id")
    suspend fun pending(): List<ChangeEntity>

    @Query("DELETE FROM changes")
    suspend fun deleteAll(): Int
}

@Dao
interface AuditDao {
    @Insert
    suspend fun insert(event: AuditEventEntity)

    @Query("SELECT * FROM audit_events ORDER BY id DESC LIMIT :limit")
    fun observeRecent(limit: Int = 200): Flow<List<AuditEventEntity>>
}


@Dao
interface ProductHistoryDao {
    @Query("SELECT * FROM product_history WHERE productUuid=:uuid ORDER BY id DESC LIMIT :limit")
    fun observeForProduct(uuid: String, limit: Int = 20): Flow<List<ProductHistoryEntity>>

    @Query("SELECT * FROM product_history WHERE productUuid=:uuid ORDER BY id DESC LIMIT 1")
    suspend fun latest(uuid: String): ProductHistoryEntity?

    @Query("SELECT * FROM product_history WHERE productUuid=:uuid AND actionType!='sync_checkpoint' ORDER BY id DESC LIMIT 1")
    suspend fun latestUndoable(uuid: String): ProductHistoryEntity?

    @Query("SELECT * FROM product_history WHERE productUuid=:uuid ORDER BY id DESC LIMIT :limit")
    suspend fun listForProduct(uuid: String, limit: Int = 20): List<ProductHistoryEntity>

    @Query("SELECT * FROM product_history WHERE id=:id LIMIT 1")
    suspend fun get(id: Long): ProductHistoryEntity?

    @Query("SELECT id FROM product_history WHERE id IN (:ids)")
    suspend fun existingIds(ids: List<Long>): List<Long>

    @Insert
    suspend fun insert(item: ProductHistoryEntity): Long

    @Query("DELETE FROM product_history WHERE productUuid=:uuid AND id NOT IN (SELECT id FROM product_history WHERE productUuid=:uuid ORDER BY id DESC LIMIT :keep)")
    suspend fun trim(uuid: String, keep: Int = 20): Int

    @Query("DELETE FROM product_history WHERE productUuid=:uuid")
    suspend fun deleteForProduct(uuid: String): Int

    @Query("DELETE FROM product_history")
    suspend fun deleteAll(): Int
}

@Dao
interface WorkQueueDao {
    @Query("SELECT q.* FROM work_queue q ORDER BY position,createdAt")
    fun observeQueue(): Flow<List<WorkQueueEntity>>

    @Query("SELECT COUNT(*) FROM work_queue")
    fun observeCount(): Flow<Long>

    @Query("SELECT * FROM work_queue WHERE productUuid=:uuid LIMIT 1")
    suspend fun get(uuid: String): WorkQueueEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(item: WorkQueueEntity)

    @Query("DELETE FROM work_queue WHERE productUuid=:uuid")
    suspend fun remove(uuid: String)

    @Query("SELECT COALESCE(MAX(position),0)+1 FROM work_queue")
    suspend fun nextPosition(): Int

    @Query("DELETE FROM work_queue")
    suspend fun clear(): Int
}

@Dao
interface SessionDao {
    @Query("SELECT * FROM sessions ORDER BY createdAt DESC")
    fun observeSessions(): Flow<List<SessionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(session: SessionEntity)
}

@Dao
interface SettingDao {
    @Query("SELECT value FROM settings WHERE key=:key LIMIT 1")
    suspend fun get(key: String): String?

    @Query("SELECT value FROM settings WHERE key=:key LIMIT 1")
    fun observe(key: String): Flow<String?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(item: SettingEntity)
}


@Dao
interface LocalPhotoDao {
    @Query("SELECT * FROM local_photos WHERE productUuid=:productUuid ORDER BY isMain DESC, sortOrder, createdAt")
    fun observeForProduct(productUuid: String): Flow<List<LocalPhotoEntity>>

    @Query("SELECT * FROM local_photos ORDER BY productUuid, isMain DESC, sortOrder, createdAt")
    fun observeAll(): Flow<List<LocalPhotoEntity>>

    @Query("SELECT * FROM local_photos WHERE productUuid=:productUuid ORDER BY isMain DESC, sortOrder, createdAt")
    suspend fun forProduct(productUuid: String): List<LocalPhotoEntity>

    @Query("SELECT * FROM local_photos WHERE id=:id LIMIT 1")
    suspend fun get(id: String): LocalPhotoEntity?

    @Query("SELECT COALESCE(MAX(sortOrder), -1) + 1 FROM local_photos WHERE productUuid=:productUuid")
    suspend fun nextSortOrder(productUuid: String): Int

    @Query("SELECT COUNT(*) FROM local_photos WHERE productUuid=:productUuid")
    suspend fun countForProduct(productUuid: String): Int

    @Query("SELECT COUNT(*) FROM local_photos WHERE remotePath=:remotePath AND id!=:excludeId")
    suspend fun countRemotePathExcept(remotePath: String, excludeId: String): Int

    @Query("SELECT sourceUri FROM local_photos WHERE sourceUri IS NOT NULL")
    suspend fun usedSourceUris(): List<String>

    @Query("SELECT * FROM local_photos WHERE status IN ('READY','ERROR') ORDER BY productUuid, isMain DESC, sortOrder ASC, createdAt ASC")
    suspend fun pendingUploads(): List<LocalPhotoEntity>

    @Query("SELECT COUNT(*) FROM local_photos WHERE status IN ('READY','ERROR','UPLOADING','UPLOADED')")
    fun observePendingCount(): Flow<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(item: LocalPhotoEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putAll(items: List<LocalPhotoEntity>)

    @Query("DELETE FROM local_photos WHERE id=:id")
    suspend fun delete(id: String)

    @Query("DELETE FROM local_photos WHERE productUuid=:productUuid")
    suspend fun deleteForProduct(productUuid: String): Int

    @Query("DELETE FROM local_photos WHERE productUuid=:productUuid AND status NOT IN ('ATTACHED','UPLOADED')")
    suspend fun deleteDiscardableForProduct(productUuid: String): Int

    @Query("UPDATE local_photos SET status='ATTACHED', error='', updatedAt=:now WHERE productUuid=:productUuid AND status='UPLOADED'")
    suspend fun markUploadedAttached(productUuid: String, now: Long)
}
