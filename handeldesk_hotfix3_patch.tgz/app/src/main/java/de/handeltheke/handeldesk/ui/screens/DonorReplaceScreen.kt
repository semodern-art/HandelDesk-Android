package de.handeltheke.handeldesk.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import de.handeltheke.handeldesk.HandelDeskApp
import de.handeltheke.handeldesk.domain.ValidationEngine
import de.handeltheke.handeldesk.ui.ScreenHeader
import de.handeltheke.handeldesk.ui.components.StatusBadge
import kotlinx.coroutines.launch

@Composable
fun DonorReplaceScreen(uuid: String, onDone: (String) -> Unit) {
    val app = LocalContext.current.applicationContext as HandelDeskApp
    val product by app.container.db.products().observe(uuid).collectAsState(initial = null)
    val scope = rememberCoroutineScope()
    var donorModel by remember { mutableStateOf("") }
    var newModel by rememberSaveable { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var applied by rememberSaveable { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var donor by remember { mutableStateOf<de.handeltheke.handeldesk.data.local.ProductEntity?>(null) }

    LaunchedEffect(product?.sourceProductId) {
        donor = product?.sourceProductId?.let { app.container.db.products().getByProductId(it) }
        donorModel = donor?.model.orEmpty()
    }

    val p = product
    if (p == null) {
        LinearProgressIndicator(Modifier.fillMaxWidth())
        return
    }

    BackHandler { onDone(uuid) }
    val checklist = donor?.let { ValidationEngine.donorChecklist(p, it) }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(
            title = "Быстрая замена по донору",
            subtitle = p.name.ifBlank { p.model },
            onBack = { onDone(uuid) },
        )

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                OutlinedTextField(
                    value = donorModel,
                    onValueChange = { donorModel = it; applied = false; message = null },
                    label = { Text("Старая модель целиком") },
                    supportingText = { Text("Например: EADP-40EB A") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                )
            }
            item {
                OutlinedTextField(
                    value = newModel,
                    onValueChange = { newModel = it; applied = false; message = null },
                    label = { Text("Новая модель целиком") },
                    supportingText = { Text("Например: ECDP-40FB C") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                )
            }
            item {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = MaterialTheme.shapes.medium,
                ) {
                    Text(
                        "Модель заменяется как единый объект во всех текстовых полях и SEO. Отдельные буквы и части модели не заменяются.",
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(12.dp),
                    )
                }
            }
            item {
                Button(
                    onClick = {
                        scope.launch {
                            busy = true
                            runCatching { app.container.productEditor.donorQuickReplace(uuid, donorModel, newModel) }
                                .onSuccess {
                                    applied = true
                                    message = "Замена применена · изменено полей: $it"
                                }
                                .onFailure { message = it.message ?: "Не удалось выполнить замену" }
                            busy = false
                        }
                    },
                    enabled = donorModel.isNotBlank() && newModel.isNotBlank() && !busy,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
                ) {
                    Text(if (busy) "ПРИМЕНЯЮ…" else "ПРИМЕНИТЬ ЗАМЕНУ")
                }
            }
            if (message != null) {
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (applied) StatusBadge("Применено", "ok")
                        Text(
                            message.orEmpty(),
                            color = if (applied) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.weight(1f),
                        )
                    }
                }
            }
            if (checklist?.applicable == true) {
                item { HorizontalDivider() }
                item { Text("Donor Checklist", style = MaterialTheme.typography.titleMedium) }
                checklist.items.forEach { item ->
                    item(key = item.code) {
                        Text("${when (item.status) { "ok" -> "✓"; "error" -> "✕"; else -> "⚠" }} ${item.label} ${item.message}")
                    }
                }
            }
            item { Spacer(Modifier.height(8.dp)) }
        }

        Surface(tonalElevation = 3.dp) {
            Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(
                    onClick = { onDone(uuid) },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp),
                ) {
                    Text(if (applied) "ГОТОВО — ПРОДОЛЖИТЬ РЕДАКТИРОВАНИЕ" else "К КАРТОЧКЕ ТОВАРА")
                }
                Text(
                    "Товар уже сохранён локально. Выход с этого экрана не удаляет черновик.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}
