package de.handeltheke.handeldesk.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import de.handeltheke.handeldesk.HandelDeskApp
import de.handeltheke.handeldesk.core.DonorTools
import de.handeltheke.handeldesk.domain.JsonTools
import de.handeltheke.handeldesk.domain.ProductJson
import de.handeltheke.handeldesk.domain.ValidationEngine
import de.handeltheke.handeldesk.ui.ScreenHeader
import de.handeltheke.handeldesk.ui.components.StatusBadge
import kotlinx.coroutines.launch

private data class QuickReplaceRow(
    val id: Long,
    val oldValue: String = "",
    val newValue: String = "",
)

@Composable
fun DonorReplaceScreen(uuid: String, onDone: (String) -> Unit) {
    val app = LocalContext.current.applicationContext as HandelDeskApp
    val product by app.container.db.products().observe(uuid).collectAsState(initial = null)
    val scope = rememberCoroutineScope()
    var rows by remember { mutableStateOf(listOf(QuickReplaceRow(1L))) }
    var nextId by remember { mutableLongStateOf(2L) }
    var message by remember { mutableStateOf<String?>(null) }
    var applied by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var donor by remember { mutableStateOf<de.handeltheke.handeldesk.data.local.ProductEntity?>(null) }

    LaunchedEffect(product?.sourceProductId, product?.sourceProductUuid) {
        val current = product
        donor = current?.sourceProductUuid?.let { app.container.db.products().get(it) }
            ?: current?.sourceProductId?.let { app.container.db.products().getByProductId(it) }
        val languageId = app.container.db.settings().get("primary_language_id")
        val donorName = donor?.let { item ->
            ProductJson.displayName(JsonTools.objectOf(item.localJson), languageId)
                .ifBlank { item.name }
                .ifBlank { item.model }
        }.orEmpty()
        if (donorName.isNotBlank() && rows.firstOrNull()?.oldValue.isNullOrBlank()) {
            rows = rows.toMutableList().apply {
                if (isEmpty()) add(QuickReplaceRow(1L, donorName, ""))
                else this[0] = this[0].copy(oldValue = donorName)
            }
        }
    }

    val p = product
    if (p == null) {
        LinearProgressIndicator(Modifier.fillMaxWidth())
        return
    }

    BackHandler { onDone(uuid) }
    val checklist = donor?.let { ValidationEngine.donorChecklist(p, it) }
    val validPairs = rows.map { it.oldValue.trim() to it.newValue.trim() }
        .filter { (old, new) -> old.isNotBlank() && new.isNotBlank() && !old.equals(new, ignoreCase = true) }
    val duplicateOld = validPairs.groupBy { it.first.lowercase() }.values.firstOrNull { it.size > 1 }?.firstOrNull()?.first
    val namePreview = remember(p.name, validPairs) { DonorTools.replaceManyAtomic(p.name, validPairs) }
    val modelPreview = remember(p.model, validPairs) { DonorTools.replaceManyAtomic(p.model, validPairs) }

    fun updateRow(id: Long, transform: (QuickReplaceRow) -> QuickReplaceRow) {
        rows = rows.map { if (it.id == id) transform(it) else it }
        applied = false
        message = null
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(
            title = "Быстрая замена по донору",
            subtitle = p.name.ifBlank { p.model },
            onBack = { onDone(uuid) },
        )

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Text("Замены", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Можно заменить модель, ток, напряжение и другие значения одним действием. Каждая строка считается цельным объектом.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            rows.forEachIndexed { index, row ->
                item(key = row.id) {
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(if (index == 0) "Основная замена" else "Замена ${index + 1}", style = MaterialTheme.typography.titleSmall)
                                if (rows.size > 1) {
                                    TextButton(onClick = {
                                        rows = rows.filterNot { it.id == row.id }
                                        applied = false
                                        message = null
                                    }) { Text("Удалить") }
                                }
                            }
                            OutlinedTextField(
                                value = row.oldValue,
                                onValueChange = { value -> updateRow(row.id) { it.copy(oldValue = value) } },
                                label = { Text("Найти") },
                                supportingText = { if (index == 0) Text("Например: OCEALEDCC195W2") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
                            )
                            OutlinedTextField(
                                value = row.newValue,
                                onValueChange = { value -> updateRow(row.id) { it.copy(newValue = value) } },
                                label = { Text("Заменить на") },
                                supportingText = { if (index == 0) Text("Например: OCEALEDCC215W3") else Text("Например: 2A → 3A") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
                            )
                        }
                    }
                }
            }

            item {
                FilledTonalButton(
                    onClick = {
                        if (rows.size < 8) {
                            rows = rows + QuickReplaceRow(nextId++)
                            applied = false
                            message = null
                        }
                    },
                    enabled = rows.size < 8,
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("＋ ЕЩЁ ЗАМЕНА") }
            }

            item {
                Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = MaterialTheme.shapes.medium) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Как работает защита", style = MaterialTheme.typography.titleSmall)
                        Text(
                            "Замены выполняются одновременно по исходному тексту и не каскадируют. Короткое значение вроде «2A» не заменится внутри более длинного идентификатора вроде «X2AB».",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
            }

            if (validPairs.isNotEmpty()) {
                item {
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Предпросмотр", style = MaterialTheme.typography.titleMedium)
                            if (namePreview.after != namePreview.before) {
                                Text("Название", style = MaterialTheme.typography.labelLarge)
                                Text("Было: ${namePreview.before}", style = MaterialTheme.typography.bodySmall)
                                Text("Станет: ${namePreview.after}")
                            }
                            if (modelPreview.after != modelPreview.before) {
                                Text("Модель", style = MaterialTheme.typography.labelLarge)
                                Text("Было: ${modelPreview.before}", style = MaterialTheme.typography.bodySmall)
                                Text("Станет: ${modelPreview.after}")
                            }
                            if (namePreview.after == namePreview.before && modelPreview.after == modelPreview.before) {
                                Text("В названии и модели совпадений пока нет. Другие поля будут проверены при применении.", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }

            if (duplicateOld != null) {
                item { Text("Значение «$duplicateOld» указано несколько раз.", color = MaterialTheme.colorScheme.error) }
            }

            item {
                Button(
                    onClick = {
                        scope.launch {
                            busy = true
                            runCatching { app.container.productEditor.donorQuickReplace(uuid, validPairs) }
                                .onSuccess {
                                    applied = true
                                    message = "Замены применены одним действием · изменено полей: $it"
                                }
                                .onFailure { message = it.message ?: "Не удалось выполнить замену" }
                            busy = false
                        }
                    },
                    enabled = validPairs.isNotEmpty() && duplicateOld == null && !busy,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
                ) {
                    Text(if (busy) "ПРИМЕНЯЮ…" else "ПРИМЕНИТЬ ${if (validPairs.size > 1) "${validPairs.size} ЗАМЕНЫ" else "ЗАМЕНУ"}")
                }
            }

            message?.let { text ->
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (applied) StatusBadge("Применено", "ok")
                        Text(
                            text,
                            color = if (applied) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.weight(1f),
                        )
                    }
                }
            }

            if (checklist?.applicable == true) {
                item { HorizontalDivider() }
                item { Text("Donor Checklist", style = MaterialTheme.typography.titleMedium) }
                checklist.items.forEach { checklistItem ->
                    item(key = checklistItem.code) {
                        Text("${when (checklistItem.status) { "ok" -> "✓"; "error" -> "✕"; else -> "⚠" }} ${checklistItem.label} ${checklistItem.message}")
                    }
                }
            }
            item { Spacer(Modifier.height(8.dp)) }
        }

        Surface(tonalElevation = 3.dp) {
            Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(
                    onClick = { onDone(uuid) },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp),
                ) {
                    Text(if (applied) "ГОТОВО — ПРОДОЛЖИТЬ РЕДАКТИРОВАНИЕ" else "К КАРТОЧКЕ ТОВАРА")
                }
                Text(
                    "Все замены входят в одну точку History/Undo. Товар уже сохранён локально.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}
