package de.handeltheke.handeldesk.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import de.handeltheke.handeldesk.HandelDeskApp
import de.handeltheke.handeldesk.data.local.LocalPhotoEntity
import de.handeltheke.handeldesk.data.repo.LocalPhotoRepository
import de.handeltheke.handeldesk.domain.JsonTools
import de.handeltheke.handeldesk.ui.ScreenHeader
import de.handeltheke.handeldesk.ui.components.LocalFileImage
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhotoManagerScreen(productUuid: String, onBack: () -> Unit, onEdit: (String) -> Unit) {
    val app = LocalContext.current.applicationContext as HandelDeskApp
    val product by app.container.db.products().observe(productUuid).collectAsState(initial = null)
    val photos by app.container.db.photos().observeForProduct(productUuid).collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var selectedFolder by remember { mutableStateOf("Fernbedienungen") }
    var folderMenu by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var pendingDeleteId by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(productUuid, photos.firstOrNull()?.remoteFolder) {
        selectedFolder = photos.firstOrNull()?.remoteFolder ?: app.container.localPhotos.suggestedFolder(productUuid)
        app.container.localPhotos.ensureGalleryMarkers(productUuid)
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) {
            scope.launch {
                busy = true
                runCatching {
                    app.container.localPhotos.importUris(productUuid, uris)
                    app.container.localPhotos.setProductFolder(productUuid, selectedFolder)
                }.onFailure { message = it.message ?: "Не удалось добавить фото" }
                busy = false
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Фото товара", product?.name?.ifBlank { product?.model.orEmpty() }, onBack)
        Column(Modifier.padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Папка на сервере", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                LocalPhotoRepository.FAST_FOLDERS.forEach { folder ->
                    FilterChip(
                        selected = selectedFolder == folder,
                        onClick = {
                            selectedFolder = folder
                            scope.launch { app.container.localPhotos.setProductFolder(productUuid, folder) }
                        },
                        label = { Text(folder) }
                    )
                }
            }
            ExposedDropdownMenuBox(expanded = folderMenu, onExpandedChange = { folderMenu = it }) {
                OutlinedTextField(
                    value = selectedFolder,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Все папки") },
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(expanded = folderMenu, onDismissRequest = { folderMenu = false }) {
                    LocalPhotoRepository.TARGET_FOLDERS.forEach { folder ->
                        DropdownMenuItem(text = { Text(folder) }, onClick = {
                            folderMenu = false
                            selectedFolder = folder
                            scope.launch { app.container.localPhotos.setProductFolder(productUuid, folder) }
                        })
                    }
                }
            }
            Button(onClick = { picker.launch("image/*") }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                Text("＋ ДОБАВИТЬ ФОТО С ТЕЛЕФОНА")
            }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            Text(
                "Имена файлов сохраняются без переименования. Оригиналы камеры не меняются. Для контроля в обычной галерее HandelDesk создаёт свои копии: Pictures/HandelDesk/В работе → после crop Pictures/HandelDesk/Обработано.",
                style = MaterialTheme.typography.bodySmall
            )
        }

        if (photos.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth().padding(24.dp)) { Text("Фото пока нет") }
        } else {
            val imageIndexByPath = remember(product?.localJson) {
                val payload = product?.localJson?.let(JsonTools::objectOf)
                (payload?.get("images") as? JsonArray).orEmpty().mapIndexedNotNull { index, element ->
                    val path = (element as? kotlinx.serialization.json.JsonObject)?.get("image")?.jsonPrimitive?.contentOrNull
                    path?.takeIf { it.isNotBlank() }?.let { it to index }
                }.toMap()
            }
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(photos, key = { it.id }) { photo ->
                    val extras = photos.filter { !it.isMain }.sortedBy { it.sortOrder }
                    val extraIndex = extras.indexOfFirst { it.id == photo.id }
                    PhotoQueueCard(
                        photo = photo,
                        additionalIndex = if (photo.isMain) 0 else imageIndexByPath[photo.remotePath],
                        canMoveUp = !photo.isMain && extraIndex > 0,
                        canMoveDown = !photo.isMain && extraIndex >= 0 && extraIndex < extras.lastIndex,
                        onEdit = { onEdit(photo.id) },
                        onMain = { scope.launch { app.container.localPhotos.setMain(photo.id) } },
                        onMoveUp = { scope.launch { app.container.localPhotos.moveAdditional(photo.id, -1) } },
                        onMoveDown = { scope.launch { app.container.localPhotos.moveAdditional(photo.id, +1) } },
                        onDelete = { pendingDeleteId = photo.id }
                    )
                }
            }
        }
    }

    pendingDeleteId?.let { photoId ->
        val target = photos.firstOrNull { it.id == photoId }
        AlertDialog(
            onDismissRequest = { pendingDeleteId = null },
            title = { Text("Удалить локальное фото?") },
            text = {
                val detail = if (target?.status == "ATTACHED")
                    "Фото уже связано с товаром. После удаления будет создано локальное изменение карточки, которое уберёт его из товара при следующем Sync. Исходник камеры останется; служебная копия HandelDesk из галереи будет удалена."
                else
                    "Фото будет удалено из HandelDesk и локальной очереди. Исходник камеры останется; служебная копия HandelDesk из галереи будет удалена."
                Text("${target?.fileName.orEmpty()}\n\n$detail")
            },
            confirmButton = {
                TextButton(
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
                    onClick = {
                        pendingDeleteId = null
                        scope.launch {
                            runCatching { app.container.localPhotos.delete(photoId) }
                                .onFailure { message = it.message ?: "Не удалось удалить фото" }
                        }
                    }
                ) { Text("Удалить") }
            },
            dismissButton = { TextButton(onClick = { pendingDeleteId = null }) { Text("Отмена") } },
        )
    }

    message?.let { text ->
        AlertDialog(
            onDismissRequest = { message = null },
            title = { Text("Фото") },
            text = { Text(text) },
            confirmButton = { TextButton(onClick = { message = null }) { Text("OK") } }
        )
    }
}

@Composable
private fun PhotoQueueCard(
    photo: LocalPhotoEntity,
    additionalIndex: Int?,
    canMoveUp: Boolean,
    canMoveDown: Boolean,
    onEdit: () -> Unit,
    onMain: () -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onDelete: () -> Unit,
) {
    val shownPath = photo.processedPath.ifBlank { photo.originalPath }
    Card(Modifier.fillMaxWidth().clickable { onEdit() }) {
        Row(Modifier.padding(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            LocalFileImage(shownPath, size = 86.dp)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(photo.fileName, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                    if (photo.isMain) AssistChip(onClick = {}, label = { Text("Главное") })
                }
                Text(photo.remoteFolder, style = MaterialTheme.typography.bodySmall)
                if (additionalIndex != null) {
                    Text(
                        if (photo.isMain) "Доп. фото №0 · дубль главного" else "Доп. фото №$additionalIndex",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                if (photo.processedWidth > 0) Text("${photo.processedWidth}×${photo.processedHeight}", style = MaterialTheme.typography.bodySmall)
                Text(photoStatus(photo), style = MaterialTheme.typography.bodySmall)
                galleryStatus(photo)?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                if (photo.error.isNotBlank()) Text(photo.error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                photo.galleryError?.takeIf { it.isNotBlank() }?.let { Text("Галерея: $it", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = onEdit) { Text(if (photo.processedPath.isBlank()) "Обрезать" else "Изменить") }
                    if (!photo.isMain) TextButton(onClick = onMain) { Text("Сделать главным") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (!photo.isMain) {
                        OutlinedButton(onClick = onMoveUp, enabled = canMoveUp, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("↑") }
                        OutlinedButton(onClick = onMoveDown, enabled = canMoveDown, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("↓") }
                    }
                    TextButton(onClick = onDelete) { Text("Удалить") }
                }
            }
        }
    }
}

private fun photoStatus(photo: LocalPhotoEntity): String = when (photo.status) {
    "IMPORTED" -> "Нужно обработать"
    "READY" -> "Готово · ожидает загрузки"
    "UPLOADING" -> "Загрузка…"
    "UPLOADED" -> "Загружено · ожидает привязки к товару"
    "ATTACHED" -> "✓ Синхронизировано"
    "ERROR" -> "Ошибка · можно повторить синхронизацию"
    else -> photo.status
}

private fun galleryStatus(photo: LocalPhotoEntity): String? = when (photo.galleryState) {
    "WORKING" -> "Галерея: HandelDesk/В работе"
    "PROCESSED" -> "Галерея: HandelDesk/Обработано"
    "UNSUPPORTED" -> "Галерея: автоальбом недоступен на этой версии Android"
    "ERROR" -> "Галерея: не удалось обновить автоальбом"
    else -> null
}
