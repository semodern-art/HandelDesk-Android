package de.handeltheke.handeldesk.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import de.handeltheke.handeldesk.HandelDeskApp
import de.handeltheke.handeldesk.data.local.LocalPhotoEntity
import de.handeltheke.handeldesk.data.repo.LocalPhotoRepository
import de.handeltheke.handeldesk.ui.ScreenHeader
import de.handeltheke.handeldesk.ui.components.LocalFileImage
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhotoManagerScreen(productUuid: String, onBack: () -> Unit, onEdit: (String) -> Unit) {
    val app = LocalContext.current.applicationContext as HandelDeskApp
    val product by app.container.db.products().observe(productUuid).collectAsState(initial = null)
    val photos by app.container.db.photos().observeForProduct(productUuid).collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var selectedFolder by remember { mutableStateOf("Fernbedienungen") }
    var folderMenu by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(productUuid, photos.firstOrNull()?.remoteFolder) {
        selectedFolder = photos.firstOrNull()?.remoteFolder ?: app.container.localPhotos.suggestedFolder(productUuid)
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) {
            scope.launch {
                busy = true
                runCatching {
                    app.container.localPhotos.importUris(productUuid, uris)
                    app.container.localPhotos.setProductFolder(productUuid, selectedFolder)
                }.onFailure { message = it.message ?: "Не удалось добавить фото" }
                busy = false
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Фото товара", product?.name?.ifBlank { product?.model.orEmpty() }, onBack)
        Column(Modifier.padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Папка на сервере", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                LocalPhotoRepository.FAST_FOLDERS.forEach { folder ->
                    FilterChip(
                        selected = selectedFolder == folder,
                        onClick = {
                            selectedFolder = folder
                            scope.launch { app.container.localPhotos.setProductFolder(productUuid, folder) }
                        },
                        label = { Text(folder) }
                    )
                }
            }
            ExposedDropdownMenuBox(expanded = folderMenu, onExpandedChange = { folderMenu = it }) {
                OutlinedTextField(
                    value = selectedFolder,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Все папки") },
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(expanded = folderMenu, onDismissRequest = { folderMenu = false }) {
                    LocalPhotoRepository.TARGET_FOLDERS.forEach { folder ->
                        DropdownMenuItem(text = { Text(folder) }, onClick = {
                            folderMenu = false
                            selectedFolder = folder
                            scope.launch { app.container.localPhotos.setProductFolder(productUuid, folder) }
                        })
                    }
                }
            }
            Button(onClick = { picker.launch("image/*") }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                Text("＋ ДОБАВИТЬ ФОТО С ТЕЛЕФОНА")
            }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            Text(
                "Имена файлов сохраняются без переименования. Оригиналы не изменяются: HandelDesk хранит отдельную обработанную копию до синхронизации.",
                style = MaterialTheme.typography.bodySmall
            )
        }

        if (photos.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth().padding(24.dp)) { Text("Фото пока нет") }
        } else {
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(photos, key = { it.id }) { photo ->
                    PhotoQueueCard(
                        photo = photo,
                        onEdit = { onEdit(photo.id) },
                        onMain = { scope.launch { app.container.localPhotos.setMain(photo.id) } },
                        onDelete = { scope.launch { app.container.localPhotos.delete(photo.id) } }
                    )
                }
            }
        }
    }

    message?.let { text ->
        AlertDialog(
            onDismissRequest = { message = null },
            title = { Text("Фото") },
            text = { Text(text) },
            confirmButton = { TextButton(onClick = { message = null }) { Text("OK") } }
        )
    }
}

@Composable
private fun PhotoQueueCard(photo: LocalPhotoEntity, onEdit: () -> Unit, onMain: () -> Unit, onDelete: () -> Unit) {
    val shownPath = photo.processedPath.ifBlank { photo.originalPath }
    Card(Modifier.fillMaxWidth().clickable { onEdit() }) {
        Row(Modifier.padding(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            LocalFileImage(shownPath, size = 86.dp)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(photo.fileName, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                    if (photo.isMain) AssistChip(onClick = {}, label = { Text("Главное") })
                }
                Text(photo.remoteFolder, style = MaterialTheme.typography.bodySmall)
                if (photo.processedWidth > 0) Text("${photo.processedWidth}×${photo.processedHeight}", style = MaterialTheme.typography.bodySmall)
                Text(photoStatus(photo), style = MaterialTheme.typography.bodySmall)
                if (photo.error.isNotBlank()) Text(photo.error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = onEdit) { Text(if (photo.processedPath.isBlank()) "Обрезать" else "Изменить") }
                    if (!photo.isMain) TextButton(onClick = onMain) { Text("Главное") }
                    TextButton(onClick = onDelete) { Text("Удалить") }
                }
            }
        }
    }
}

private fun photoStatus(photo: LocalPhotoEntity): String = when (photo.status) {
    "IMPORTED" -> "Нужно обработать"
    "READY" -> "Готово · ожидает загрузки"
    "UPLOADING" -> "Загрузка…"
    "UPLOADED" -> "Загружено · ожидает привязки к товару"
    "ATTACHED" -> "✓ Синхронизировано"
    "ERROR" -> "Ошибка · можно повторить синхронизацию"
    else -> photo.status
}
