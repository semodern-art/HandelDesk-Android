package de.handeltheke.handeldesk.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import de.handeltheke.handeldesk.HandelDeskApp
import de.handeltheke.handeldesk.data.local.LocalPhotoEntity
import de.handeltheke.handeldesk.data.repo.LocalPhotoRepository
import de.handeltheke.handeldesk.domain.JsonTools
import de.handeltheke.handeldesk.ui.ScreenHeader
import de.handeltheke.handeldesk.ui.components.EmptyState
import de.handeltheke.handeldesk.ui.components.LocalFileImage
import de.handeltheke.handeldesk.ui.components.SectionCard
import de.handeltheke.handeldesk.ui.components.StatusBadge
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonPrimitive

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhotoManagerScreen(
    productUuid: String,
    onBack: () -> Unit,
    onEdit: (String) -> Unit,
    onInbox: (String) -> Unit,
) {
    val app = LocalContext.current.applicationContext as HandelDeskApp
    val product by app.container.db.products().observe(productUuid).collectAsState(initial = null)
    val photos by app.container.db.photos().observeForProduct(productUuid).collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var selectedFolder by remember { mutableStateOf("Fernbedienungen") }
    var folderMenu by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var pendingDeleteId by remember { mutableStateOf<String?>(null) }
    var workspace by remember { mutableStateOf(LocalPhotoRepository.WorkspaceStatus(false)) }

    LaunchedEffect(productUuid, photos.joinToString("|") { "${it.id}:${it.sourceStage}:${it.status}:${it.updatedAt}" }) {
        selectedFolder = photos.firstOrNull()?.remoteFolder ?: app.container.localPhotos.suggestedFolder(productUuid)
        app.container.localPhotos.cleanupLegacyGalleryMarkers(productUuid)
        app.container.localPhotos.reconcileWorkspaceStages(productUuid)
        workspace = app.container.localPhotos.workspaceStatus()
    }

    val imageIndexByPath = remember(product?.localJson) {
        val payload = product?.localJson?.let(JsonTools::objectOf)
        (payload?.get("images") as? JsonArray).orEmpty().mapIndexedNotNull { index, element ->
            val path = (element as? kotlinx.serialization.json.JsonObject)?.get("image")?.jsonPrimitive?.contentOrNull
            path?.takeIf { it.isNotBlank() }?.let { it to index }
        }.toMap()
    }

    val fallbackPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) {
            scope.launch {
                busy = true
                runCatching {
                    app.container.localPhotos.importUris(productUuid, uris)
                    app.container.localPhotos.setProductFolder(productUuid, selectedFolder)
                }.onFailure { message = it.message ?: "Не удалось добавить фото" }
                busy = false
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Фото товара", product?.name?.ifBlank { product?.model.orEmpty() }, onBack)

        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                SectionCard(Modifier.fillMaxWidth()) {
                    Text("Оригиналы", style = MaterialTheme.typography.titleMedium)
                    if (workspace.configured) {
                        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            StatusBadge("Eingang ${workspace.inboxCount}", "primary")
                            StatusBadge("Bearbeitet ${workspace.processedCount}", "warn")
                            StatusBadge("Hochgeladen ${workspace.uploadedCount}", "ok")
                        }
                        Button(onClick = { onInbox(productUuid) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                            Text("ДОБАВИТЬ ИЗ 01_EINGANG")
                        }
                    } else {
                        Text(
                            "Настрой рабочую папку при первом открытии Eingang. После этого оригиналы будут автоматически переходить 01_Eingang → 02_Bearbeitet → 03_Hochgeladen без изменения качества.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Button(onClick = { onInbox(productUuid) }, modifier = Modifier.fillMaxWidth()) { Text("НАСТРОИТЬ HANDELDESK / EINGANG") }
                    }
                    OutlinedButton(onClick = { fallbackPicker.launch("image/*") }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                        Text("Добавить из другой папки")
                    }
                    Text(
                        "Crop/resize применяются только к внутренней копии для магазина. Оригинал для ПК не перекодируется и не перезаписывается.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                }
            }

            item {
                SectionCard(Modifier.fillMaxWidth()) {
                    Text("Папка на сервере", style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        LocalPhotoRepository.FAST_FOLDERS.forEach { folder ->
                            FilterChip(
                                selected = selectedFolder == folder,
                                onClick = {
                                    selectedFolder = folder
                                    scope.launch { app.container.localPhotos.setProductFolder(productUuid, folder) }
                                },
                                label = { Text(folder) },
                            )
                        }
                    }
                    ExposedDropdownMenuBox(expanded = folderMenu, onExpandedChange = { folderMenu = it }) {
                        OutlinedTextField(
                            value = selectedFolder,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Все серверные папки") },
                            modifier = Modifier.menuAnchor().fillMaxWidth(),
                        )
                        ExposedDropdownMenu(expanded = folderMenu, onDismissRequest = { folderMenu = false }) {
                            LocalPhotoRepository.TARGET_FOLDERS.forEach { folder ->
                                DropdownMenuItem(text = { Text(folder) }, onClick = {
                                    folderMenu = false
                                    selectedFolder = folder
                                    scope.launch { app.container.localPhotos.setProductFolder(productUuid, folder) }
                                })
                            }
                        }
                    }
                }
            }

            if (photos.isEmpty()) {
                item { EmptyState("Фото пока нет", "Добавь оригиналы из Eingang и обработай их перед синхронизацией.", Modifier.fillMaxWidth().height(230.dp)) }
            } else {
                items(photos, key = { it.id }) { photo ->
                    val extras = photos.filter { !it.isMain }.sortedBy { it.sortOrder }
                    val extraIndex = extras.indexOfFirst { it.id == photo.id }
                    PhotoQueueCard(
                        photo = photo,
                        additionalIndex = if (photo.isMain) 0 else imageIndexByPath[photo.remotePath],
                        canMoveUp = !photo.isMain && extraIndex > 0,
                        canMoveDown = !photo.isMain && extraIndex >= 0 && extraIndex < extras.lastIndex,
                        onEdit = { onEdit(photo.id) },
                        onMain = { scope.launch { app.container.localPhotos.setMain(photo.id) } },
                        onMoveUp = { scope.launch { app.container.localPhotos.moveAdditional(photo.id, -1) } },
                        onMoveDown = { scope.launch { app.container.localPhotos.moveAdditional(photo.id, +1) } },
                        onDelete = { pendingDeleteId = photo.id },
                    )
                }
            }
        }
    }

    pendingDeleteId?.let { photoId ->
        val target = photos.firstOrNull { it.id == photoId }
        AlertDialog(
            onDismissRequest = { pendingDeleteId = null },
            title = { Text("Удалить локальное фото?") },
            text = {
                val detail = if (target?.status == "ATTACHED") {
                    "Фото уже связано с товаром. Будет создано локальное изменение карточки. Оригинал из 03_Hochgeladen останется для архива."
                } else {
                    "Фото выйдет из локальной очереди. Если оригинал уже был перенесён в 02_Bearbeitet, HandelDesk попробует вернуть его обратно в 01_Eingang."
                }
                Text("${target?.fileName.orEmpty()}\n\n$detail")
            },
            confirmButton = {
                TextButton(
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
                    onClick = {
                        pendingDeleteId = null
                        scope.launch {
                            runCatching { app.container.localPhotos.delete(photoId) }
                                .onFailure { message = it.message ?: "Не удалось удалить фото" }
                        }
                    },
                ) { Text("Удалить") }
            },
            dismissButton = { TextButton(onClick = { pendingDeleteId = null }) { Text("Отмена") } },
        )
    }

    message?.let { text ->
        AlertDialog(
            onDismissRequest = { message = null },
            title = { Text("Фото") },
            text = { Text(text) },
            confirmButton = { TextButton(onClick = { message = null }) { Text("OK") } },
        )
    }
}

@Composable
private fun PhotoQueueCard(
    photo: LocalPhotoEntity,
    additionalIndex: Int?,
    canMoveUp: Boolean,
    canMoveDown: Boolean,
    onEdit: () -> Unit,
    onMain: () -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onDelete: () -> Unit,
) {
    val shownPath = photo.processedPath.ifBlank { photo.originalPath }
    ElevatedCard(Modifier.fillMaxWidth().clickable { onEdit() }) {
        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            LocalFileImage(shownPath, size = 92.dp)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(photo.fileName, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f), maxLines = 2)
                    if (photo.isMain) StatusBadge("Главное", "primary")
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    StatusBadge(photoStatusShort(photo), photoStatusKind(photo))
                    sourceStatus(photo)?.let { StatusBadge(it, sourceStatusKind(photo)) }
                }
                Text(photo.remoteFolder, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (additionalIndex != null) {
                    Text(
                        if (photo.isMain) "Доп. фото №0 · дубль главного" else "Доп. фото №$additionalIndex",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
                if (photo.processedWidth > 0) Text("${photo.processedWidth}×${photo.processedHeight}", style = MaterialTheme.typography.bodySmall)
                photo.error.takeIf { it.isNotBlank() }?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                photo.sourceError?.takeIf { it.isNotBlank() }?.let { Text("Оригинал: $it", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    FilledTonalButton(onClick = onEdit, contentPadding = PaddingValues(horizontal = 12.dp)) { Text(if (photo.processedPath.isBlank()) "Обрезать" else "Изменить") }
                    if (!photo.isMain) TextButton(onClick = onMain) { Text("Главное") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (!photo.isMain) {
                        OutlinedButton(onClick = onMoveUp, enabled = canMoveUp, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("↑") }
                        OutlinedButton(onClick = onMoveDown, enabled = canMoveDown, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("↓") }
                    }
                    TextButton(onClick = onDelete, colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)) { Text("Удалить") }
                }
            }
        }
    }
}

private fun photoStatusShort(photo: LocalPhotoEntity): String = when (photo.status) {
    "IMPORTED" -> "Обработать"
    "READY" -> "К загрузке"
    "UPLOADING" -> "Загрузка"
    "UPLOADED" -> "Привязка"
    "ATTACHED" -> "Готово"
    "ERROR" -> "Ошибка"
    else -> photo.status
}

private fun photoStatusKind(photo: LocalPhotoEntity): String = when (photo.status) {
    "ATTACHED" -> "ok"
    "READY", "UPLOADED" -> "warn"
    "ERROR" -> "error"
    else -> "neutral"
}

private fun sourceStatus(photo: LocalPhotoEntity): String? = when (photo.sourceStage) {
    LocalPhotoRepository.STAGE_INBOX -> "01 Eingang"
    LocalPhotoRepository.STAGE_PROCESSED -> "02 Bearbeitet"
    LocalPhotoRepository.STAGE_UPLOADED -> "03 Hochgeladen"
    LocalPhotoRepository.STAGE_EXTERNAL -> "Внешнее"
    else -> null
}

private fun sourceStatusKind(photo: LocalPhotoEntity): String = when (photo.sourceStage) {
    LocalPhotoRepository.STAGE_UPLOADED -> "ok"
    LocalPhotoRepository.STAGE_PROCESSED -> "warn"
    LocalPhotoRepository.STAGE_INBOX -> "primary"
    else -> "neutral"
}
