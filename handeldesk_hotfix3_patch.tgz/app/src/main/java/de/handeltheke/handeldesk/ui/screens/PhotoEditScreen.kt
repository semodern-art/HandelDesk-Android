package de.handeltheke.handeldesk.ui.screens

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import de.handeltheke.handeldesk.HandelDeskApp
import de.handeltheke.handeldesk.data.local.LocalPhotoEntity
import de.handeltheke.handeldesk.ui.ScreenHeader
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private data class CropRect(val left: Float, val top: Float, val right: Float, val bottom: Float)
private enum class DragPart { NONE, MOVE, LEFT, RIGHT, TOP, BOTTOM, TL, TR, BL, BR }

@Composable
fun PhotoEditScreen(photoId: String, onBack: () -> Unit) {
    val app = LocalContext.current.applicationContext as HandelDeskApp
    val scope = rememberCoroutineScope()
    var row by remember { mutableStateOf<LocalPhotoEntity?>(null) }
    var preview by remember { mutableStateOf<Bitmap?>(null) }
    var crop by remember { mutableStateOf(CropRect(0f, 0f, 1f, 1f)) }
    var rotation by remember { mutableIntStateOf(0) }
    var widthText by remember { mutableStateOf("") }
    var heightText by remember { mutableStateOf("") }
    var keepAspect by remember { mutableStateOf(true) }
    var doNotEnlarge by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var cropDragging by remember { mutableStateOf(false) }
    var sizeDriver by remember { mutableStateOf("WIDTH") }

    LaunchedEffect(photoId) {
        row = app.container.db.photos().get(photoId)?.also { p ->
            crop = CropRect(p.cropLeft, p.cropTop, p.cropRight, p.cropBottom)
            rotation = p.rotationDegrees
            widthText = p.targetWidth.takeIf { it > 0 }?.toString().orEmpty()
            heightText = p.targetHeight.takeIf { it > 0 }?.toString().orEmpty()
            keepAspect = p.keepAspect
            doNotEnlarge = p.doNotEnlarge
            sizeDriver = if (p.targetWidth > 0 || p.targetHeight <= 0) "WIDTH" else "HEIGHT"
        }
    }
    LaunchedEffect(photoId, rotation, row?.id) {
        if (row != null) {
            preview?.recycle()
            preview = runCatching { app.container.localPhotos.loadPreview(photoId, 1800, rotation).bitmap }
                .onFailure { message = it.message }
                .getOrNull()
        }
    }
    DisposableEffect(Unit) { onDispose { preview?.recycle() } }

    val photo = row
    if (photo == null) {
        Column { ScreenHeader("Редактор фото", onBack = onBack); LinearProgressIndicator(Modifier.fillMaxWidth()) }
        return
    }

    val rotatedSourceW = if (rotation % 180 == 0) photo.sourceWidth else photo.sourceHeight
    val rotatedSourceH = if (rotation % 180 == 0) photo.sourceHeight else photo.sourceWidth
    val cropW = max(1, (rotatedSourceW * (crop.right - crop.left)).roundToInt())
    val cropH = max(1, (rotatedSourceH * (crop.bottom - crop.top)).roundToInt())

    LaunchedEffect(cropW, cropH, keepAspect, sizeDriver) {
        if (!keepAspect || cropW <= 0 || cropH <= 0) return@LaunchedEffect
        if (sizeDriver == "HEIGHT") {
            heightText.toIntOrNull()?.let { h -> widthText = max(1, (h.toDouble() * cropW / cropH).roundToInt()).toString() }
        } else {
            widthText.toIntOrNull()?.let { w -> heightText = max(1, (w.toDouble() * cropH / cropW).roundToInt()).toString() }
        }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Обрезка фото", photo.fileName, onBack)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState(), enabled = !cropDragging).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            preview?.let { bitmap ->
                ManualCropView(
                    bitmap = bitmap,
                    crop = crop,
                    onCropChange = { crop = it },
                    onDraggingChange = { cropDragging = it },
                )
            } ?: LinearProgressIndicator(Modifier.fillMaxWidth())

            Text("Исходник: ${rotatedSourceW}×${rotatedSourceH} · Обрезка: ${cropW}×${cropH}")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    rotation = (rotation + 90) % 360
                    crop = CropRect(0f, 0f, 1f, 1f)
                }) { Text("↻ 90°") }
                OutlinedButton(onClick = { crop = CropRect(0f, 0f, 1f, 1f) }) { Text("Сбросить crop") }
            }

            Text("Итоговое разрешение", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = widthText,
                    onValueChange = { value ->
                        sizeDriver = "WIDTH"
                        widthText = value.filter(Char::isDigit).take(5)
                        if (keepAspect) widthText.toIntOrNull()?.let { w -> heightText = max(1, (w.toDouble() * cropH / cropW).roundToInt()).toString() }
                    },
                    label = { Text("Ширина px") },
                    placeholder = { Text(cropW.toString()) },
                    modifier = Modifier.weight(1f), singleLine = true
                )
                OutlinedTextField(
                    value = heightText,
                    onValueChange = { value ->
                        sizeDriver = "HEIGHT"
                        heightText = value.filter(Char::isDigit).take(5)
                        if (keepAspect) heightText.toIntOrNull()?.let { h -> widthText = max(1, (h.toDouble() * cropW / cropH).roundToInt()).toString() }
                    },
                    label = { Text("Высота px") },
                    placeholder = { Text(cropH.toString()) },
                    modifier = Modifier.weight(1f), singleLine = true
                )
            }
            Row(Modifier.fillMaxWidth()) {
                Checkbox(keepAspect, onCheckedChange = { keepAspect = it })
                Text("Сохранять пропорции", modifier = Modifier.padding(top = 12.dp))
            }
            Row(Modifier.fillMaxWidth()) {
                Checkbox(doNotEnlarge, onCheckedChange = { doNotEnlarge = it })
                Text("Не увеличивать сверх обрезанного исходника", modifier = Modifier.padding(top = 12.dp))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(800, 1200, 1600).forEach { preset ->
                    OutlinedButton(onClick = {
                        sizeDriver = "WIDTH"
                        widthText = preset.toString()
                        heightText = max(1, (preset.toDouble() * cropH / cropW).roundToInt()).toString()
                        keepAspect = true
                    }) { Text("${preset}px") }
                }
            }
            Text("Файл останется с именем ${photo.fileName}; оригинал на телефоне и его копия в HandelDesk не изменяются.", style = MaterialTheme.typography.bodySmall)
        }
        Button(
            onClick = {
                scope.launch {
                    busy = true
                    runCatching {
                        app.container.localPhotos.process(
                            photoId = photoId,
                            cropLeft = crop.left, cropTop = crop.top, cropRight = crop.right, cropBottom = crop.bottom,
                            rotationDegrees = rotation,
                            targetWidth = widthText.toIntOrNull() ?: 0,
                            targetHeight = heightText.toIntOrNull() ?: 0,
                            keepAspect = keepAspect,
                            doNotEnlarge = doNotEnlarge,
                        )
                    }.onSuccess { onBack() }.onFailure { message = it.message ?: "Не удалось обработать фото" }
                    busy = false
                }
            },
            enabled = !busy,
            modifier = Modifier.fillMaxWidth().padding(12.dp)
        ) { Text(if (busy) "ОБРАБОТКА…" else "СОХРАНИТЬ ОБРАБОТАННОЕ ФОТО") }
    }

    message?.let { text ->
        AlertDialog(onDismissRequest = { message = null }, title = { Text("Фото") }, text = { Text(text) }, confirmButton = { TextButton(onClick = { message = null }) { Text("OK") } })
    }
}

@Composable
private fun ManualCropView(
    bitmap: Bitmap,
    crop: CropRect,
    onCropChange: (CropRect) -> Unit,
    onDraggingChange: (Boolean) -> Unit,
) {
    val density = LocalDensity.current
    val cropState = rememberUpdatedState(crop)
    var dragPart by remember { mutableStateOf(DragPart.NONE) }

    DisposableEffect(Unit) {
        onDispose { onDraggingChange(false) }
    }

    BoxWithConstraints(Modifier.fillMaxWidth().height(430.dp).background(Color.Black)) {
        val boxW = with(density) { maxWidth.toPx() }
        val boxH = with(density) { maxHeight.toPx() }
        val scale = min(boxW / bitmap.width.toFloat(), boxH / bitmap.height.toFloat())
        val imageW = bitmap.width * scale
        val imageH = bitmap.height * scale
        val offX = (boxW - imageW) / 2f
        val offY = (boxH - imageH) / 2f
        // Large invisible hit target for fingers; the visible handle stays compact.
        val handlePx = with(density) { 44.dp.toPx() }
        val handleRadius = with(density) { 9.dp.toPx() }

        Image(bitmap.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        Canvas(
            Modifier.fillMaxSize().pointerInput(boxW, boxH, imageW, imageH) {
                fun point(rect: CropRect): FloatArray = floatArrayOf(
                    offX + rect.left * imageW, offY + rect.top * imageH,
                    offX + rect.right * imageW, offY + rect.bottom * imageH
                )
                fun choose(rect: CropRect, pos: Offset): DragPart {
                    val p = point(rect); val l=p[0]; val t=p[1]; val r=p[2]; val b=p[3]
                    val nearL=abs(pos.x-l)<=handlePx; val nearR=abs(pos.x-r)<=handlePx
                    val nearT=abs(pos.y-t)<=handlePx; val nearB=abs(pos.y-b)<=handlePx
                    return when {
                        nearL && nearT -> DragPart.TL
                        nearR && nearT -> DragPart.TR
                        nearL && nearB -> DragPart.BL
                        nearR && nearB -> DragPart.BR
                        nearL && pos.y in t..b -> DragPart.LEFT
                        nearR && pos.y in t..b -> DragPart.RIGHT
                        nearT && pos.x in l..r -> DragPart.TOP
                        nearB && pos.x in l..r -> DragPart.BOTTOM
                        pos.x in l..r && pos.y in t..b -> DragPart.MOVE
                        else -> DragPart.NONE
                    }
                }

                var gestureRect = cropState.value
                detectDragGestures(
                    onDragStart = { start ->
                        gestureRect = cropState.value
                        dragPart = choose(gestureRect, start)
                        onDraggingChange(dragPart != DragPart.NONE)
                    },
                    onDragEnd = {
                        dragPart = DragPart.NONE
                        onDraggingChange(false)
                    },
                    onDragCancel = {
                        dragPart = DragPart.NONE
                        onDraggingChange(false)
                    },
                    onDrag = { change, amount ->
                        if (dragPart != DragPart.NONE && imageW > 0f && imageH > 0f) {
                            change.consume()
                            val dx = amount.x / imageW
                            val dy = amount.y / imageH
                            val minSize = 0.02f
                            var l=gestureRect.left; var t=gestureRect.top; var r=gestureRect.right; var b=gestureRect.bottom
                            when (dragPart) {
                                DragPart.MOVE -> {
                                    val w=r-l; val h=b-t
                                    l=(l+dx).coerceIn(0f, 1f-w); r=l+w
                                    t=(t+dy).coerceIn(0f, 1f-h); b=t+h
                                }
                                DragPart.LEFT -> l=(l+dx).coerceIn(0f, r-minSize)
                                DragPart.RIGHT -> r=(r+dx).coerceIn(l+minSize,1f)
                                DragPart.TOP -> t=(t+dy).coerceIn(0f,b-minSize)
                                DragPart.BOTTOM -> b=(b+dy).coerceIn(t+minSize,1f)
                                DragPart.TL -> { l=(l+dx).coerceIn(0f,r-minSize); t=(t+dy).coerceIn(0f,b-minSize) }
                                DragPart.TR -> { r=(r+dx).coerceIn(l+minSize,1f); t=(t+dy).coerceIn(0f,b-minSize) }
                                DragPart.BL -> { l=(l+dx).coerceIn(0f,r-minSize); b=(b+dy).coerceIn(t+minSize,1f) }
                                DragPart.BR -> { r=(r+dx).coerceIn(l+minSize,1f); b=(b+dy).coerceIn(t+minSize,1f) }
                                DragPart.NONE -> Unit
                            }
                            gestureRect = CropRect(l,t,r,b)
                            onCropChange(gestureRect)
                        }
                    }
                )
            }
        ) {
            val l=offX+crop.left*imageW; val t=offY+crop.top*imageH; val r=offX+crop.right*imageW; val b=offY+crop.bottom*imageH
            drawRect(Color.Black.copy(alpha=.58f), topLeft=Offset(offX,offY), size=androidx.compose.ui.geometry.Size(imageW, max(0f,t-offY)))
            drawRect(Color.Black.copy(alpha=.58f), topLeft=Offset(offX,b), size=androidx.compose.ui.geometry.Size(imageW, max(0f,offY+imageH-b)))
            drawRect(Color.Black.copy(alpha=.58f), topLeft=Offset(offX,t), size=androidx.compose.ui.geometry.Size(max(0f,l-offX), max(0f,b-t)))
            drawRect(Color.Black.copy(alpha=.58f), topLeft=Offset(r,t), size=androidx.compose.ui.geometry.Size(max(0f,offX+imageW-r), max(0f,b-t)))
            drawRect(Color.White, topLeft=Offset(l,t), size=androidx.compose.ui.geometry.Size(r-l,b-t), style=Stroke(width=with(density) { 2.dp.toPx() }))
            listOf(Offset(l,t),Offset(r,t),Offset(l,b),Offset(r,b)).forEach { point ->
                drawCircle(Color.Black.copy(alpha=.65f), handleRadius + 2f, point)
                drawCircle(Color.White, handleRadius, point)
            }
        }
    }
}
