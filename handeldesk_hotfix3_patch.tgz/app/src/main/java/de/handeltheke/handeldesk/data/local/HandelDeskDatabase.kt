package de.handeltheke.handeldesk.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        ProductEntity::class, CategoryEntity::class, ManufacturerEntity::class,
        ChangeEntity::class, AuditEventEntity::class, WorkQueueEntity::class,
        SessionEntity::class, SettingEntity::class, LocalPhotoEntity::class
    ],
    version = 4,
    exportSchema = true,
)
abstract class HandelDeskDatabase : RoomDatabase() {
    abstract fun products(): ProductDao
    abstract fun references(): ReferenceDao
    abstract fun changes(): ChangeDao
    abstract fun audit(): AuditDao
    abstract fun queue(): WorkQueueDao
    abstract fun sessions(): SessionDao
    abstract fun settings(): SettingDao
    abstract fun photos(): LocalPhotoDao

    companion object {
        @Volatile private var instance: HandelDeskDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """CREATE TABLE IF NOT EXISTS `local_photos` (
                        `id` TEXT NOT NULL,
                        `productUuid` TEXT NOT NULL,
                        `fileName` TEXT NOT NULL,
                        `originalPath` TEXT NOT NULL,
                        `processedPath` TEXT NOT NULL,
                        `remoteFolder` TEXT NOT NULL,
                        `remotePath` TEXT NOT NULL,
                        `isMain` INTEGER NOT NULL,
                        `sortOrder` INTEGER NOT NULL,
                        `cropLeft` REAL NOT NULL,
                        `cropTop` REAL NOT NULL,
                        `cropRight` REAL NOT NULL,
                        `cropBottom` REAL NOT NULL,
                        `rotationDegrees` INTEGER NOT NULL,
                        `targetWidth` INTEGER NOT NULL,
                        `targetHeight` INTEGER NOT NULL,
                        `keepAspect` INTEGER NOT NULL,
                        `doNotEnlarge` INTEGER NOT NULL,
                        `sourceWidth` INTEGER NOT NULL,
                        `sourceHeight` INTEGER NOT NULL,
                        `processedWidth` INTEGER NOT NULL,
                        `processedHeight` INTEGER NOT NULL,
                        `sha256` TEXT NOT NULL,
                        `status` TEXT NOT NULL,
                        `error` TEXT NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )""".trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_local_photos_productUuid` ON `local_photos` (`productUuid`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_local_photos_status` ON `local_photos` (`status`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_local_photos_productUuid_sortOrder` ON `local_photos` (`productUuid`, `sortOrder`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_local_photos_remotePath` ON `local_photos` (`remotePath`)")
            }
        }


        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `local_photos` ADD COLUMN `galleryUri` TEXT")
                db.execSQL("ALTER TABLE `local_photos` ADD COLUMN `galleryState` TEXT")
                db.execSQL("ALTER TABLE `local_photos` ADD COLUMN `galleryError` TEXT")
            }
        }


        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `local_photos` ADD COLUMN `sourceUri` TEXT")
                db.execSQL("ALTER TABLE `local_photos` ADD COLUMN `sourceStage` TEXT")
                db.execSQL("ALTER TABLE `local_photos` ADD COLUMN `sourceError` TEXT")
            }
        }

        fun get(context: Context): HandelDeskDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext,
                HandelDeskDatabase::class.java,
                "handeldesk.db"
            )
                .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4)
                .setJournalMode(JournalMode.WRITE_AHEAD_LOGGING)
                .build()
                .also { instance = it }
        }
    }
}
