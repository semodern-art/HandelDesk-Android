package de.handeltheke.handeldesk.domain

import kotlinx.serialization.json.*

data class ProductFieldDiff(val path: String, val before: JsonElement, val after: JsonElement)

object ProductStateDiff {
    private val numericProductPaths = setOf(
        "product.quantity", "product.stock_status_id", "product.manufacturer_id", "product.shipping",
        "product.price", "product.points", "product.tax_class_id", "product.weight", "product.weight_class_id",
        "product.length", "product.width", "product.height", "product.length_class_id", "product.subtract",
        "product.minimum", "product.sort_order", "product.status",
    )

    fun diff(base: JsonObject, target: JsonObject): List<ProductFieldDiff> {
        val out = mutableListOf<ProductFieldDiff>()

        val baseProduct = base["product"] as? JsonObject ?: buildJsonObject { }
        val targetProduct = target["product"] as? JsonObject ?: buildJsonObject { }
        (baseProduct.keys + targetProduct.keys)
            .filterNot { it == "product_id" || it == "revision" }
            .sorted()
            .forEach { key -> add(out, "product.$key", base, target) }

        val baseDescriptions = base["descriptions"] as? JsonObject ?: buildJsonObject { }
        val targetDescriptions = target["descriptions"] as? JsonObject ?: buildJsonObject { }
        (baseDescriptions.keys + targetDescriptions.keys).sortedBy { it.toIntOrNull() ?: Int.MAX_VALUE }.forEach { lang ->
            val b = baseDescriptions[lang] as? JsonObject ?: buildJsonObject { }
            val t = targetDescriptions[lang] as? JsonObject ?: buildJsonObject { }
            (b.keys + t.keys).sorted().forEach { field -> add(out, "descriptions.$lang.$field", base, target) }
        }

        // Everything outside product/descriptions is treated as an atomic top-level section.
        // This keeps restore compatible with future Bridge extension fields without teaching
        // the Android client every possible section name in advance.
        (base.keys + target.keys)
            .filterNot { it == "product" || it == "descriptions" || it == "revision" }
            .sorted()
            .forEach { path -> add(out, path, base, target) }

        return out
    }

    private fun add(out: MutableList<ProductFieldDiff>, path: String, base: JsonObject, target: JsonObject) {
        val before = JsonTools.path(base, path) ?: JsonNull
        val after = JsonTools.path(target, path) ?: JsonNull
        if (!equivalent(path, before, after)) out += ProductFieldDiff(path, before, after)
    }

    private fun equivalent(path: String, a: JsonElement, b: JsonElement): Boolean {
        if (a == b) return true
        if (path in numericProductPaths && a is JsonPrimitive && b is JsonPrimitive) {
            val an = a.content.toBigDecimalOrNull()
            val bn = b.content.toBigDecimalOrNull()
            if (an != null && bn != null) return an.compareTo(bn) == 0
        }
        return false
    }
}
