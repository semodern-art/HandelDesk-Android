package de.handeltheke.handeldesk.ui.components

import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import de.handeltheke.handeldesk.data.local.LocalPhotoEntity

/** Pinch to zoom and pan, with an explicit route to the photo editor. */
@Composable
fun ProductPhotoZoomDialog(remotePath: String, localPhotos: List<LocalPhotoEntity>, onDismiss: () -> Unit, onEdit: () -> Unit, editLabel: String = "К редактированию") {
    var scale by remember(remotePath) { mutableFloatStateOf(1f) }
    var offset by remember(remotePath) { mutableStateOf(Offset.Zero) }
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Просмотр фото · увеличивай двумя пальцами", style = MaterialTheme.typography.titleSmall)
                Box(
                    Modifier.fillMaxWidth().height(330.dp).clip(RoundedCornerShape(10.dp))
                        .pointerInput(remotePath) {
                            detectTransformGestures { _, pan, zoom, _ ->
                                scale = (scale * zoom).coerceIn(1f, 5f)
                                offset = if (scale <= 1f) Offset.Zero else offset + pan
                            }
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    ProductThumbnail(
                        remotePath = remotePath,
                        localPhotos = localPhotos,
                        size = 300.dp,
                        modifier = Modifier.graphicsLayer {
                            scaleX = scale; scaleY = scale
                            translationX = offset.x; translationY = offset.y
                        },
                        contentScale = ContentScale.Fit,
                    )
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("Закрыть") }
                    Button(onClick = onEdit, modifier = Modifier.weight(1f)) { Text(editLabel) }
                }
            }
        }
    }
}
