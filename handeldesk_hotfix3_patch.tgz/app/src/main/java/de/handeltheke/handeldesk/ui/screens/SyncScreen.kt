package de.handeltheke.handeldesk.ui.screens

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import de.handeltheke.handeldesk.HandelDeskApp
import de.handeltheke.handeldesk.data.local.LocalPhotoEntity
import de.handeltheke.handeldesk.data.repo.LocalPhotoRepository
import de.handeltheke.handeldesk.ui.ScreenHeader
import de.handeltheke.handeldesk.ui.components.LocalFileImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.*
import java.io.File

@Composable
fun SyncScreen(onBack: () -> Unit) {
    val app = LocalContext.current.applicationContext as HandelDeskApp
    val scope = rememberCoroutineScope()
    var preview by remember { mutableStateOf<JsonObject?>(null) }
    var running by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var confirm by remember { mutableStateOf("") }
    var productNames by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    val pending by app.container.db.changes().observePending().collectAsState(initial = emptyList())
    val allPhotos by app.container.db.photos().observeAll().collectAsState(initial = emptyList())
    val photoProductUuids = remember(pending) {
        pending.filter { change ->
            change.included && change.entityType == "product" &&
                (change.fieldPath == "__create__" || change.fieldPath == "product.image" || change.fieldPath == "images")
        }.map { it.entityUuid }.toSet()
    }
    val pendingPhotos = remember(allPhotos, photoProductUuids) {
        allPhotos.count { it.productUuid in photoProductUuids && it.status in setOf("READY", "ERROR", "UPLOADING", "UPLOADED") }
    }
    val heldPhotos = remember(allPhotos, photoProductUuids) {
        allPhotos.count { it.productUuid !in photoProductUuids && it.status in setOf("READY", "ERROR", "UPLOADING", "UPLOADED") }
    }
    val collisionPhotos = remember(allPhotos) {
        allPhotos.filter { it.status == "ERROR" && LocalPhotoRepository.collisionPath(it.error) != null }
    }

    LaunchedEffect(preview) {
        val uuids = (preview?.get("results") as? JsonArray).orEmpty().mapNotNull { (it as? JsonObject)?.get("entity_uuid")?.jsonPrimitive?.contentOrNull }.distinct()
        productNames = uuids.associateWith { uuid ->
            app.container.db.products().get(uuid)?.let { it.name.ifBlank { it.model } }.orEmpty()
        }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(
            "Синхронизация",
            "Операций: ${pending.count { it.included }} · фото в очереди: $pendingPhotos",
            onBack
        )
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (pendingPhotos > 0 || heldPhotos > 0) {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("Фото в текущем Sync: $pendingPhotos", style = MaterialTheme.typography.titleSmall)
                        Text("Загружаются только фото тех товаров, у которых включено создание/изменение изображений.", style = MaterialTheme.typography.bodySmall)
                        if (heldPhotos > 0) Text("Ещё $heldPhotos фото остаются только локально и сейчас загружаться не будут.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            if (collisionPhotos.isNotEmpty()) {
                Text("Нужно решить конфликт фото", style = MaterialTheme.typography.titleMedium)
                Text(
                    "На сервере уже есть файл с таким именем, но SHA-256 отличается. Точное совпадение Bridge пропускает автоматически; здесь показываются только неоднозначные случаи.",
                    style = MaterialTheme.typography.bodySmall,
                )
                collisionPhotos.forEach { photo ->
                    PhotoCollisionCard(
                        app = app,
                        photo = photo,
                        onResolved = { text ->
                            message = text
                            preview = null
                            confirm = ""
                        },
                    )
                }
            }

            Button(onClick = {
                scope.launch {
                    running = true; message = null
                    runCatching { app.container.sync.preview() }
                        .onSuccess { preview = it; message = "Preview получен" }
                        .onFailure { message = "Ошибка: ${it.message}" }
                    running = false
                }
            }, enabled = !running && pending.any { it.included }, modifier = Modifier.fillMaxWidth()) { Text("1. ПРОВЕРИТЬ НА СЕРВЕРЕ") }
            if (running) LinearProgressIndicator(Modifier.fillMaxWidth())

            preview?.let { p ->
                val conflicts = p["conflict_count"]?.jsonPrimitive?.intOrNull ?: 0
                val warnings = p["warning_count"]?.jsonPrimitive?.intOrNull ?: 0
                val allowed = p["apply_allowed"]?.jsonPrimitive?.booleanOrNull == true
                val mode = (p["policy"] as? JsonObject)?.get("mode")?.jsonPrimitive?.contentOrNull ?: "?"
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("Bridge mode: $mode")
                        Text("Конфликты: $conflicts")
                        Text("Предупреждения: $warnings")
                        Text(if (allowed) "✓ Apply разрешён" else "✕ Apply заблокирован")
                        (p["policy_errors"] as? JsonArray).orEmpty().forEach { Text("• ${it.jsonPrimitive.content}") }
                    }
                }

                val results = (p["results"] as? JsonArray).orEmpty().mapNotNull { it as? JsonObject }
                if (results.any { ((it["conflicts"] as? JsonArray)?.isNotEmpty() == true) || ((it["warnings"] as? JsonArray)?.isNotEmpty() == true) || it["mode"]?.jsonPrimitive?.contentOrNull == "recover_create" }) {
                    Text("Детали по товарам", style = MaterialTheme.typography.titleMedium)
                    results.forEach { item ->
                        PreviewProductCard(item, productNames[item["entity_uuid"]?.jsonPrimitive?.contentOrNull].orEmpty())
                    }
                }
                val refs = (p["reference_results"] as? JsonArray).orEmpty().mapNotNull { it as? JsonObject }
                    .filter { (it["conflicts"] as? JsonArray)?.isNotEmpty() == true || (it["warnings"] as? JsonArray)?.isNotEmpty() == true }
                refs.forEach { item -> PreviewReferenceCard(item) }

                if (allowed) {
                    OutlinedTextField(confirm, { confirm = it }, label = { Text("Введите APPLY") }, modifier = Modifier.fillMaxWidth())
                    Button(onClick = {
                        scope.launch {
                            running = true
                            message = if (pendingPhotos > 0) "Загрузка фото и синхронизация…" else "Синхронизация…"
                            runCatching { app.container.sync.apply() }
                                .onSuccess { result ->
                                    message = "✓ Успешно ${result["success_count"]?.jsonPrimitive?.intOrNull ?: 0}; ошибок ${result["error_count"]?.jsonPrimitive?.intOrNull ?: 0}"
                                    preview = null; confirm = ""
                                }
                                .onFailure { message = "Ошибка Apply: ${it.message}" }
                            running = false
                        }
                    }, enabled = confirm == "APPLY" && !running && collisionPhotos.isEmpty(), modifier = Modifier.fillMaxWidth()) {
                        Text(if (pendingPhotos > 0) "2. ЗАГРУЗИТЬ ФОТО И APPLY" else "2. APPLY")
                    }
                    if (collisionPhotos.isNotEmpty()) {
                        Text("Сначала решите все конфликты фотографий.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                    }
                }
            }
            message?.let { Text(it) }
            Text("Если товар уже был создан сервером, но приложение не успело зафиксировать ответ, Bridge теперь восстанавливает его по UUID вместо повторного создания.", style = MaterialTheme.typography.bodySmall)
        }
    }
}

private data class CollisionPreview(
    val serverPath: String = "",
    val serverFile: String = "",
    val localInfo: String = "",
    val serverInfo: String = "",
    val visualText: String = "",
    val error: String? = null,
)

@Composable
private fun PhotoCollisionCard(
    app: HandelDeskApp,
    photo: LocalPhotoEntity,
    onResolved: (String) -> Unit,
) {
    val scope = rememberCoroutineScope()
    var busy by remember(photo.id) { mutableStateOf(false) }
    var showLarge by remember(photo.id) { mutableStateOf(false) }
    var confirmReplace by remember(photo.id) { mutableStateOf(false) }
    val productName by produceState(initialValue = "", photo.productUuid) {
        value = app.container.db.products().get(photo.productUuid)?.let { it.name.ifBlank { it.model } }.orEmpty()
    }
    val preview by produceState<CollisionPreview?>(initialValue = null, photo.id, photo.error, photo.remotePath) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                val serverPath = LocalPhotoRepository.collisionPath(photo.error) ?: photo.remotePath
                val serverFile = app.container.imageCache.cache(serverPath, force = true)
                val localFile = File(photo.processedPath)
                require(localFile.isFile) { "Локальный обработанный файл не найден" }
                CollisionPreview(
                    serverPath = serverPath,
                    serverFile = serverFile.absolutePath,
                    localInfo = imageInfo(localFile),
                    serverInfo = imageInfo(serverFile),
                    visualText = visualComparison(localFile, serverFile),
                )
            }.getOrElse { e ->
                CollisionPreview(
                    serverPath = LocalPhotoRepository.collisionPath(photo.error) ?: photo.remotePath,
                    error = e.message ?: "Не удалось загрузить серверное фото",
                )
            }
        }
    }

    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(productName.ifBlank { photo.fileName }, style = MaterialTheme.typography.titleSmall)
            Text(preview?.serverPath ?: photo.remotePath, style = MaterialTheme.typography.bodySmall)

            if (preview == null) {
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Text("Загружаю серверную версию для сравнения…", style = MaterialTheme.typography.bodySmall)
            } else if (preview?.error != null) {
                Text("Не удалось показать серверное фото: ${preview?.error}", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("НА СЕРВЕРЕ", style = MaterialTheme.typography.labelMedium)
                        LocalFileImage(preview!!.serverFile, Modifier.fillMaxWidth(), size = 145.dp, contentScale = ContentScale.Fit)
                        Text(preview!!.serverInfo, style = MaterialTheme.typography.bodySmall)
                    }
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("С ТЕЛЕФОНА", style = MaterialTheme.typography.labelMedium)
                        LocalFileImage(photo.processedPath, Modifier.fillMaxWidth(), size = 145.dp, contentScale = ContentScale.Fit)
                        Text(preview!!.localInfo, style = MaterialTheme.typography.bodySmall)
                    }
                }
                Surface(tonalElevation = 1.dp, shape = MaterialTheme.shapes.medium) {
                    Text(preview!!.visualText, Modifier.padding(10.dp), style = MaterialTheme.typography.bodySmall)
                }
                TextButton(onClick = { showLarge = true }, modifier = Modifier.align(Alignment.End)) { Text("Открыть крупнее") }
            }

            Text(
                "Если SHA-256 совпадает, HandelDesk вообще не показывает этот экран. Разный SHA может означать как другое фото, так и тот же кадр после обрезки/пересохранения JPEG.",
                style = MaterialTheme.typography.bodySmall,
            )

            Button(
                onClick = {
                    scope.launch {
                        busy = true
                        runCatching { app.container.localPhotos.useServerImage(photo.id) }
                            .onSuccess { onResolved("✓ Оставлен существующий файл с сервера. Снова выполните проверку и Apply.") }
                            .onFailure { onResolved("Ошибка: ${it.message}") }
                        busy = false
                    }
                },
                enabled = !busy && preview?.error == null,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("ИСПОЛЬЗОВАТЬ ФАЙЛ С СЕРВЕРА") }

            OutlinedButton(
                onClick = {
                    scope.launch {
                        busy = true
                        runCatching { app.container.localPhotos.renameCollisionAndRetry(photo.id) }
                            .onSuccess { name -> onResolved("✓ Локальное фото получило свободное имя $name. Снова выполните проверку и Apply.") }
                            .onFailure { onResolved("Ошибка: ${it.message}") }
                        busy = false
                    }
                },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("ЗАГРУЗИТЬ КАК НОВЫЙ ФАЙЛ") }

            TextButton(
                onClick = { confirmReplace = true },
                enabled = !busy && preview?.error == null,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("ЗАМЕНИТЬ ФАЙЛ НА СЕРВЕРЕ") }
        }
    }

    if (showLarge && preview?.error == null) {
        Dialog(onDismissRequest = { showLarge = false }) {
            Surface(shape = MaterialTheme.shapes.large) {
                Column(
                    Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text("Сравнение фото", style = MaterialTheme.typography.titleLarge)
                    Text("На сервере", style = MaterialTheme.typography.titleSmall)
                    LocalFileImage(preview!!.serverFile, size = 300.dp, contentScale = ContentScale.Fit)
                    Text("С телефона", style = MaterialTheme.typography.titleSmall)
                    LocalFileImage(photo.processedPath, size = 300.dp, contentScale = ContentScale.Fit)
                    Text(preview!!.visualText, style = MaterialTheme.typography.bodyMedium)
                    Button(onClick = { showLarge = false }) { Text("Закрыть") }
                }
            }
        }
    }

    if (confirmReplace) {
        AlertDialog(
            onDismissRequest = { if (!busy) confirmReplace = false },
            title = { Text("Заменить серверный файл?") },
            text = {
                Text("Файл по этому пути будет перезаписан. Если он используется другим товаром, изображение изменится и там. Используйте это только если уверены, что серверная версия неправильная.")
            },
            confirmButton = {
                Button(onClick = {
                    scope.launch {
                        busy = true
                        runCatching { app.container.localPhotos.replaceServerImage(photo.id) }
                            .onSuccess {
                                confirmReplace = false
                                onResolved("✓ Серверный файл заменён локальной версией. Снова выполните проверку и Apply.")
                            }
                            .onFailure { onResolved("Ошибка замены: ${it.message}") }
                        busy = false
                    }
                }, enabled = !busy) { Text("ЗАМЕНИТЬ") }
            },
            dismissButton = { TextButton(onClick = { confirmReplace = false }, enabled = !busy) { Text("Отмена") } },
        )
    }
}

private fun imageInfo(file: File): String {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(file.absolutePath, bounds)
    val size = when {
        file.length() >= 1024L * 1024L -> "%.1f MB".format(file.length().toDouble() / (1024.0 * 1024.0))
        else -> "%.0f KB".format(file.length().toDouble() / 1024.0)
    }
    return if (bounds.outWidth > 0 && bounds.outHeight > 0) "${bounds.outWidth}×${bounds.outHeight} · $size" else size
}

private fun visualComparison(local: File, server: File): String {
    val a = dHash(local)
    val b = dHash(server)
    if (a == null || b == null) return "Автосравнение не удалось — сравните изображения визуально."
    val distance = java.lang.Long.bitCount(a xor b)
    return when {
        distance <= 3 -> "Визуально почти идентичны (dHash $distance/64). Вероятно, это тот же кадр, но файл был пересохранён."
        distance <= 10 -> "Изображения очень похожи (dHash $distance/64). Проверьте крупное сравнение."
        distance <= 18 -> "Есть заметное сходство (dHash $distance/64), но безопаснее проверить вручную."
        else -> "Изображения выглядят различными (dHash $distance/64)."
    }
}

private fun dHash(file: File): Long? {
    val decoded = BitmapFactory.decodeFile(file.absolutePath) ?: return null
    val scaled = try {
        Bitmap.createScaledBitmap(decoded, 9, 8, true)
    } catch (_: Throwable) {
        if (!decoded.isRecycled) decoded.recycle()
        return null
    }
    if (scaled !== decoded && !decoded.isRecycled) decoded.recycle()
    return try {
        var hash = 0L
        for (y in 0 until 8) {
            for (x in 0 until 8) {
                val left = luminance(scaled.getPixel(x, y))
                val right = luminance(scaled.getPixel(x + 1, y))
                hash = hash shl 1
                if (left > right) hash = hash or 1L
            }
        }
        hash
    } finally {
        if (!scaled.isRecycled) scaled.recycle()
    }
}

private fun luminance(pixel: Int): Int {
    val r = (pixel shr 16) and 0xff
    val g = (pixel shr 8) and 0xff
    val b = pixel and 0xff
    return (299 * r + 587 * g + 114 * b) / 1000
}

@Composable
private fun PreviewProductCard(item: JsonObject, productName: String) {
    var expanded by remember(item.toString()) { mutableStateOf(false) }
    val mode = item["mode"]?.jsonPrimitive?.contentOrNull.orEmpty()
    val conflicts = (item["conflicts"] as? JsonArray).orEmpty()
    val warnings = (item["warnings"] as? JsonArray).orEmpty()
    val productId = item["product_id"]?.jsonPrimitive?.intOrNull
    Card(Modifier.fillMaxWidth().clickable { expanded = !expanded }) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text(productName.ifBlank { "Товар" }, style = MaterialTheme.typography.titleSmall)
                    Text("$mode${productId?.let { " · #$it" }.orEmpty()} · конфликтов ${conflicts.size} · предупреждений ${warnings.size}", style = MaterialTheme.typography.bodySmall)
                    if (mode == "recover_create") Text("✓ Будет восстановлена уже выполненная операция создания", style = MaterialTheme.typography.bodySmall)
                }
                Text(if (expanded) "⌃" else "⌄")
            }
            if (expanded) {
                conflicts.forEach { ConflictLine(it as? JsonObject, true) }
                warnings.forEach { ConflictLine(it as? JsonObject, false) }
            }
        }
    }
}

@Composable
private fun PreviewReferenceCard(item: JsonObject) {
    val type = item["entity_type"]?.jsonPrimitive?.contentOrNull.orEmpty()
    val conflicts = (item["conflicts"] as? JsonArray).orEmpty()
    val warnings = (item["warnings"] as? JsonArray).orEmpty()
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(10.dp)) {
            Text("$type · конфликтов ${conflicts.size} · предупреждений ${warnings.size}", style = MaterialTheme.typography.titleSmall)
            conflicts.forEach { ConflictLine(it as? JsonObject, true) }
            warnings.forEach { ConflictLine(it as? JsonObject, false) }
        }
    }
}

@Composable
private fun ConflictLine(row: JsonObject?, conflict: Boolean) {
    if (row == null) return
    val path = row["path"]?.jsonPrimitive?.contentOrNull.orEmpty()
    val reason = row["reason"]?.jsonPrimitive?.contentOrNull.orEmpty()
    Text("${if (conflict) "✕" else "⚠"} $path · $reason", style = MaterialTheme.typography.bodySmall, color = if (conflict) MaterialTheme.colorScheme.error else LocalContentColor.current)
    row["server"]?.let { Text("server: ${it.toString().take(160)}", style = MaterialTheme.typography.bodySmall) }
    row["local"]?.let { Text("local: ${it.toString().take(160)}", style = MaterialTheme.typography.bodySmall) }
}
