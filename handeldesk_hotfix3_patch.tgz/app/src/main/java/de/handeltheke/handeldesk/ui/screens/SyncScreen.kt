package de.handeltheke.handeldesk.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import de.handeltheke.handeldesk.HandelDeskApp
import de.handeltheke.handeldesk.ui.ScreenHeader
import kotlinx.coroutines.launch
import kotlinx.serialization.json.*

@Composable
fun SyncScreen(onBack: () -> Unit) {
    val app = LocalContext.current.applicationContext as HandelDeskApp
    val scope = rememberCoroutineScope()
    var preview by remember { mutableStateOf<JsonObject?>(null) }
    var running by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var confirm by remember { mutableStateOf("") }
    var productNames by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    val pending by app.container.db.changes().observePending().collectAsState(initial = emptyList())
    val pendingPhotos by app.container.db.photos().observePendingCount().collectAsState(initial = 0)

    LaunchedEffect(preview) {
        val uuids = (preview?.get("results") as? JsonArray).orEmpty().mapNotNull { (it as? JsonObject)?.get("entity_uuid")?.jsonPrimitive?.contentOrNull }.distinct()
        productNames = uuids.associateWith { uuid ->
            app.container.db.products().get(uuid)?.let { it.name.ifBlank { it.model } }.orEmpty()
        }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(
            "Синхронизация",
            "Операций: ${pending.count { it.included }} · фото в очереди: $pendingPhotos",
            onBack
        )
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (pendingPhotos > 0) {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("Фото готовы к синхронизации: $pendingPhotos", style = MaterialTheme.typography.titleSmall)
                        Text("При APPLY они сначала загрузятся в выбранные папки, затем карточки товаров получат уже существующие пути.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            Button(onClick = {
                scope.launch {
                    running = true; message = null
                    runCatching { app.container.sync.preview() }
                        .onSuccess { preview = it; message = "Preview получен" }
                        .onFailure { message = "Ошибка: ${it.message}" }
                    running = false
                }
            }, enabled = !running && pending.any { it.included }, modifier = Modifier.fillMaxWidth()) { Text("1. ПРОВЕРИТЬ НА СЕРВЕРЕ") }
            if (running) LinearProgressIndicator(Modifier.fillMaxWidth())

            preview?.let { p ->
                val conflicts = p["conflict_count"]?.jsonPrimitive?.intOrNull ?: 0
                val warnings = p["warning_count"]?.jsonPrimitive?.intOrNull ?: 0
                val allowed = p["apply_allowed"]?.jsonPrimitive?.booleanOrNull == true
                val mode = (p["policy"] as? JsonObject)?.get("mode")?.jsonPrimitive?.contentOrNull ?: "?"
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("Bridge mode: $mode")
                        Text("Конфликты: $conflicts")
                        Text("Предупреждения: $warnings")
                        Text(if (allowed) "✓ Apply разрешён" else "✕ Apply заблокирован")
                        (p["policy_errors"] as? JsonArray).orEmpty().forEach { Text("• ${it.jsonPrimitive.content}") }
                    }
                }

                val results = (p["results"] as? JsonArray).orEmpty().mapNotNull { it as? JsonObject }
                if (results.any { ((it["conflicts"] as? JsonArray)?.isNotEmpty() == true) || ((it["warnings"] as? JsonArray)?.isNotEmpty() == true) || it["mode"]?.jsonPrimitive?.contentOrNull == "recover_create" }) {
                    Text("Детали по товарам", style = MaterialTheme.typography.titleMedium)
                    results.forEach { item ->
                        PreviewProductCard(item, productNames[item["entity_uuid"]?.jsonPrimitive?.contentOrNull].orEmpty())
                    }
                }
                val refs = (p["reference_results"] as? JsonArray).orEmpty().mapNotNull { it as? JsonObject }
                    .filter { (it["conflicts"] as? JsonArray)?.isNotEmpty() == true || (it["warnings"] as? JsonArray)?.isNotEmpty() == true }
                refs.forEach { item -> PreviewReferenceCard(item) }

                if (allowed) {
                    OutlinedTextField(confirm, { confirm = it }, label = { Text("Введите APPLY") }, modifier = Modifier.fillMaxWidth())
                    Button(onClick = {
                        scope.launch {
                            running = true
                            message = if (pendingPhotos > 0) "Загрузка фото и синхронизация…" else "Синхронизация…"
                            runCatching { app.container.sync.apply() }
                                .onSuccess { result ->
                                    message = "✓ Успешно ${result["success_count"]?.jsonPrimitive?.intOrNull ?: 0}; ошибок ${result["error_count"]?.jsonPrimitive?.intOrNull ?: 0}"
                                    preview = null; confirm = ""
                                }
                                .onFailure { message = "Ошибка Apply: ${it.message}" }
                            running = false
                        }
                    }, enabled = confirm == "APPLY" && !running, modifier = Modifier.fillMaxWidth()) {
                        Text(if (pendingPhotos > 0) "2. ЗАГРУЗИТЬ ФОТО И APPLY" else "2. APPLY")
                    }
                }
            }
            message?.let { Text(it) }
            Text("Если товар уже был создан сервером, но приложение не успело зафиксировать ответ, Bridge теперь восстанавливает его по UUID вместо повторного создания.", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun PreviewProductCard(item: JsonObject, productName: String) {
    var expanded by remember(item.toString()) { mutableStateOf(false) }
    val mode = item["mode"]?.jsonPrimitive?.contentOrNull.orEmpty()
    val conflicts = (item["conflicts"] as? JsonArray).orEmpty()
    val warnings = (item["warnings"] as? JsonArray).orEmpty()
    val productId = item["product_id"]?.jsonPrimitive?.intOrNull
    Card(Modifier.fillMaxWidth().clickable { expanded = !expanded }) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text(productName.ifBlank { "Товар" }, style = MaterialTheme.typography.titleSmall)
                    Text("$mode${productId?.let { " · #$it" }.orEmpty()} · конфликтов ${conflicts.size} · предупреждений ${warnings.size}", style = MaterialTheme.typography.bodySmall)
                    if (mode == "recover_create") Text("✓ Будет восстановлена уже выполненная операция создания", style = MaterialTheme.typography.bodySmall)
                }
                Text(if (expanded) "⌃" else "⌄")
            }
            if (expanded) {
                conflicts.forEach { ConflictLine(it as? JsonObject, true) }
                warnings.forEach { ConflictLine(it as? JsonObject, false) }
            }
        }
    }
}

@Composable
private fun PreviewReferenceCard(item: JsonObject) {
    val type = item["entity_type"]?.jsonPrimitive?.contentOrNull.orEmpty()
    val conflicts = (item["conflicts"] as? JsonArray).orEmpty()
    val warnings = (item["warnings"] as? JsonArray).orEmpty()
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(10.dp)) {
            Text("$type · конфликтов ${conflicts.size} · предупреждений ${warnings.size}", style = MaterialTheme.typography.titleSmall)
            conflicts.forEach { ConflictLine(it as? JsonObject, true) }
            warnings.forEach { ConflictLine(it as? JsonObject, false) }
        }
    }
}

@Composable
private fun ConflictLine(row: JsonObject?, conflict: Boolean) {
    if (row == null) return
    val path = row["path"]?.jsonPrimitive?.contentOrNull.orEmpty()
    val reason = row["reason"]?.jsonPrimitive?.contentOrNull.orEmpty()
    Text("${if (conflict) "✕" else "⚠"} $path · $reason", style = MaterialTheme.typography.bodySmall, color = if (conflict) MaterialTheme.colorScheme.error else LocalContentColor.current)
    row["server"]?.let { Text("server: ${it.toString().take(160)}", style = MaterialTheme.typography.bodySmall) }
    row["local"]?.let { Text("local: ${it.toString().take(160)}", style = MaterialTheme.typography.bodySmall) }
}
