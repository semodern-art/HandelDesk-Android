package de.handeltheke.handeldesk.domain

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue
import kotlinx.serialization.json.*

class ProductJsonAndSchemaTest {
    @Test
    fun displayNameFallsBackToFirstNonBlankDescription() {
        val payload = JsonObject(ProductJson.blank().toMutableMap().apply {
            put("descriptions", buildJsonObject {
                put("1", buildJsonObject { put("name", "") })
                put("2", buildJsonObject { put("name", "Полное название товара") })
            })
        })
        assertEquals("Полное название товара", ProductJson.displayName(payload, "1"))
        assertEquals("Полное название товара", ProductJson.index(payload, "1").name)
    }

    @Test
    fun bridgeSchemaKeepsOptionDefinitionsAndValues() {
        val schema = buildJsonObject {
            put("languages", buildJsonArray {})
            put("options", buildJsonArray {
                add(buildJsonObject {
                    put("option_id", 7)
                    put("name", "Цвет")
                    put("type", "select")
                    put("sort_order", 2)
                    put("values", buildJsonArray {
                        add(buildJsonObject { put("option_value_id", 71); put("name", "Чёрный"); put("sort_order", 1) })
                        add(buildJsonObject { put("option_value_id", 72); put("name", "Белый"); put("sort_order", 2) })
                    })
                })
            })
        }
        val labels = BridgeSchemaLabels.fromSchemaJson(schema.toString())
        val option = labels.optionDefinition("7")
        assertEquals("Цвет", option?.name)
        assertEquals("select", option?.type)
        assertEquals(listOf("Чёрный", "Белый"), option?.values?.map { it.name })
        assertEquals("Белый", labels.optionValue("72"))
        assertTrue(labels.optionDefinitions.isNotEmpty())
    }
}
