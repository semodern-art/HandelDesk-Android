package de.handeltheke.handeldesk.domain

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue
import kotlinx.serialization.json.*

class ProductStateDiffTest {
    @Test
    fun restoreDiffTreatsWholeArraysAsAtomicFields() {
        val base = ProductJson.blank()
        val target = JsonTools.setPath(
            JsonTools.setPath(base, "product.model", JsonPrimitive("ECDP-40FB C")),
            "images",
            buildJsonArray {
                add(buildJsonObject { put("image", "catalog/product/Fernbedienungen/a.jpg"); put("sort_order", 0) })
            }
        )
        val diffs = ProductStateDiff.diff(base, target)
        assertTrue(diffs.any { it.path == "product.model" })
        assertTrue(diffs.any { it.path == "images" })
        assertEquals(2, diffs.size)
    }

    @Test
    fun numericPriceFormattingDoesNotCreateFalseDiffs() {
        val base = JsonTools.setPath(ProductJson.blank(), "product.price", JsonPrimitive("12.00"))
        val target = JsonTools.setPath(ProductJson.blank(), "product.price", JsonPrimitive("12.0000"))
        assertTrue(ProductStateDiff.diff(base, target).none { it.path == "product.price" })
    }

    @Test
    fun numericLookingModelIsNeverTreatedAsANumber() {
        val base = JsonTools.setPath(ProductJson.blank(), "product.model", JsonPrimitive("001"))
        val target = JsonTools.setPath(ProductJson.blank(), "product.model", JsonPrimitive("1"))
        assertTrue(ProductStateDiff.diff(base, target).any { it.path == "product.model" })
    }
    @Test
    fun futureTopLevelSectionsAreNotLost() {
        val base = ProductJson.blank()
        val target = JsonObject(base.toMutableMap().apply {
            put("future_extension", buildJsonObject { put("enabled", true) })
        })
        assertTrue(ProductStateDiff.diff(base, target).any { it.path == "future_extension" })
    }

}
