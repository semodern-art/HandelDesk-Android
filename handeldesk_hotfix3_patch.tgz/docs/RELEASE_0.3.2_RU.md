# HandelDesk 0.3.2 — Travel Ready

Перед поездкой релиз сфокусирован на надёжности офлайн-работы без изменения Bridge-протокола.

## Multi Replace
- В «Быстрой замене по донору» можно добавить до 8 атомарных замен одним действием.
- Замены применяются одновременно к исходному тексту и не каскадируют.
- Короткие значения (например `2A`) защищены границами идентификатора.
- Есть предпросмотр названия и модели.
- Все строки входят в одну точку History/Undo.

## Backup / Restore
- ZIP содержит Room DB (товары, черновики, ChangeSet, History/Undo, очередь, настройки, фото-связки), внутренние оригиналы/обработанные фото HandelDesk и Bridge URL/device name.
- Device Token не экспортируется из Android Keystore.
- По желанию можно добавить большой offline image cache.
- Перед восстановлением проверяются manifest, размеры, SHA-256 каждого файла, SQLite `integrity_check`, `user_version` и обязательные таблицы.
- Импорт БД выполняется одной SQLite-транзакцией. Рабочие фото меняются через rollback-safe directory swap.

## Travel Ready
Экран «Готовность к поездке / Backup» проверяет:
- целостность БД и количество товаров;
- справочники;
- доступ к папке HandelDesk;
- свободное место;
- offline image cache;
- свежесть Full/Delta;
- Bridge configuration/token presence;
- свежесть backup;
- несинхронизированные изменения и фото;
- History/Undo.

## Диагностика
- Экспорт TXT и копирование в clipboard.
- Отчёт содержит версию, Android/device, DB quick_check/counts, storage, workspace, Bridge без token, offline timestamps, readiness и последние audit events.
- Последний uncaught crash сохраняется локально и попадает в диагностический отчёт.

## Autosave
Карточка товара явно показывает время последнего локального сохранения и задержку автосохранения 0,5 с.

DB schema остаётся v5. Bridge остаётся 0.4.8.
