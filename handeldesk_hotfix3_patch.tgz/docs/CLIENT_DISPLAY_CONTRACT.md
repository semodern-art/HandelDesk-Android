# HandelDesk client display contract

`language_id`, `option_id` and `option_value_id` are transport/storage keys, not UI labels.

Every client (Android, desktop, web, future clients) must resolve them through the Bridge `schema` response:

- `schema.languages[].language_id` -> `schema.languages[].name` (fallback: `code`)
- `schema.options[].option_id` -> `schema.options[].name`
- `schema.options[].values[].option_value_id` -> `schema.options[].values[].name`

The numeric ID may be logged for diagnostics but must not be the primary user-facing text.
This keeps OpenCart as the source of truth: renaming a language, option or option value is picked up after schema sync without a client release.
