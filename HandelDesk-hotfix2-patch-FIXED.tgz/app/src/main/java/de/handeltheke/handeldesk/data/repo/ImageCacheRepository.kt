package de.handeltheke.handeldesk.data.repo

import android.content.Context
import de.handeltheke.handeldesk.data.local.HandelDeskDatabase
import de.handeltheke.handeldesk.data.remote.BridgeClient
import de.handeltheke.handeldesk.data.remote.BridgeException
import de.handeltheke.handeldesk.domain.JsonTools
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.*
import java.io.EOFException
import java.io.File
import java.io.IOException
import java.net.ConnectException
import java.net.SocketException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.security.MessageDigest
import javax.net.ssl.SSLHandshakeException

class ImageCacheRepository(
    context: Context,
    private val db: HandelDeskDatabase,
    private val bridge: BridgeClient,
) {
    private val root = File(context.filesDir, "image-cache").apply { mkdirs() }

    data class Progress(val current: Int, val total: Int, val path: String)
    private data class ImageRef(val revision: String?, val mtime: Long?, val size: Long?)
    data class VerifySummary(
        val checked: Int,
        val downloaded: Int,
        val removed: Int,
        val unchanged: Int,
    ) {
        fun userText() = "Фото: проверено $checked · обновлено $downloaded · удалено $removed · без изменений $unchanged"
    }

    fun cachedFile(remotePath: String): File? {
        if (remotePath.isBlank()) return null
        val file = fileFor(remotePath)
        return file.takeIf { it.isFile && it.length() > 0 }
    }

    suspend fun cache(
        remotePath: String,
        expectedRevision: String? = null,
        expectedMtime: Long? = null,
        expectedSize: Long? = null,
        force: Boolean = false,
    ): File = withContext(Dispatchers.IO) {
        require(remotePath.isNotBlank()) { "Пустой путь изображения" }
        val target = fileFor(remotePath)
        val revisionFile = revisionFileFor(remotePath)
        val localRevision = revisionFile.takeIf(File::isFile)?.readText()?.trim().orEmpty()

        val reusable = target.isFile && target.length() > 0 && !force && (
            expectedRevision.isNullOrBlank() || localRevision == expectedRevision
        )
        if (reusable) return@withContext target

        // Migration from pre-0.1.4 cache: no .rev sidecar existed yet. If the cached file
        // was downloaded after the server file's mtime and has the same size, adopt it
        // without re-downloading thousands of unchanged photos.
        if (!force && target.isFile && target.length() > 0 && localRevision.isBlank() &&
            !expectedRevision.isNullOrBlank() && expectedMtime != null && expectedSize != null &&
            target.length() == expectedSize && target.lastModified() + 2_000L >= expectedMtime * 1000L
        ) {
            revisionFile.writeText(expectedRevision)
            return@withContext target
        }

        val bytes = bridge.getBytes("image_fetch", mapOf("path" to remotePath))
        require(bytes.size >= 16) { "Bridge вернул пустое изображение" }
        val tmp = File(target.parentFile, target.name + ".tmp")
        tmp.writeBytes(bytes)
        if (target.exists()) target.delete()
        require(tmp.renameTo(target)) { "Не удалось сохранить кеш изображения" }

        if (!expectedRevision.isNullOrBlank()) {
            revisionFile.writeText(expectedRevision)
        } else if (revisionFile.exists()) {
            revisionFile.delete()
        }
        target
    }

    suspend fun prepare(mode: String, onProgress: suspend (Progress) -> Unit = {}) {
        if (mode == "none") return
        val refs = localImageRefs(mode)
        refs.entries.forEachIndexed { index, (path, ref) ->
            onProgress(Progress(index, refs.size, path))
            try {
                cache(path, ref.revision, ref.mtime, ref.size)
            } catch (t: Throwable) {
                if (isRetryableNetworkError(t)) throw t
                // One broken/removed image must not abort the complete offline package.
            }
        }
        onProgress(Progress(refs.size, refs.size, "Готово"))
    }

    /**
     * Compares local cached files with the server's cheap image manifest (mtime + filesize).
     * It does not download image bytes unless a file is missing or its revision changed.
     */
    suspend fun verifyAndRepair(
        mode: String,
        onProgress: suspend (Progress) -> Unit = {},
    ): VerifySummary {
        if (mode == "none") return VerifySummary(0, 0, 0, 0)
        val refs = localImageRefs(mode)
        val paths = refs.keys.toList()
        var checked = 0
        var downloaded = 0
        var removed = 0
        var unchanged = 0

        for (chunk in paths.chunked(200)) {
            val body = buildJsonObject {
                put("paths", JsonArray(chunk.map { JsonPrimitive(it) }))
            }
            val root = bridge.post("image_manifest", body)
            val manifest = root["images"]?.jsonObject.orEmpty()

            for (path in chunk) {
                val meta = manifest[path]?.jsonObject
                val exists = meta?.get("exists")?.jsonPrimitive?.booleanOrNull == true
                val revision = meta?.get("revision")?.jsonPrimitive?.contentOrNull.orEmpty()
                val serverMtime = meta?.get("mtime")?.jsonPrimitive?.longOrNull
                val serverSize = meta?.get("size")?.jsonPrimitive?.longOrNull
                val target = fileFor(path)
                val revFile = revisionFileFor(path)
                val localRevision = revFile.takeIf(File::isFile)?.readText()?.trim().orEmpty()

                checked++
                onProgress(Progress(checked, paths.size, path))

                if (!exists) {
                    var changed = false
                    if (target.exists()) changed = target.delete() || changed
                    if (revFile.exists()) changed = revFile.delete() || changed
                    if (changed) removed++ else unchanged++
                    continue
                }

                if (!target.isFile || target.length() <= 0 || revision.isBlank() || localRevision != revision) {
                    try {
                        val canAdoptLegacy = localRevision.isBlank() && target.isFile && target.length() > 0 &&
                            revision.isNotBlank() && serverSize != null && target.length() == serverSize &&
                            serverMtime != null && target.lastModified() + 2_000L >= serverMtime * 1000L
                        cache(
                            path,
                            revision.takeIf(String::isNotBlank),
                            serverMtime,
                            serverSize,
                            force = false,
                        )
                        if (canAdoptLegacy) unchanged++ else downloaded++
                    } catch (t: Throwable) {
                        if (isRetryableNetworkError(t)) throw t
                        // Keep going when a single image is broken on the server.
                    }
                } else {
                    unchanged++
                }
            }
        }
        onProgress(Progress(paths.size, paths.size, "Готово"))
        return VerifySummary(checked, downloaded, removed, unchanged)
    }

    suspend fun clearAll(): Int = withContext(Dispatchers.IO) {
        val files = root.listFiles().orEmpty()
        var deleted = 0
        for (file in files) {
            if (file.isFile && file.delete()) deleted++
        }
        deleted
    }

    suspend fun cacheStats(): Pair<Int, Long> = withContext(Dispatchers.IO) {
        val files = root.listFiles()?.filter { it.isFile && !it.name.endsWith(".rev") }.orEmpty()
        files.size to files.sumOf(File::length)
    }

    private suspend fun localImageRefs(mode: String): LinkedHashMap<String, ImageRef> {
        val refs = linkedMapOf<String, ImageRef>()
        db.products().all().forEach { product ->
            val payload = JsonTools.objectOf(product.localJson)
            val imageMeta = payload["image_meta"]?.jsonObject.orEmpty()

            fun add(path: String) {
                if (path.isBlank()) return
                val meta = imageMeta[path]?.jsonObject
                val revision = meta?.get("revision")?.jsonPrimitive?.contentOrNull?.takeIf(String::isNotBlank)
                val mtime = meta?.get("mtime")?.jsonPrimitive?.longOrNull
                val size = meta?.get("size")?.jsonPrimitive?.longOrNull
                val incoming = ImageRef(revision, mtime, size)
                val existing = refs[path]
                refs[path] = if (incoming.revision != null) incoming else (existing ?: incoming)
            }

            val main = payload["product"]?.jsonObject?.get("image")?.jsonPrimitive?.contentOrNull.orEmpty()
            add(main)
            if (mode == "all") {
                (payload["images"] as? JsonArray).orEmpty().forEach { row ->
                    add(row.jsonObject["image"]?.jsonPrimitive?.contentOrNull.orEmpty())
                }
            }
        }
        return LinkedHashMap(refs)
    }

    private fun isRetryableNetworkError(t: Throwable): Boolean {
        var current: Throwable? = t
        while (current != null) {
            when (current) {
                is UnknownHostException,
                is ConnectException,
                is SocketTimeoutException,
                is SocketException,
                is EOFException -> return true
                is SSLHandshakeException -> return false
                is BridgeException -> {
                    val status = current.status
                    return status == 408 || status == 429 || (status != null && status in 500..599)
                }
                is IOException -> return true
            }
            current = current.cause
        }
        return false
    }

    private fun fileFor(remotePath: String): File {
        val digest = pathDigest(remotePath)
        val ext = remotePath.substringAfterLast('.', "img").lowercase()
            .takeIf { it in setOf("jpg", "jpeg", "png", "gif", "webp") } ?: "img"
        return File(root, "$digest.$ext")
    }

    private fun revisionFileFor(remotePath: String): File = File(root, "${pathDigest(remotePath)}.rev")

    private fun pathDigest(remotePath: String): String = MessageDigest.getInstance("SHA-256")
        .digest(remotePath.toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it) }
}
