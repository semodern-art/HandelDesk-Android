package de.handeltheke.handeldesk.worker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.content.ContextCompat
import androidx.core.app.NotificationCompat
import de.handeltheke.handeldesk.HandelDeskApp
import de.handeltheke.handeldesk.data.local.SettingEntity
import de.handeltheke.handeldesk.data.remote.BridgeException
import de.handeltheke.handeldesk.data.repo.ImageCacheRepository
import de.handeltheke.handeldesk.data.repo.SnapshotRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.EOFException
import java.io.IOException
import java.net.ConnectException
import java.net.SocketException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import javax.net.ssl.SSLHandshakeException

class OfflinePrepareService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var app: HandelDeskApp
    private var syncJob: Job? = null
    private var lastImagePublished = -1
    private var completed = false
    private var heartbeatJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        app = application as HandelDeskApp
        OfflinePrepareRuntime.setActive(true)
        createNotificationChannel()
        heartbeatJob = scope.launch {
            while (isActive) {
                app.container.db.settings().put(SettingEntity("offline_job_heartbeat_at", System.currentTimeMillis().toString()))
                delay(HEARTBEAT_INTERVAL_MS)
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            scope.launch {
                publishState(STATE_CANCELLED, "Фоновая задача остановлена. Checkpoint сохранён.", 0, 0, "cancelled", notify = false)
                completed = true
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            return START_NOT_STICKY
        }

        if (syncJob?.isActive == true) return START_STICKY

        val requestedImageMode = intent?.getStringExtra(EXTRA_IMAGE_MODE)
            ?.takeIf { it in setOf("none", "main", "all") }

        startAsForeground("Запуск фонового обновления", 0, 0)
        syncJob = scope.launch { runSyncLoop(requestedImageMode) }
        return START_STICKY
    }

    private suspend fun runSyncLoop(requestedImageMode: String?) {
        var imageMode = requestedImageMode
            ?: app.container.db.settings().get("offline_image_mode")?.takeIf { it in setOf("none", "main", "all") }
            ?: "main"
        if (requestedImageMode != null) {
            app.container.db.settings().put(SettingEntity("offline_image_mode", imageMode))
        }

        while (scope.isActive) {
            try {
                imageMode = app.container.db.settings().get("offline_image_mode")
                    ?.takeIf { it in setOf("none", "main", "all") }
                    ?: imageMode

                publishState(STATE_RUNNING, "Проверка соединения", 0, 0, "start", notify = true)
                val summary = app.container.snapshot.refresh { p -> publishSnapshotProgress(p) }
                app.container.imageCache.prepare(imageMode) { p -> publishImageProgress(p) }
                val stats = app.container.imageCache.cacheStats()
                val refWarning = app.container.db.settings().get("reference_refresh_warning").orEmpty()
                val message = "✓ OFFLINE READY · ${summary.userText()} · фото ${stats.first}" +
                    if (refWarning.isNotBlank()) " · ⚠ справочники: локальный кеш" else ""
                publishState(STATE_READY, message, 0, 0, "done", notify = false)
                completed = true
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (t: Throwable) {
                if (isRetryableNetworkError(t)) {
                    publishState(
                        STATE_WAITING_NETWORK,
                        "Сетевая ошибка: ${networkErrorText(t)}. Checkpoint сохранён — повтор через 10 секунд.",
                        0,
                        0,
                        "network",
                        notify = true,
                    )
                    delay(RETRY_DELAY_MS)
                } else {
                    val message = "Ошибка: ${t.message ?: t::class.java.simpleName}"
                    publishState(STATE_ERROR, message, 0, 0, "error", notify = false)
                    completed = true
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                    return
                }
            }
        }
    }

    private suspend fun publishSnapshotProgress(p: SnapshotRepository.Progress) {
        publishState(STATE_RUNNING, p.message, p.current, p.total, "snapshot", notify = true)
    }

    private suspend fun publishImageProgress(p: ImageCacheRepository.Progress) {
        val shouldPublish = p.current == p.total || p.current == 0 || p.current - lastImagePublished >= 10
        if (!shouldPublish) return
        lastImagePublished = p.current
        val name = p.path.takeLast(60)
        publishState(
            STATE_RUNNING,
            if (p.total > 0) "Фото ${p.current}/${p.total}: $name" else "Подготовка фото",
            p.current,
            p.total,
            "images",
            notify = true,
        )
    }

    private suspend fun publishState(
        state: String,
        message: String,
        current: Int,
        total: Int,
        stage: String,
        notify: Boolean,
    ) {
        val settings = app.container.db.settings()
        settings.put(SettingEntity("offline_job_state", state))
        settings.put(SettingEntity("offline_job_message", message))
        settings.put(SettingEntity("offline_job_current", current.toString()))
        settings.put(SettingEntity("offline_job_total", total.toString()))
        settings.put(SettingEntity("offline_job_stage", stage))
        val now = System.currentTimeMillis().toString()
        settings.put(SettingEntity("offline_job_updated_at", now))
        settings.put(SettingEntity("offline_job_heartbeat_at", now))
        if (notify) updateNotification(message, current, total)
    }

    private fun startAsForeground(message: String, current: Int, total: Int) {
        val notification = buildNotification(message, current, total)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun updateNotification(message: String, current: Int, total: Int) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, buildNotification(message, current, total))
    }

    private fun buildNotification(message: String, current: Int, total: Int) =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("HandelDesk · Offline")
            .setContentText(message)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setProgress(total.coerceAtLeast(0), current.coerceAtLeast(0), total <= 0)
            .build()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "HandelDesk Offline Sync", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Фоновая подготовка каталога и изображений для офлайн-работы"
                    setShowBadge(false)
                }
            )
        }
    }

    private fun isRetryableNetworkError(t: Throwable): Boolean {
        var current: Throwable? = t
        while (current != null) {
            when (current) {
                is UnknownHostException,
                is ConnectException,
                is SocketTimeoutException,
                is SocketException,
                is EOFException -> return true
                is SSLHandshakeException -> return false
                is BridgeException -> {
                    val status = current.status
                    // status == null means a local/config/security error from BridgeClient
                    // (missing URL/token, HTTPS requirement, etc.), not a network outage.
                    return status != null && (status == 408 || status == 429 || status in 500..599)
                }
                is IOException -> return true
            }
            current = current.cause
        }
        return false
    }

    private fun networkErrorText(t: Throwable): String {
        var current: Throwable? = t
        while (current != null) {
            val text = current.message?.trim().orEmpty()
            if (text.isNotBlank()) return "${current::class.java.simpleName}: ${text.take(180)}"
            current = current.cause
        }
        return t::class.java.simpleName
    }

    override fun onTimeout(startId: Int, fgsType: Int) {
        scope.launch {
            publishState(
                STATE_ERROR,
                "Android остановил длительную фоновую синхронизацию по системному лимиту. Checkpoint сохранён — открой приложение и продолжи.",
                0,
                0,
                "timeout",
                notify = false,
            )
            completed = true
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf(startId)
        }
    }

    override fun onDestroy() {
        OfflinePrepareRuntime.setActive(false)
        heartbeatJob?.cancel()
        if (!completed && syncJob?.isActive == true) {
            syncJob?.cancel()
        }
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val STATE_RUNNING = "RUNNING"
        const val STATE_WAITING_NETWORK = "WAITING_NETWORK"
        const val STATE_READY = "READY"
        const val STATE_ERROR = "ERROR"
        const val STATE_CANCELLED = "CANCELLED"

        private const val ACTION_START = "de.handeltheke.handeldesk.action.PREPARE_OFFLINE"
        private const val ACTION_STOP = "de.handeltheke.handeldesk.action.STOP_PREPARE_OFFLINE"
        private const val EXTRA_IMAGE_MODE = "image_mode"
        private const val CHANNEL_ID = "handeldesk_offline_sync"
        private const val NOTIFICATION_ID = 43013
        private const val RETRY_DELAY_MS = 10_000L
        private const val HEARTBEAT_INTERVAL_MS = 5_000L
        const val HEARTBEAT_STALE_MS = 20_000L

        fun isHeartbeatFresh(heartbeatAt: String?, updatedAt: String?, now: Long = System.currentTimeMillis()): Boolean {
            val last = maxOf(heartbeatAt?.toLongOrNull() ?: 0L, updatedAt?.toLongOrNull() ?: 0L)
            return last > 0L && now - last <= HEARTBEAT_STALE_MS
        }

        fun start(context: Context, imageMode: String) {
            val intent = Intent(context, OfflinePrepareService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_IMAGE_MODE, imageMode)
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, OfflinePrepareService::class.java).setAction(ACTION_STOP)
            context.startService(intent)
        }
    }
}
