package de.handeltheke.handeldesk.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import de.handeltheke.handeldesk.HandelDeskApp
import de.handeltheke.handeldesk.core.HandelthekeSeoPolicy
import de.handeltheke.handeldesk.data.local.ProductEntity
import de.handeltheke.handeldesk.domain.*
import de.handeltheke.handeldesk.ui.ScreenHeader
import de.handeltheke.handeldesk.ui.components.AutoSaveField
import de.handeltheke.handeldesk.ui.components.CachedProductImage
import kotlinx.coroutines.launch
import kotlinx.serialization.json.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductScreen(
    uuid: String,
    onBack: () -> Unit,
    onReplace: (String) -> Unit,
    onReadyToWork: () -> Unit,
) {
    val app = LocalContext.current.applicationContext as HandelDeskApp
    val product by app.container.db.products().observe(uuid).collectAsState(initial = null)
    val categories by app.container.db.references().observeCategories().collectAsState(initial = emptyList())
    val manufacturers by app.container.db.references().observeManufacturers().collectAsState(initial = emptyList())
    val schemaJson by app.container.db.settings().observe("bridge_schema").collectAsState(initial = null)
    val scope = rememberCoroutineScope()

    var primaryLanguageId by remember { mutableStateOf("1") }
    var showAll by rememberSaveable { mutableStateOf(false) }
    var showCategories by remember { mutableStateOf(false) }
    var showManufacturerPicker by remember { mutableStateOf(false) }
    var manufacturerQuery by rememberSaveable { mutableStateOf("") }
    var showNewManufacturer by remember { mutableStateOf(false) }
    var showNewCategory by remember { mutableStateOf(false) }
    var newManufacturerName by rememberSaveable { mutableStateOf("") }
    var newCategoryName by rememberSaveable { mutableStateOf("") }
    var uiMessage by remember { mutableStateOf<String?>(null) }
    var donor by remember { mutableStateOf<ProductEntity?>(null) }
    var selectedLanguageId by rememberSaveable { mutableStateOf("") }
    var showMainImage by remember { mutableStateOf(false) }
    var showDonorOverride by remember { mutableStateOf(false) }
    var showDeleteLocal by remember { mutableStateOf(false) }
    var weightClassMenu by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { primaryLanguageId = app.container.db.settings().get("primary_language_id") ?: "1" }
    LaunchedEffect(product?.sourceProductId) {
        donor = product?.sourceProductId?.let { app.container.db.products().getByProductId(it) }
    }

    val schema = remember(schemaJson) { JsonTools.objectOf(schemaJson.orEmpty()) }
    val schemaLanguages = remember(schemaJson) {
        (schema["languages"] as? JsonArray).orEmpty().mapNotNull { it as? JsonObject }
    }
    val languageNames = remember(schemaJson) {
        schemaLanguages.associate { row ->
            row["language_id"]?.jsonPrimitive?.contentOrNull.orEmpty() to
                row["name"]?.jsonPrimitive?.contentOrNull.orEmpty()
        }.filterKeys { it.isNotBlank() }
    }
    val weightClasses = remember(schemaJson) {
        (schema["weight_classes"] as? JsonArray).orEmpty().mapNotNull { it as? JsonObject }
    }
    val schemaOptions = remember(schemaJson) { (schema["options"] as? JsonArray) ?: JsonArray(emptyList()) }

    val p = product
    if (p == null) {
        Column { ScreenHeader("Товар", onBack = onBack); LinearProgressIndicator(Modifier.fillMaxWidth()) }
        return
    }

    val payload = remember(p.localJson) { JsonTools.objectOf(p.localJson) }
    val core = payload["product"]?.jsonObject ?: buildJsonObject {}
    val descriptions = payload["descriptions"]?.jsonObject ?: buildJsonObject {}

    LaunchedEffect(primaryLanguageId, descriptions.keys.joinToString("|")) {
        val fallback = if (primaryLanguageId in descriptions.keys) primaryLanguageId else descriptions.keys.firstOrNull().orEmpty()
        if (selectedLanguageId.isBlank() || selectedLanguageId !in descriptions.keys) selectedLanguageId = fallback
    }

    val activeLanguageId = selectedLanguageId.ifBlank { primaryLanguageId }
    val desc = descriptions[activeLanguageId]?.jsonObject ?: descriptions.values.firstOrNull()?.jsonObject ?: buildJsonObject {}
    val mainImage = core["image"]?.jsonPrimitive?.contentOrNull.orEmpty()
    val selectedCategories = (payload["categories"] as? JsonArray).orEmpty().mapNotNull { it.jsonPrimitive.intOrNull }.toSet()
    val manufacturerName = manufacturers.firstOrNull { it.manufacturerId == p.manufacturerId }?.name ?: "—"
    val validation = remember(p.localJson, primaryLanguageId) { ValidationEngine.validate(p, primaryLanguageId) }
    val checklist = remember(p.localJson, donor?.localJson) { donor?.let { ValidationEngine.donorChecklist(p, it) } }

    val weightClassId = core["weight_class_id"]?.jsonPrimitive?.intOrNull ?: 0
    val selectedWeightClass = weightClasses.firstOrNull { it["weight_class_id"]?.jsonPrimitive?.intOrNull == weightClassId }
    val weightClassLabel = selectedWeightClass?.let(::weightClassText) ?: if (weightClassId == 0) "—" else "ID $weightClassId"

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(p.name.ifBlank { "Новый товар" }, "${p.productId?.let { "#$it" } ?: "LOCAL"} · ${p.state} · ${p.workflowState}", onBack)
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (mainImage.isNotBlank()) {
                            CachedProductImage(mainImage, modifier = Modifier.fillMaxWidth().clickable { showMainImage = true }, size = 160.dp)
                            Text("Нажмите на фото, чтобы открыть", style = MaterialTheme.typography.bodySmall)
                        }
                        AutoSaveField(
                            value = core["model"]?.jsonPrimitive?.contentOrNull.orEmpty(),
                            label = "Model",
                            onSave = { app.container.productEditor.updateField(uuid, "product.model", JsonPrimitive(it)) },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            AutoSaveField(
                                value = core["price"]?.jsonPrimitive?.contentOrNull.orEmpty(), label = "Цена",
                                onSave = { app.container.productEditor.updateField(uuid, "product.price", JsonPrimitive(it.replace(',', '.'))) },
                                modifier = Modifier.weight(1f)
                            )
                            Column(Modifier.weight(1f)) {
                                Text("Остаток", style = MaterialTheme.typography.labelMedium)
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    OutlinedButton(onClick = { scope.launch { app.container.productEditor.adjustQuantity(uuid, -1) } }) { Text("−1") }
                                    Text(p.quantity.toString(), modifier = Modifier.padding(top = 12.dp))
                                    OutlinedButton(onClick = { scope.launch { app.container.productEditor.adjustQuantity(uuid, +1) } }) { Text("+1") }
                                    OutlinedButton(onClick = { scope.launch { app.container.productEditor.adjustQuantity(uuid, +2) } }) { Text("+2") }
                                }
                            }
                        }
                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Text("Статус", modifier = Modifier.weight(1f))
                            Switch(
                                checked = p.status == 1,
                                onCheckedChange = { checked -> scope.launch { app.container.productEditor.updateField(uuid, "product.status", JsonPrimitive(if (checked) 1 else 0)) } }
                            )
                        }
                        OutlinedButton(
                            onClick = { manufacturerQuery = ""; showManufacturerPicker = true },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(Modifier.fillMaxWidth()) {
                                Text("Производитель", style = MaterialTheme.typography.labelSmall)
                                Text(manufacturerName)
                            }
                        }
                        OutlinedButton(onClick = { showCategories = true }, modifier = Modifier.fillMaxWidth()) {
                            Text("Категории: ${selectedCategories.size} · ${categories.filter { it.categoryId in selectedCategories }.take(3).joinToString { it.name }}")
                        }
                        if (p.sourceProductId != null) Button(onClick = { onReplace(uuid) }, modifier = Modifier.fillMaxWidth()) { Text("⚡ Быстрая замена по донору") }
                    }
                }
            }

            if (checklist?.applicable == true) item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("Donor Checklist", style = MaterialTheme.typography.titleMedium)
                        checklist.items.forEach { item ->
                            Text("${when(item.status){"ok"->"✓";"error"->"✕";else->"⚠"}} ${item.label}${if(item.message.isNotBlank()) " — ${item.message}" else ""}")
                        }
                        if (!checklist.ready) {
                            OutlinedButton(onClick = { showDonorOverride = true }, modifier = Modifier.fillMaxWidth()) { Text("Пропустить ошибки Donor Checklist") }
                        }
                    }
                }
            }

            if (validation.isNotEmpty()) item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("Проверка", style = MaterialTheme.typography.titleMedium)
                        validation.forEach { issue -> Text("${if(issue.severity==Severity.ERROR) "✕" else "⚠"} ${issue.message}") }
                    }
                }
            }

            item {
                TextButton(onClick = { showAll = !showAll }, modifier = Modifier.fillMaxWidth()) { Text(if (showAll) "Скрыть полную карточку" else "ПОЛНАЯ КАРТОЧКА") }
            }

            if (showAll) {
                item { ProductSection("General · Контент") {
                    if (descriptions.isNotEmpty()) {
                        Text("Языки", style = MaterialTheme.typography.labelLarge)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            descriptions.keys.sortedBy { it.toIntOrNull() ?: Int.MAX_VALUE }.forEach { lang ->
                                FilterChip(
                                    selected = activeLanguageId == lang,
                                    onClick = { selectedLanguageId = lang },
                                    label = { Text(languageNames[lang]?.ifBlank { null } ?: "Язык $lang") }
                                )
                            }
                        }
                    }
                    AutoSaveField(desc["name"]?.jsonPrimitive?.contentOrNull.orEmpty(), "Название", { app.container.productEditor.updateField(uuid, "descriptions.$activeLanguageId.name", JsonPrimitive(it)) }, Modifier.fillMaxWidth())
                    AutoSaveField(desc["description"]?.jsonPrimitive?.contentOrNull.orEmpty(), "Description (HTML)", { app.container.productEditor.updateField(uuid, "descriptions.$activeLanguageId.description", JsonPrimitive(it)) }, Modifier.fillMaxWidth(), singleLine = false, minLines = 5)
                    AutoSaveField(desc["meta_title"]?.jsonPrimitive?.contentOrNull.orEmpty(), "Meta Title", { app.container.productEditor.updateField(uuid, "descriptions.$activeLanguageId.meta_title", JsonPrimitive(it)) }, Modifier.fillMaxWidth())
                    AutoSaveField(desc["meta_description"]?.jsonPrimitive?.contentOrNull.orEmpty(), "Meta Description", { app.container.productEditor.updateField(uuid, "descriptions.$activeLanguageId.meta_description", JsonPrimitive(it)) }, Modifier.fillMaxWidth(), singleLine = false, minLines = 2)
                    AutoSaveField(desc["meta_keyword"]?.jsonPrimitive?.contentOrNull.orEmpty(), "Meta Keywords", { app.container.productEditor.updateField(uuid, "descriptions.$activeLanguageId.meta_keyword", JsonPrimitive(it)) }, Modifier.fillMaxWidth())
                    AutoSaveField(desc["tag"]?.jsonPrimitive?.contentOrNull.orEmpty(), "Tags", { app.container.productEditor.updateField(uuid, "descriptions.$activeLanguageId.tag", JsonPrimitive(it)) }, Modifier.fillMaxWidth())
                } }

                item { ProductSection("Data · Данные") {
                    Text("Производитель: $manufacturerName", style = MaterialTheme.typography.bodyMedium)
                    listOf("sku" to "SKU", "upc" to "UPC", "ean" to "EAN", "jan" to "JAN", "isbn" to "ISBN", "mpn" to "MPN", "location" to "Location").forEach { (field,label) ->
                        AutoSaveField(core[field]?.jsonPrimitive?.contentOrNull.orEmpty(), label, { app.container.productEditor.updateField(uuid, "product.$field", JsonPrimitive(it)) }, Modifier.fillMaxWidth())
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AutoSaveField(
                            core["weight"]?.jsonPrimitive?.contentOrNull.orEmpty(),
                            "Вес",
                            { app.container.productEditor.updateField(uuid, "product.weight", JsonPrimitive(it.replace(',', '.'))) },
                            Modifier.weight(1f)
                        )
                        ExposedDropdownMenuBox(expanded = weightClassMenu, onExpandedChange = { weightClassMenu = it }, modifier = Modifier.weight(1f)) {
                            OutlinedTextField(
                                value = weightClassLabel,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Ед. веса") },
                                modifier = Modifier.menuAnchor().fillMaxWidth()
                            )
                            ExposedDropdownMenu(expanded = weightClassMenu, onDismissRequest = { weightClassMenu = false }) {
                                weightClasses.forEach { wc ->
                                    val id = wc["weight_class_id"]?.jsonPrimitive?.intOrNull ?: return@forEach
                                    DropdownMenuItem(
                                        text = { Text(weightClassText(wc)) },
                                        onClick = {
                                            weightClassMenu = false
                                            scope.launch { app.container.productEditor.updateField(uuid, "product.weight_class_id", JsonPrimitive(id)) }
                                        }
                                    )
                                }
                            }
                        }
                    }
                } }

                item { ProductSection("Options · Опции") { OptionsEditor(uuid, payload, schemaOptions, app, scope) } }
                item { ProductSection("SEO URL") { SeoEditor(uuid, payload, languageNames, app) } }
                item { ProductSection("Изображения") {
                    Text("Главное: ${core["image"]?.jsonPrimitive?.contentOrNull.orEmpty().ifBlank { "—" }}")
                    val images = (payload["images"] as? JsonArray).orEmpty()
                    Text("Дополнительных: ${images.size}")
                    images.forEachIndexed { i, img -> Text("${i+1}. ${img.jsonObject["image"]?.jsonPrimitive?.contentOrNull.orEmpty()}") }
                } }
                item { ProductSection("Локальная заметка") {
                    AutoSaveField(p.localNote, "Не синхронизируется", { app.container.productEditor.setLocalNote(uuid, it) }, Modifier.fillMaxWidth(), singleLine = false, minLines = 2)
                } }
            }
        }

        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { scope.launch { app.container.productEditor.addToQueue(uuid) } }, modifier = Modifier.weight(1f)) { Text("В очередь") }
                Button(onClick = {
                    scope.launch {
                        runCatching { app.container.productEditor.setWorkflowState(uuid, "READY") }
                            .onSuccess {
                                if (p.productId == null) {
                                    app.container.productEditor.addToQueue(uuid)
                                    onReadyToWork()
                                }
                            }
                            .onFailure {
                                val text = it.message ?: "Не удалось отметить товар готовым"
                                if (text.contains("Donor Checklist", ignoreCase = true)) showDonorOverride = true else uiMessage = text
                            }
                    }
                }, modifier = Modifier.weight(1f)) { Text(if (p.workflowState == "READY") "✓ Готов" else "Отметить готовым") }
            }
            if (p.productId == null) {
                TextButton(onClick = { showDeleteLocal = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Удалить локальный товар", color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }

    if (showManufacturerPicker) {
        val filtered = remember(manufacturerQuery, manufacturers) {
            val q = manufacturerQuery.trim().lowercase()
            if (q.isBlank()) manufacturers else manufacturers.filter { it.name.lowercase().contains(q) }
        }
        AlertDialog(
            onDismissRequest = { showManufacturerPicker = false },
            title = { Text("Производитель") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = manufacturerQuery,
                        onValueChange = { manufacturerQuery = it },
                        label = { Text("Поиск по названию") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = {
                            showManufacturerPicker = false
                            showNewManufacturer = true
                        }) { Text("＋ Новый") }
                        TextButton(onClick = {
                            scope.launch { app.container.productEditor.updateField(uuid, "product.manufacturer_id", JsonPrimitive(0)) }
                            showManufacturerPicker = false
                        }) { Text("Без производителя") }
                    }
                    LazyColumn(Modifier.heightIn(max = 420.dp)) {
                        items(filtered, key = { it.uuid }) { m ->
                            Row(
                                Modifier.fillMaxWidth().clickable {
                                    scope.launch { app.container.productEditor.updateField(uuid, "product.manufacturer_id", JsonPrimitive(m.manufacturerId)) }
                                    showManufacturerPicker = false
                                }.padding(vertical = 10.dp)
                            ) {
                                Text(m.name)
                            }
                            HorizontalDivider()
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showManufacturerPicker = false }) { Text("Закрыть") } }
        )
    }

    if (showCategories) {
        AlertDialog(
            onDismissRequest = { showCategories = false },
            title = { Text("Категории") },
            text = {
                LazyColumn(Modifier.heightIn(max = 480.dp)) {
                    item {
                        TextButton(onClick = { showCategories = false; showNewCategory = true }) { Text("＋ Новая категория") }
                        HorizontalDivider()
                    }
                    itemsIndexed(categories) { _, c ->
                        val checked = c.categoryId in selectedCategories
                        Row(Modifier.fillMaxWidth().clickable {
                            val next = selectedCategories.toMutableSet().apply { if (checked) remove(c.categoryId) else add(c.categoryId) }.sorted()
                            scope.launch { app.container.productEditor.updateField(uuid, "categories", JsonArray(next.map(::JsonPrimitive))) }
                        }.padding(vertical = 6.dp)) {
                            Checkbox(checked = checked, onCheckedChange = null)
                            Text(c.name, modifier = Modifier.padding(top = 12.dp))
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showCategories = false }) { Text("Готово") } }
        )
    }

    if (showNewManufacturer) {
        AlertDialog(
            onDismissRequest = { showNewManufacturer = false },
            title = { Text("Новый производитель") },
            text = { OutlinedTextField(newManufacturerName, { newManufacturerName = it }, label = { Text("Название") }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        runCatching { app.container.references.createManufacturer(newManufacturerName) }
                            .onSuccess { created ->
                                app.container.productEditor.updateField(uuid, "product.manufacturer_id", JsonPrimitive(created.manufacturerId))
                                newManufacturerName = ""; showNewManufacturer = false
                            }.onFailure { uiMessage = it.message }
                    }
                }) { Text("Создать и выбрать") }
            },
            dismissButton = { TextButton(onClick = { showNewManufacturer = false }) { Text("Отмена") } }
        )
    }

    if (showNewCategory) {
        AlertDialog(
            onDismissRequest = { showNewCategory = false },
            title = { Text("Новая категория") },
            text = { OutlinedTextField(newCategoryName, { newCategoryName = it }, label = { Text("Название") }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        runCatching { app.container.references.createCategory(newCategoryName, primaryLanguageId = primaryLanguageId) }
                            .onSuccess { created ->
                                val next = (selectedCategories + created.categoryId).sorted()
                                app.container.productEditor.updateField(uuid, "categories", JsonArray(next.map(::JsonPrimitive)))
                                newCategoryName = ""; showNewCategory = false
                            }.onFailure { uiMessage = it.message }
                    }
                }) { Text("Создать и выбрать") }
            },
            dismissButton = { TextButton(onClick = { showNewCategory = false }) { Text("Отмена") } }
        )
    }

    if (showMainImage && mainImage.isNotBlank()) {
        AlertDialog(
            onDismissRequest = { showMainImage = false },
            title = { Text("Главное изображение") },
            text = { CachedProductImage(mainImage, modifier = Modifier.fillMaxWidth(), size = 320.dp, contentScale = ContentScale.Fit) },
            confirmButton = { TextButton(onClick = { showMainImage = false }) { Text("Закрыть") } }
        )
    }

    if (showDonorOverride) {
        AlertDialog(
            onDismissRequest = { showDonorOverride = false },
            title = { Text("Пропустить Donor Checklist?") },
            text = { Text("Товар можно отметить готовым несмотря на ошибки сравнения с донором. Обычные ошибки карточки всё равно останутся обязательными.") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        runCatching { app.container.productEditor.setWorkflowState(uuid, "READY", ignoreDonorChecklistErrors = true) }
                            .onSuccess {
                                showDonorOverride = false
                                if (p.productId == null) {
                                    app.container.productEditor.addToQueue(uuid)
                                    onReadyToWork()
                                }
                            }
                            .onFailure { uiMessage = it.message ?: "Не удалось отметить товар готовым"; showDonorOverride = false }
                    }
                }) { Text("Пропустить и отметить готовым") }
            },
            dismissButton = { TextButton(onClick = { showDonorOverride = false }) { Text("Отмена") } }
        )
    }

    if (showDeleteLocal) {
        AlertDialog(
            onDismissRequest = { showDeleteLocal = false },
            title = { Text("Удалить локальный товар?") },
            text = { Text("Товар ещё не существует на сервере. Он будет полностью удалён с телефона вместе со всеми несинхронизированными изменениями и записью из очереди. Отменить это действие нельзя.") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        runCatching { app.container.productEditor.deleteLocalProduct(uuid) }
                            .onSuccess { showDeleteLocal = false; onBack() }
                            .onFailure { uiMessage = it.message ?: "Не удалось удалить локальный товар"; showDeleteLocal = false }
                    }
                }) { Text("Удалить", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { showDeleteLocal = false }) { Text("Отмена") } }
        )
    }

    if (uiMessage != null) {
        AlertDialog(
            onDismissRequest = { uiMessage = null },
            title = { Text("HandelDesk") },
            text = { Text(uiMessage.orEmpty()) },
            confirmButton = { TextButton(onClick = { uiMessage = null }) { Text("OK") } }
        )
    }
}

@Composable
private fun ProductSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    var open by rememberSaveable(title) { mutableStateOf(title.startsWith("General")) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(Modifier.fillMaxWidth().clickable { open = !open }, horizontalArrangement = Arrangement.SpaceBetween) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(if (open) "⌃" else "⌄")
            }
            if (open) { Spacer(Modifier.height(8.dp)); Column(verticalArrangement = Arrangement.spacedBy(8.dp), content = content) }
        }
    }
}

@Composable
private fun OptionsEditor(
    uuid: String,
    payload: JsonObject,
    schemaOptions: JsonArray,
    app: HandelDeskApp,
    scope: kotlinx.coroutines.CoroutineScope,
) {
    val options = (payload["options"] as? JsonArray).orEmpty()
    val templates = schemaOptions.mapNotNull { it as? JsonObject }
    val templateById = templates.associateBy { it["option_id"]?.jsonPrimitive?.intOrNull ?: -1 }

    var showAdd by remember { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    var chosenId by remember { mutableStateOf<Int?>(null) }
    var selectedValues by remember { mutableStateOf<Set<Int>>(emptySet()) }

    if (options.isEmpty()) Text("Опций нет")

    options.forEachIndexed { oi, optElement ->
        val option = optElement.jsonObject
        val optionId = option["option_id"]?.jsonPrimitive?.intOrNull ?: 0
        val template = templateById[optionId]
        val optionName = template?.get("name")?.jsonPrimitive?.contentOrNull ?: "Option ID $optionId"
        val valueNames = (template?.get("values") as? JsonArray).orEmpty().mapNotNull { it as? JsonObject }
            .associate { (it["option_value_id"]?.jsonPrimitive?.intOrNull ?: -1) to it["name"]?.jsonPrimitive?.contentOrNull.orEmpty() }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(optionName, style = MaterialTheme.typography.titleSmall)
            TextButton(onClick = {
                val newOptions = options.toMutableList().apply { removeAt(oi) }
                scope.launch { app.container.productEditor.updateField(uuid, "options", JsonArray(newOptions)) }
            }) { Text("Удалить") }
        }

        val values = (option["values"] as? JsonArray).orEmpty()
        values.forEachIndexed { vi, valueElement ->
            val value = valueElement.jsonObject
            val valueId = value["option_value_id"]?.jsonPrimitive?.intOrNull ?: 0
            val q = value["quantity"]?.jsonPrimitive?.intOrNull ?: 0
            val price = value["price"]?.jsonPrimitive?.contentOrNull.orEmpty()
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(valueNames[valueId]?.ifBlank { null } ?: "#$valueId", modifier = Modifier.weight(1f))
                OutlinedButton(onClick = {
                    val newValues = values.toMutableList(); newValues[vi] = JsonObject(value.toMutableMap().apply { put("quantity", JsonPrimitive(q - 1)) })
                    val newOption = JsonObject(option.toMutableMap().apply { put("values", JsonArray(newValues)) })
                    val newOptions = options.toMutableList(); newOptions[oi] = newOption
                    scope.launch { app.container.productEditor.updateField(uuid, "options", JsonArray(newOptions)) }
                }) { Text("−") }
                Text(q.toString(), modifier = Modifier.padding(top = 12.dp))
                OutlinedButton(onClick = {
                    val newValues = values.toMutableList(); newValues[vi] = JsonObject(value.toMutableMap().apply { put("quantity", JsonPrimitive(q + 1)) })
                    val newOption = JsonObject(option.toMutableMap().apply { put("values", JsonArray(newValues)) })
                    val newOptions = options.toMutableList(); newOptions[oi] = newOption
                    scope.launch { app.container.productEditor.updateField(uuid, "options", JsonArray(newOptions)) }
                }) { Text("+") }
                Text("€ $price", modifier = Modifier.padding(top = 12.dp))
            }
        }
        HorizontalDivider()
    }

    OutlinedButton(
        onClick = { query = ""; chosenId = null; selectedValues = emptySet(); showAdd = true },
        enabled = templates.isNotEmpty(),
        modifier = Modifier.fillMaxWidth()
    ) { Text("＋ Добавить опцию") }
    if (templates.isEmpty()) Text("Список опций не загружен. Обновите Offline/Bridge schema.", style = MaterialTheme.typography.bodySmall)

    if (showAdd) {
        val existingIds = options.mapNotNull { it.jsonObject["option_id"]?.jsonPrimitive?.intOrNull }.toSet()
        val chosen = templates.firstOrNull { it["option_id"]?.jsonPrimitive?.intOrNull == chosenId }
        val chosenValues = (chosen?.get("values") as? JsonArray).orEmpty().mapNotNull { it as? JsonObject }
        val type = chosen?.get("type")?.jsonPrimitive?.contentOrNull.orEmpty()
        val needsValues = type in setOf("select", "radio", "checkbox", "image")
        val filtered = templates.filter { t ->
            val id = t["option_id"]?.jsonPrimitive?.intOrNull ?: -1
            val name = t["name"]?.jsonPrimitive?.contentOrNull.orEmpty()
            id !in existingIds && (query.isBlank() || name.contains(query, ignoreCase = true))
        }

        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text(if (chosen == null) "Добавить опцию" else chosen["name"]?.jsonPrimitive?.contentOrNull.orEmpty()) },
            text = {
                if (chosen == null) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(query, { query = it }, label = { Text("Поиск опции") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        LazyColumn(Modifier.heightIn(max = 420.dp)) {
                            items(filtered) { t ->
                                val id = t["option_id"]?.jsonPrimitive?.intOrNull ?: return@items
                                Row(Modifier.fillMaxWidth().clickable { chosenId = id; selectedValues = emptySet() }.padding(vertical = 10.dp)) {
                                    Column {
                                        Text(t["name"]?.jsonPrimitive?.contentOrNull.orEmpty())
                                        Text(t["type"]?.jsonPrimitive?.contentOrNull.orEmpty(), style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                                HorizontalDivider()
                            }
                        }
                    }
                } else if (needsValues) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = { selectedValues = chosenValues.mapNotNull { it["option_value_id"]?.jsonPrimitive?.intOrNull }.toSet() }) { Text("Выбрать все") }
                            TextButton(onClick = { selectedValues = emptySet() }) { Text("Снять все") }
                        }
                        LazyColumn(Modifier.heightIn(max = 420.dp)) {
                            items(chosenValues) { value ->
                                val id = value["option_value_id"]?.jsonPrimitive?.intOrNull ?: return@items
                                val checked = id in selectedValues
                                Row(Modifier.fillMaxWidth().clickable { selectedValues = if (checked) selectedValues - id else selectedValues + id }.padding(vertical = 5.dp)) {
                                    Checkbox(checked, onCheckedChange = null)
                                    Text(value["name"]?.jsonPrimitive?.contentOrNull.orEmpty(), modifier = Modifier.padding(top = 12.dp))
                                }
                            }
                        }
                    }
                } else {
                    Text("Опция типа $type будет добавлена без значений. Значение можно будет заполнить в следующем этапе редактора.")
                }
            },
            confirmButton = {
                if (chosen != null) {
                    TextButton(
                        enabled = !needsValues || selectedValues.isNotEmpty(),
                        onClick = {
                            val optionId = chosen["option_id"]?.jsonPrimitive?.intOrNull ?: 0
                            if (optionId <= 0) {
                                showAdd = false
                                return@TextButton
                            }
                            val valueRows = if (needsValues) chosenValues.mapNotNull { templateValue ->
                                val valueId = templateValue["option_value_id"]?.jsonPrimitive?.intOrNull ?: return@mapNotNull null
                                if (valueId !in selectedValues) return@mapNotNull null
                                buildJsonObject {
                                    put("option_value_id", valueId)
                                    put("quantity", 0)
                                    put("subtract", 1)
                                    put("price", "0.0000")
                                    put("price_prefix", "+")
                                    put("points", 0)
                                    put("points_prefix", "+")
                                    put("weight", "0.00000000")
                                    put("weight_prefix", "+")
                                }
                            } else emptyList()
                            val newOption = buildJsonObject {
                                put("option_id", optionId)
                                put("value", "")
                                put("required", 0)
                                put("values", JsonArray(valueRows))
                            }
                            scope.launch { app.container.productEditor.updateField(uuid, "options", JsonArray(options + newOption)) }
                            showAdd = false
                        }
                    ) { Text("Добавить") }
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    if (chosen != null) { chosenId = null; selectedValues = emptySet() } else showAdd = false
                }) { Text(if (chosen != null) "← Назад" else "Отмена") }
            }
        )
    }
}

@Composable
private fun SeoEditor(uuid: String, payload: JsonObject, languageNames: Map<String, String>, app: HandelDeskApp) {
    val rows = (payload["seo_urls"] as? JsonArray).orEmpty()
    if (rows.isEmpty()) { Text("SEO URL отсутствует"); return }
    rows.forEachIndexed { index, rowElement ->
        val row = rowElement.jsonObject
        val languageId = row["language_id"]?.jsonPrimitive?.contentOrNull.orEmpty()
        val languageLabel = languageNames[languageId]?.ifBlank { null } ?: "Язык $languageId"
        AutoSaveField(
            value = row["keyword"]?.jsonPrimitive?.contentOrNull.orEmpty(),
            label = "SEO · $languageLabel",
            onSave = { raw -> app.container.productEditor.updateField(uuid, "seo_urls.$index.keyword", JsonPrimitive(HandelthekeSeoPolicy.slug(raw))) },
            modifier = Modifier.fillMaxWidth()
        )
    }
}

private fun weightClassText(row: JsonObject): String {
    val title = row["title"]?.jsonPrimitive?.contentOrNull.orEmpty()
    val unit = row["unit"]?.jsonPrimitive?.contentOrNull.orEmpty()
    val id = row["weight_class_id"]?.jsonPrimitive?.contentOrNull.orEmpty()
    return when {
        title.isNotBlank() && unit.isNotBlank() -> "$title ($unit)"
        title.isNotBlank() -> title
        unit.isNotBlank() -> unit
        else -> "ID $id"
    }
}
