package de.handeltheke.handeldesk.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import de.handeltheke.handeldesk.HandelDeskApp
import de.handeltheke.handeldesk.ui.ScreenHeader
import de.handeltheke.handeldesk.worker.OfflinePrepareService
import de.handeltheke.handeldesk.worker.OfflinePrepareRuntime
import kotlinx.coroutines.delay

@Composable
fun PrepareOfflineScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val app = context.applicationContext as HandelDeskApp
    val settings = app.container.db.settings()
    val total by app.container.db.products().observeTotalCount().collectAsState(initial = 0)

    val lastSnapshot by settings.observe("snapshot_at").collectAsState(initial = null)
    val lastMode by settings.observe("last_refresh_mode").collectAsState(initial = null)
    val lastSummary by settings.observe("last_refresh_summary").collectAsState(initial = null)
    val deltaCursor by settings.observe("delta_cursor").collectAsState(initial = null)
    val checkpointReceived by settings.observe("full_snapshot_received").collectAsState(initial = null)
    val checkpointTotal by settings.observe("full_snapshot_total").collectAsState(initial = null)
    val checkpointAfterId by settings.observe("full_snapshot_after_id").collectAsState(initial = null)

    val jobState by settings.observe("offline_job_state").collectAsState(initial = null)
    val jobMessage by settings.observe("offline_job_message").collectAsState(initial = null)
    val jobCurrentRaw by settings.observe("offline_job_current").collectAsState(initial = null)
    val jobTotalRaw by settings.observe("offline_job_total").collectAsState(initial = null)
    val jobStage by settings.observe("offline_job_stage").collectAsState(initial = null)
    val jobHeartbeatAt by settings.observe("offline_job_heartbeat_at").collectAsState(initial = null)
    val jobUpdatedAt by settings.observe("offline_job_updated_at").collectAsState(initial = null)
    val fullSnapshotInProgress by settings.observe("full_snapshot_in_progress").collectAsState(initial = null)
    val runtimeActive by OfflinePrepareRuntime.active.collectAsState()

    var imageMode by rememberSaveable { mutableStateOf("main") }
    var cacheStats by remember { mutableStateOf(0 to 0L) }
    var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var autoResumeAttempted by rememberSaveable { mutableStateOf(false) }
    var startRequested by remember { mutableStateOf(false) }

    val current = jobCurrentRaw?.toIntOrNull() ?: 0
    val jobTotal = jobTotalRaw?.toIntOrNull() ?: 0
    val checkpointCurrent = checkpointReceived?.toIntOrNull() ?: 0
    val checkpointMax = checkpointTotal?.toIntOrNull() ?: 0
    val persistedActiveState = jobState in setOf(
        OfflinePrepareService.STATE_RUNNING,
        OfflinePrepareService.STATE_WAITING_NETWORK,
    )
    val heartbeatFresh = OfflinePrepareService.isHeartbeatFresh(jobHeartbeatAt, jobUpdatedAt, nowMs)
    val running = runtimeActive && persistedActiveState
    val staleRun = persistedActiveState && !runtimeActive
    val serviceHeartbeatDelayed = running && !heartbeatFresh
    val hasCheckpoint = fullSnapshotInProgress == "1" || checkpointCurrent > 0 || !checkpointAfterId.isNullOrBlank()

    LaunchedEffect(jobState, runtimeActive) {
        while (jobState in setOf(OfflinePrepareService.STATE_RUNNING, OfflinePrepareService.STATE_WAITING_NETWORK)) {
            nowMs = System.currentTimeMillis()
            delay(2_000)
        }
    }

    LaunchedEffect(jobState) {
        cacheStats = app.container.imageCache.cacheStats()
    }

    LaunchedEffect(staleRun, hasCheckpoint) {
        if (staleRun) {
            settings.put(de.handeltheke.handeldesk.data.local.SettingEntity("offline_job_state", "INTERRUPTED"))
            settings.put(de.handeltheke.handeldesk.data.local.SettingEntity("offline_job_message", "Предыдущая фоновая задача была прервана. Checkpoint сохранён."))
            if (hasCheckpoint && !autoResumeAttempted) {
                autoResumeAttempted = true
                startRequested = true
                OfflinePrepareService.start(context, imageMode)
            }
        }
    }

    LaunchedEffect(runtimeActive) {
        if (runtimeActive) startRequested = false
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Подготовить Offline", "Каталог локально: $total товаров", onBack)
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                if (deltaCursor.isNullOrBlank()) {
                    "Первый Full Snapshot теперь сохраняет checkpoint и продолжает с места остановки. После завершения включается Delta Sync."
                } else {
                    "Delta Sync активен: повторно весь каталог не скачивается. Локально изменённые товары серверными данными не перезаписываются."
                }
            )

            Text(
                "Последнее обновление: ${lastSummary ?: if (lastSnapshot == null) "не выполнялось" else lastMode.orEmpty()}",
                style = MaterialTheme.typography.bodySmall,
            )
            if (!deltaCursor.isNullOrBlank()) {
                Text("Delta cursor: $deltaCursor", style = MaterialTheme.typography.bodySmall)
            } else if (checkpointCurrent > 0 || !checkpointAfterId.isNullOrBlank()) {
                Text(
                    "Checkpoint: $checkpointCurrent${if (checkpointMax > 0) " / $checkpointMax" else ""} · product_id ${checkpointAfterId.orEmpty()}",
                    style = MaterialTheme.typography.bodySmall,
                )
            }

            Text("Изображения для офлайна:", style = MaterialTheme.typography.titleSmall)
            listOf("none" to "Без изображений", "main" to "Только главные", "all" to "Все изображения").forEach { (value, label) ->
                Row(Modifier.fillMaxWidth()) {
                    RadioButton(
                        selected = imageMode == value,
                        onClick = { if (!running) imageMode = value },
                        enabled = !running,
                    )
                    Text(label, modifier = Modifier.padding(top = 12.dp))
                }
            }
            Text(
                "В кеше: ${cacheStats.first} файлов · ${"%.1f".format(cacheStats.second / 1048576.0)} MB",
                style = MaterialTheme.typography.bodySmall,
            )

            if (running) {
                if (jobTotal > 0) {
                    LinearProgressIndicator(
                        progress = { current.toFloat() / jobTotal.coerceAtLeast(1) },
                        modifier = Modifier.fillMaxWidth(),
                    )
                } else {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
                Text(jobMessage ?: "Фоновая задача выполняется", style = MaterialTheme.typography.bodySmall)
                if (jobState == OfflinePrepareService.STATE_WAITING_NETWORK) {
                    Text(
                        "Соединение пропало. Фоновая служба сама повторит запрос, а Snapshot продолжится с checkpoint.",
                        color = MaterialTheme.colorScheme.tertiary,
                        style = MaterialTheme.typography.bodySmall,
                    )
                } else if (jobStage == "snapshot") {
                    Text("Можно свернуть приложение — загрузка продолжится в фоне.", style = MaterialTheme.typography.bodySmall)
                }
            }

            if (staleRun) {
                Text(
                    "Предыдущая задача больше не запущена. Старый статус RUNNING сброшен; checkpoint не потерян.",
                    color = MaterialTheme.colorScheme.tertiary,
                    style = MaterialTheme.typography.bodySmall,
                )
            } else if (serviceHeartbeatDelayed) {
                Text(
                    "Сервис запущен, но heartbeat задержан. Если Bridge не ответит, запрос автоматически завершится по таймауту и будет повторён.",
                    color = MaterialTheme.colorScheme.tertiary,
                    style = MaterialTheme.typography.bodySmall,
                )
            }

            Button(
                onClick = {
                    startRequested = true
                    OfflinePrepareService.start(context, imageMode)
                },
                enabled = !running && !startRequested,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    when {
                        running || startRequested -> "ЗАПУСК ОБНОВЛЕНИЯ…"
                        deltaCursor.isNullOrBlank() && hasCheckpoint -> "ПРОДОЛЖИТЬ OFFLINE"
                        deltaCursor.isNullOrBlank() -> "ПОДГОТОВИТЬ OFFLINE"
                        else -> "ОБНОВИТЬ OFFLINE"
                    }
                )
            }

            if (running) {
                OutlinedButton(
                    onClick = { OfflinePrepareService.stop(context) },
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text("Остановить фоновую задачу")
                }
            }

            when (jobState) {
                OfflinePrepareService.STATE_READY -> Text(
                    jobMessage ?: "✓ OFFLINE READY",
                    color = MaterialTheme.colorScheme.primary,
                )
                OfflinePrepareService.STATE_ERROR -> Text(
                    jobMessage ?: "Ошибка фонового обновления",
                    color = MaterialTheme.colorScheme.error,
                )
            }

            HorizontalDivider()
            Text(
                "Full Snapshot сохраняет прогресс после каждой пачки. Фото, уже находящиеся в кеше, повторно не скачиваются. При потере сети задача ждёт соединение и продолжает автоматически.",
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}
