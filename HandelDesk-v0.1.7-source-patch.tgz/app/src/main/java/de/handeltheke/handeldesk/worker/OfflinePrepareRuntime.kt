package de.handeltheke.handeldesk.worker

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * In-process truth about the foreground service.
 * Persistent DB state is only progress/history and must never be used alone
 * to decide whether the service is actually alive.
 */
object OfflinePrepareRuntime {
    private val _active = MutableStateFlow(false)
    val active: StateFlow<Boolean> = _active.asStateFlow()

    internal fun setActive(value: Boolean) {
        _active.value = value
    }
}
